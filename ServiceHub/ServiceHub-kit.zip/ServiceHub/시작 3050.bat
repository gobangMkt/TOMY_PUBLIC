@echo off
chcp 65001
cd /d "%~dp0"
start http://localhost:3050
python src/main.py
