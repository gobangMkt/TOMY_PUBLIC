const test = require('node:test');
const assert = require('node:assert');
const { matchService } = require('../static/search.js');

const svc = { name: 'KeyDesk', root: '프로젝트/for_Local' };

test('이름 부분일치(대소문자 무시)', () => {
  assert.equal(matchService(svc, 'key'), true);
  assert.equal(matchService(svc, 'DESK'), true);
});

test('루트 라벨로 일치', () => {
  assert.equal(matchService(svc, 'for_local'), true);
  assert.equal(matchService({ name: 'x', root: '에이전트' }, 'agent'), true);
});

test('한글 이름 일치', () => {
  assert.equal(matchService({ name: '블로그허브', root: '프로젝트/for_Release' }, '블로그'), true);
});

test('앞뒤 공백 trim', () => {
  assert.equal(matchService(svc, '  key  '), true);
});

test('빈 쿼리는 전체 통과', () => {
  assert.equal(matchService(svc, ''), true);
  assert.equal(matchService(svc, '   '), true);
  assert.equal(matchService(svc, null), true);
});

test('일치 없으면 false', () => {
  assert.equal(matchService(svc, 'zzz'), false);
});
