import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))
import config


def test_default_config_created(tmp_path, monkeypatch):
    cfg_file = tmp_path / 'config.json'
    monkeypatch.setattr(config, 'CONFIG_PATH', cfg_file)
    monkeypatch.setattr(config, '_REPO_ROOT', tmp_path)
    loaded = config.load_config()
    assert cfg_file.exists()
    assert loaded['manager_port'] == 3050
    assert 'roots' in loaded and len(loaded['roots']) >= 1


def test_resolve_roots_absolute(tmp_path, monkeypatch):
    monkeypatch.setattr(config, '_REPO_ROOT', tmp_path)
    resolved = config.resolve_roots(['프로젝트/for_Local'])
    assert resolved[0] == tmp_path / '프로젝트/for_Local'


def test_save_roundtrip(tmp_path, monkeypatch):
    cfg_file = tmp_path / 'config.json'
    monkeypatch.setattr(config, 'CONFIG_PATH', cfg_file)
    data = {'manager_port': 3050, 'assigned_ports': {'x': 3060}}
    config.save_config(data)
    assert json.loads(cfg_file.read_text(encoding='utf-8'))['assigned_ports']['x'] == 3060


def test_is_onboarded_flag_true():
    assert config.is_onboarded({'onboarded': True, 'roots': []}) is True


def test_is_onboarded_false_when_no_roots_exist(tmp_path, monkeypatch):
    monkeypatch.setattr(config, '_REPO_ROOT', tmp_path)
    assert config.is_onboarded({'onboarded': False, 'roots': ['프로젝트/for_Local']}) is False


def test_is_onboarded_true_when_a_root_exists(tmp_path, monkeypatch):
    monkeypatch.setattr(config, '_REPO_ROOT', tmp_path)
    (tmp_path / 'work').mkdir()
    assert config.is_onboarded({'onboarded': False, 'roots': ['work']}) is True
