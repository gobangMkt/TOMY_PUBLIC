import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from fastapi.testclient import TestClient
import server
import usage


class _Reg:
    def list(self): return []
    def get(self, sid): return None


class _Sup:
    def scan_index(self): return None
    def effective_status(self, s, idx): return 'stopped'


def _app():
    return server.create_app(_Reg(), _Sup(), rescan_fn=lambda: None)


def test_api_usage_shape(monkeypatch):
    monkeypatch.setattr(usage, 'fetch_limits', lambda timeout=10: {
        'ok': True, 'reason': None, 'limits': {'session': {'percent': 11}}})
    monkeypatch.setattr(usage, 'local_stats', lambda days=14: {
        'available': True, 'totals': {'tokens': 5, 'sessions': 1, 'messages': 2,
        'computedDate': '2026-06-19'}, 'daily': [], 'byModel': []})
    monkeypatch.setattr(usage, 'cost_estimate', lambda bm: 0.0)
    c = TestClient(_app())
    r = c.get('/api/usage')
    assert r.status_code == 200
    body = r.json()
    assert 'limits' in body and 'local' in body and 'status' in body
    assert body['local']['cost'] == 0.0


def test_poll_usage_once_updates_cache(monkeypatch):
    monkeypatch.setattr(usage, 'fetch_limits', lambda timeout=10: {
        'ok': True, 'reason': None, 'limits': {'session': {'percent': 42}}})
    app = _app()
    asyncio.run(app.state.poll_usage_once())
    assert app.state.usage_cache['limits']['session']['percent'] == 42
    assert app.state.usage_cache['status'] == 'ok'
    assert app.state.usage_cache['updatedAt'] is not None


def test_poll_usage_once_failure_keeps_last(monkeypatch):
    app = _app()
    app.state.usage_cache.update(limits={'session': {'percent': 7}}, status='ok')
    monkeypatch.setattr(usage, 'fetch_limits', lambda timeout=10: {
        'ok': False, 'reason': 'network', 'limits': None})
    asyncio.run(app.state.poll_usage_once())
    assert app.state.usage_cache['limits']['session']['percent'] == 7
    assert app.state.usage_cache['status'] == 'network'
