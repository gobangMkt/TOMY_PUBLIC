import io
import json as _json
import sys
import urllib.error
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

import usage


def test_parse_limits_normalizes_kinds():
    data = {
        'limits': [
            {'kind': 'session', 'percent': 11, 'severity': 'normal',
             'resets_at': '2026-06-21T07:00:00+00:00', 'scope': None},
            {'kind': 'weekly_all', 'percent': 21, 'severity': 'normal',
             'resets_at': '2026-06-26T23:00:00+00:00', 'scope': None},
            {'kind': 'weekly_scoped', 'percent': 3, 'severity': 'normal',
             'resets_at': '2026-06-26T22:59:59+00:00',
             'scope': {'model': {'display_name': 'Sonnet'}}},
        ]
    }
    out = usage.parse_limits(data)
    assert out['session']['percent'] == 11
    assert out['weekly_all']['percent'] == 21
    assert out['weekly_scoped']['percent'] == 3
    assert out['weekly_scoped']['label'] == 'Sonnet'


def test_parse_limits_handles_missing():
    assert usage.parse_limits({})['session'] is None


def test_model_family():
    assert usage._model_family('claude-opus-4-8') == 'opus'
    assert usage._model_family('claude-haiku-4-5-20251001') == 'haiku'
    assert usage._model_family('claude-sonnet-4-6') == 'sonnet'


def test_load_token_no_file(tmp_path, monkeypatch):
    monkeypatch.setattr(usage, 'CRED_PATH', tmp_path / 'none.json')
    token, err = usage._load_token()
    assert token is None and err == 'no_credentials'


def test_load_token_expired(tmp_path, monkeypatch):
    p = tmp_path / 'cred.json'
    p.write_text(_json.dumps({'claudeAiOauth': {
        'accessToken': 'x', 'expiresAt': 1}}), encoding='utf-8')
    monkeypatch.setattr(usage, 'CRED_PATH', p)
    token, err = usage._load_token()
    assert token is None and err == 'needs_login'


def test_fetch_limits_ok(tmp_path, monkeypatch):
    p = tmp_path / 'cred.json'
    p.write_text(_json.dumps({'claudeAiOauth': {
        'accessToken': 'tok', 'expiresAt': 9999999999999}}), encoding='utf-8')
    monkeypatch.setattr(usage, 'CRED_PATH', p)
    body = _json.dumps({'limits': [
        {'kind': 'session', 'percent': 11, 'resets_at': 'x', 'severity': 'normal'}]})

    def fake_urlopen(req, timeout=10):
        assert req.headers['Authorization'] == 'Bearer tok'
        return io.BytesIO(body.encode('utf-8'))
    monkeypatch.setattr(usage.urllib.request, 'urlopen', fake_urlopen)
    res = usage.fetch_limits()
    assert res['ok'] is True
    assert res['limits']['session']['percent'] == 11


def test_fetch_limits_401(tmp_path, monkeypatch):
    p = tmp_path / 'cred.json'
    p.write_text(_json.dumps({'claudeAiOauth': {
        'accessToken': 'tok', 'expiresAt': 9999999999999}}), encoding='utf-8')
    monkeypatch.setattr(usage, 'CRED_PATH', p)

    def fake_urlopen(req, timeout=10):
        raise urllib.error.HTTPError('u', 401, 'unauth', {}, None)
    monkeypatch.setattr(usage.urllib.request, 'urlopen', fake_urlopen)
    res = usage.fetch_limits()
    assert res['ok'] is False and res['reason'] == 'needs_login'


def test_fetch_limits_network(tmp_path, monkeypatch):
    p = tmp_path / 'cred.json'
    p.write_text(_json.dumps({'claudeAiOauth': {
        'accessToken': 'tok', 'expiresAt': 9999999999999}}), encoding='utf-8')
    monkeypatch.setattr(usage, 'CRED_PATH', p)

    def fake_urlopen(req, timeout=10):
        raise urllib.error.URLError('down')
    monkeypatch.setattr(usage.urllib.request, 'urlopen', fake_urlopen)
    res = usage.fetch_limits()
    assert res['ok'] is False and res['reason'] == 'network'


def _line(**o):
    return _json.dumps(o)


def test_local_stats_aggregates(tmp_path, monkeypatch):
    ts = '2026-06-19T03:00:00.000Z'
    opus_u = {'input_tokens': 100, 'output_tokens': 200,
              'cache_read_input_tokens': 10, 'cache_creation_input_tokens': 5}
    son_u = {'input_tokens': 50, 'output_tokens': 50,
             'cache_read_input_tokens': 0, 'cache_creation_input_tokens': 0}
    proj = tmp_path / 'projects' / 'p1'
    proj.mkdir(parents=True)
    (proj / 'a.jsonl').write_text('\n'.join([
        _line(type='user', uuid='u1', timestamp=ts, message={'role': 'user'}),
        _line(type='assistant', uuid='u2', timestamp=ts,
              message={'id': 'm1', 'model': 'claude-opus-4-8', 'usage': opus_u}),
    ]), encoding='utf-8')
    (proj / 'b.jsonl').write_text('\n'.join([
        # m1 중복(resume) → 토큰 dedup, 두 번 세지 않음
        _line(type='assistant', uuid='u3', timestamp=ts,
              message={'id': 'm1', 'model': 'claude-opus-4-8', 'usage': opus_u}),
        _line(type='assistant', uuid='u4', timestamp=ts,
              message={'id': 'm2', 'model': 'claude-sonnet-4-6', 'usage': son_u}),
    ]), encoding='utf-8')
    monkeypatch.setattr(usage, 'PROJECTS_DIR', tmp_path / 'projects')
    usage._file_cache.clear()
    out = usage.local_stats(days=14)
    assert out['available'] is True
    assert out['totals']['sessions'] == 2
    assert out['totals']['messages'] == 4
    assert out['totals']['tokens'] == 415   # opus 315 (dedup) + sonnet 100
    assert out['byModel'][0]['family'] == 'opus'
    assert out['byModel'][0]['tokens'] == 315
    day = usage._local_date(ts)
    assert out['daily'][-1] == {'date': day, 'tokens': 415,
                                'byModel': {'opus': 315, 'sonnet': 100}}


def test_local_stats_missing(tmp_path, monkeypatch):
    monkeypatch.setattr(usage, 'PROJECTS_DIR', tmp_path / 'none')
    usage._file_cache.clear()
    assert usage.local_stats()['available'] is False


def test_cost_estimate():
    by_model = [{'family': 'opus', 'raw': {
        'inputTokens': 1_000_000, 'outputTokens': 1_000_000,
        'cacheReadInputTokens': 0, 'cacheCreationInputTokens': 0}}]
    assert usage.cost_estimate(by_model) == 90.0
