import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))
from fastapi.testclient import TestClient
import server


class FakeReg:
    def __init__(self):
        self._s = {'a': {'id': 'a', 'name': 'A', 'root': 'r', 'type': 'web',
                         'port': 3060, 'command': 'npm run dev', 'enabled': True}}
    def list(self): return list(self._s.values())
    def get(self, sid): return self._s.get(sid)


class FakeSup:
    def __init__(self): self.started = []
    def start(self, svc): self.started.append(svc['id'])
    def stop(self, sid, port=None): pass
    def status(self, sid): return 'running'
    def effective_status(self, svc, proc_index=None): return 'running'
    def scan_index(self): return (set(), [])
    def logs(self, sid): return ['line1', 'line2']
    def stop_all(self): pass


def _client(timer=None):
    app = server.create_app(FakeReg(), FakeSup(), rescan_fn=lambda: None, timer=timer)
    return TestClient(app)


class FakeTimer:
    def __init__(self):
        self.state = {'running': False, 'started_at': None, 'elapsed_seconds': 0,
                      'today_seconds': 0, 'today_date': '2026-06-21', 'auto_stopped': None}
    def get_state(self): return self.state
    def start(self):
        self.state = {**self.state, 'running': True, 'started_at': '2026-06-21T09:00:00+09:00'}
        return self.state
    def stop(self):
        self.state = {**self.state, 'running': False, 'started_at': None, 'today_seconds': 600}
        return self.state


def test_list_services():
    r = _client().get('/api/services')
    assert r.status_code == 200
    data = r.json()
    assert data[0]['id'] == 'a'
    assert data[0]['status'] == 'running'


def test_mini_page_served():
    r = _client().get('/mini')
    assert r.status_code == 200
    assert 'mini.js' in r.text


def test_start_service():
    c = _client()
    r = c.post('/api/services/a/start')
    assert r.status_code == 200
    assert r.json()['ok'] is True


def test_logs_endpoint():
    r = _client().get('/api/services/a/logs')
    assert r.json()['logs'] == ['line1', 'line2']


def test_unknown_service_404():
    assert _client().post('/api/services/zzz/start').status_code == 404


def test_timer_get():
    r = _client(FakeTimer()).get('/api/timer')
    assert r.status_code == 200
    assert r.json()['running'] is False


def test_timer_start_stop():
    c = _client(FakeTimer())
    assert c.post('/api/timer/start').json()['running'] is True
    assert c.post('/api/timer/stop').json()['today_seconds'] == 600


def test_timer_disabled_404():
    assert _client().get('/api/timer').status_code == 404


# ── 미니뷰 토글 ──
def test_miniview_toggle_calls_callback():
    hits = []
    app = server.create_app(FakeReg(), FakeSup(), rescan_fn=lambda: None,
                            mini_toggle=lambda: hits.append(1))
    r = TestClient(app).post('/api/miniview/toggle')
    assert r.status_code == 200 and hits == [1]


def test_miniview_toggle_404_when_disabled():
    r = _client().post('/api/miniview/toggle')
    assert r.status_code == 404


# ── 온보딩 ──
def _onboard_client(tmp_path):
    cfg = {'roots': [], 'overrides': {}, 'assigned_ports': {}, 'onboarded': False}
    saved, rescans = [], []
    app = server.create_app(FakeReg(), FakeSup(),
                            rescan_fn=lambda: rescans.append(1),
                            cfg=cfg, save_fn=lambda c: saved.append(dict(c)))
    return TestClient(app), cfg, saved, rescans


def test_onboard_status_not_onboarded(tmp_path):
    client, *_ = _onboard_client(tmp_path)
    r = client.get('/api/onboard/status')
    assert r.status_code == 200 and r.json()['onboarded'] is False


def test_onboard_preview_bad_dir(tmp_path):
    client, *_ = _onboard_client(tmp_path)
    r = client.post('/api/onboard/preview', json={'folder': 'C:/nope/zzz'})
    assert r.status_code == 200
    body = r.json()
    assert body['ok'] is False and body['candidates'] == []


def test_onboard_preview_lists_candidates(tmp_path):
    (tmp_path / 'for_Local' / 'app-a').mkdir(parents=True)
    (tmp_path / 'for_Local' / 'app-a' / 'package.json').write_text('{"scripts":{"dev":"vite"}}', encoding='utf-8')
    client, *_ = _onboard_client(tmp_path)
    r = client.post('/api/onboard/preview', json={'folder': str(tmp_path)})
    assert r.status_code == 200 and r.json()['ok'] is True
    labels = [c['label'] for c in r.json()['candidates']]
    assert 'for_Local' in labels


def test_onboard_save_persists_and_rescans(tmp_path):
    client, cfg, saved, rescans = _onboard_client(tmp_path)
    r = client.post('/api/onboard/save', json={'roots': ['C:/work/repo/for_Local']})
    assert r.status_code == 200 and r.json()['ok'] is True
    assert cfg['roots'] == ['C:/work/repo/for_Local']
    assert cfg['onboarded'] is True
    assert saved and rescans == [1]


def test_onboard_save_rejects_empty(tmp_path):
    client, *_ = _onboard_client(tmp_path)
    r = client.post('/api/onboard/save', json={'roots': []})
    assert r.status_code == 400
