import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))
from timer import WorkTimer, MAX_RUN_SECONDS

KST = timezone(timedelta(hours=9))


def _clock(start: datetime):
    """가변 now 제공자. box['t']를 바꿔 시간 진행을 시뮬레이트."""
    box = {'t': start}
    return box, (lambda: box['t'])


def _mk(now_box_fn):
    cfg = {}
    saves = []
    box, now_fn = now_box_fn
    t = WorkTimer(cfg, save_fn=lambda c: saves.append(dict(c['work_timer'])), now_fn=now_fn)
    return t, cfg, saves, box


def test_initial_state_not_running():
    t, cfg, _, _ = _mk(_clock(datetime(2026, 6, 21, 9, 0, tzinfo=KST)))
    s = t.get_state()
    assert s['running'] is False
    assert s['elapsed_seconds'] == 0
    assert s['today_seconds'] == 0


def test_start_then_elapsed_counts_up():
    box, now_fn = _clock(datetime(2026, 6, 21, 9, 0, tzinfo=KST))
    t, cfg, _, _ = _mk((box, now_fn))
    t.start()
    box['t'] = datetime(2026, 6, 21, 9, 0, 30, tzinfo=KST)
    s = t.get_state()
    assert s['running'] is True
    assert s['elapsed_seconds'] == 30


def test_stop_accumulates_today():
    box, now_fn = _clock(datetime(2026, 6, 21, 9, 0, tzinfo=KST))
    t, cfg, _, _ = _mk((box, now_fn))
    t.start()
    box['t'] = datetime(2026, 6, 21, 9, 10, tzinfo=KST)  # +600s
    s = t.stop()
    assert s['running'] is False
    assert s['elapsed_seconds'] == 0
    assert s['today_seconds'] == 600


def test_multiple_sessions_sum():
    box, now_fn = _clock(datetime(2026, 6, 21, 9, 0, tzinfo=KST))
    t, cfg, _, _ = _mk((box, now_fn))
    t.start()
    box['t'] = datetime(2026, 6, 21, 9, 5, tzinfo=KST)
    t.stop()                                              # +300
    box['t'] = datetime(2026, 6, 21, 10, 0, tzinfo=KST)
    t.start()
    box['t'] = datetime(2026, 6, 21, 10, 2, tzinfo=KST)
    s = t.stop()                                          # +120
    assert s['today_seconds'] == 420


def test_start_is_idempotent_when_running():
    box, now_fn = _clock(datetime(2026, 6, 21, 9, 0, tzinfo=KST))
    t, cfg, _, _ = _mk((box, now_fn))
    first = t.start()['started_at']
    box['t'] = datetime(2026, 6, 21, 9, 1, tzinfo=KST)
    again = t.start()['started_at']
    assert first == again  # 진행 중 재시작은 무시(started_at 유지)


def test_new_day_resets_today_seconds():
    box, now_fn = _clock(datetime(2026, 6, 21, 9, 0, tzinfo=KST))
    t, cfg, _, _ = _mk((box, now_fn))
    t.start()
    box['t'] = datetime(2026, 6, 21, 9, 30, tzinfo=KST)
    t.stop()  # today=1800
    box['t'] = datetime(2026, 6, 22, 8, 0, tzinfo=KST)  # 다음날, 정지 상태 조회
    s = t.get_state()
    assert s['today_seconds'] == 0
    assert s['today_date'] == '2026-06-22'


def test_midnight_auto_stop_while_running():
    box, now_fn = _clock(datetime(2026, 6, 21, 23, 0, tzinfo=KST))
    t, cfg, _, _ = _mk((box, now_fn))
    t.start()
    # 다음날 조회 → 자정 자동 종료, 전날 진행분 폐기, 오늘 0
    box['t'] = datetime(2026, 6, 22, 14, 0, tzinfo=KST)
    s = t.get_state()
    assert s['running'] is False
    assert s['auto_stopped'] == 'midnight'
    assert s['today_seconds'] == 0
    assert s['today_date'] == '2026-06-22'
    # 자동종료는 1회만 보고
    assert t.get_state()['auto_stopped'] is None


def test_long_run_guard_auto_stops_with_cap():
    box, now_fn = _clock(datetime(2026, 6, 21, 1, 0, tzinfo=KST))
    t, cfg, _, _ = _mk((box, now_fn))
    t.start()
    box['t'] = datetime(2026, 6, 21, 14, 0, tzinfo=KST)  # +13h(같은 날)
    s = t.get_state()
    assert s['running'] is False
    assert s['auto_stopped'] == 'long_run'
    assert s['today_seconds'] == MAX_RUN_SECONDS  # 상한 12h만 누적
    assert t.get_state()['auto_stopped'] is None


def test_state_persisted_via_save():
    box, now_fn = _clock(datetime(2026, 6, 21, 9, 0, tzinfo=KST))
    t, cfg, saves, _ = _mk((box, now_fn))
    t.start()
    assert cfg['work_timer']['started_at'] is not None
    assert len(saves) >= 1  # 시작 시 저장됨
