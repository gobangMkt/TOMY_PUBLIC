import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))
import tray


def test_autostart_cmd_nonempty():
    cmd = tray._build_autostart_cmd()
    assert isinstance(cmd, str) and len(cmd) > 0


def test_icon_image_created():
    img = tray._create_icon_image('#3b82f6')
    assert img.size == (64, 64)
