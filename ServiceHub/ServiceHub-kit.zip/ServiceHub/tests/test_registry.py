import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))
from registry import Registry


def _svc(id_, port, type_='web'):
    return {'id': id_, 'name': id_, 'root': 'r', 'path': '/x', 'type': type_,
            'command': 'npm run dev', 'setup_cmd': None,
            'intended_port': port, 'port': port}


def test_unique_ports_no_conflict():
    cfg = {'port_pool_start': 3060, 'overrides': {}, 'assigned_ports': {}}
    reg = Registry(cfg, save_fn=lambda c: None)
    reg.rebuild([_svc('a', 3017), _svc('b', 3017), _svc('c', 3040)])
    ports = {s['id']: s['port'] for s in reg.list()}
    assert len({ports['a'], ports['b'], ports['c']}) == 3
    assert 3017 in ports.values()  # 하나는 의도포트 유지
    assert ports['c'] == 3040


def test_assigned_ports_persisted():
    saved = {}
    cfg = {'port_pool_start': 3060, 'overrides': {}, 'assigned_ports': {}}
    reg = Registry(cfg, save_fn=lambda c: saved.update(c))
    reg.rebuild([_svc('a', 3017), _svc('b', 3017)])
    assert saved['assigned_ports']  # 저장 호출됨
    # 재시작: 같은 포트 유지
    cfg2 = {'port_pool_start': 3060, 'overrides': {}, 'assigned_ports': dict(saved['assigned_ports'])}
    reg2 = Registry(cfg2, save_fn=lambda c: None)
    reg2.rebuild([_svc('a', 3017), _svc('b', 3017)])
    assert {s['id']: s['port'] for s in reg.list()} == {s['id']: s['port'] for s in reg2.list()}


def test_override_applied():
    cfg = {'port_pool_start': 3060,
           'overrides': {'a': {'name': '커스텀', 'enabled': False}}, 'assigned_ports': {}}
    reg = Registry(cfg, save_fn=lambda c: None)
    reg.rebuild([_svc('a', 3040)])
    svc = reg.get('a')
    assert svc['name'] == '커스텀'
    assert svc['enabled'] is False


def test_task_has_no_port():
    cfg = {'port_pool_start': 3060, 'overrides': {}, 'assigned_ports': {}}
    reg = Registry(cfg, save_fn=lambda c: None)
    reg.rebuild([_svc('t', None, type_='task')])
    assert reg.get('t')['port'] is None


def test_reassign_port_avoids_used_and_busy():
    # 막힌(busy) 포트 + 다른 서비스가 쓰는 포트를 피해 풀에서 다음 빈 포트를 잡는다
    cfg = {'port_pool_start': 3060, 'overrides': {}, 'assigned_ports': {}}
    reg = Registry(cfg, save_fn=lambda c: None)
    reg.rebuild([_svc('a', 3060), _svc('b', 3061)])  # a=3060, b=3061 배정
    busy = {3060, 3061, 3062}  # 3062는 OS가 점유 중이라고 가정
    new_port = reg.reassign_port('a', is_free=lambda p: p not in busy)
    assert new_port == 3063  # 3060(자기 옛포트·busy), 3061(b), 3062(busy) 다 회피
    assert reg.get('a')['port'] == 3063


def test_reassign_port_persists_to_config():
    saved = {}
    cfg = {'port_pool_start': 3060, 'overrides': {}, 'assigned_ports': {}}
    reg = Registry(cfg, save_fn=lambda c: saved.update(c))
    reg.rebuild([_svc('a', 3060)])
    new_port = reg.reassign_port('a', is_free=lambda p: p != 3060)
    assert saved['assigned_ports']['a'] == new_port


def test_reassign_port_ignores_non_web():
    cfg = {'port_pool_start': 3060, 'overrides': {}, 'assigned_ports': {}}
    reg = Registry(cfg, save_fn=lambda c: None)
    reg.rebuild([_svc('t', None, type_='task')])
    assert reg.reassign_port('t', is_free=lambda p: True) is None
