import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))
import os

from supervisor import Supervisor, is_port_free


def _svc(tmp_path, command, type_='task', port=None):
    return {'id': 'dummy', 'name': 'dummy', 'path': str(tmp_path), 'type': type_,
            'command': command, 'setup_cmd': None, 'port': port, 'enabled': True}


def test_run_task_captures_output(tmp_path):
    sup = Supervisor(log_lines=100, on_event=lambda *_: None)
    svc = _svc(tmp_path, f'{sys.executable} -c "print(\'hello-task\')"', type_='task')
    sup.start(svc)
    for _ in range(50):
        if sup.status('dummy') == 'exited':
            break
        time.sleep(0.1)
    assert sup.status('dummy') == 'exited'
    assert any('hello-task' in line for line in sup.logs('dummy'))


def test_start_stop_long_process(tmp_path):
    sup = Supervisor(log_lines=100, on_event=lambda *_: None)
    code = 'import time\nwhile True: time.sleep(0.2)'
    svc = _svc(tmp_path, f'{sys.executable} -c "{code}"', type_='task')
    sup.start(svc)
    time.sleep(0.5)
    assert sup.status('dummy') == 'running'
    sup.stop('dummy')
    time.sleep(0.5)
    assert sup.status('dummy') in ('stopped', 'exited')


def test_start_when_already_running_reemits_state(tmp_path):
    events = []
    sup = Supervisor(log_lines=100, on_event=lambda sid, kind, p: events.append((kind, p)))
    code = 'import time\nwhile True: time.sleep(0.2)'
    svc = _svc(tmp_path, f'{sys.executable} -c "{code}"', type_='task')
    sup.start(svc)
    time.sleep(0.5)
    assert sup.status('dummy') == 'running'
    events.clear()
    sup.start(svc)  # 이미 실행 중 → 무반응 대신 상태 재전송
    assert ('state', 'running') in events
    sup.stop('dummy')


def test_auto_install_prefix_when_no_node_modules(tmp_path):
    (tmp_path / 'package.json').write_text('{}')
    sup = Supervisor(log_lines=100, on_event=lambda *_: None)
    svc = _svc(tmp_path, 'npm run dev', type_='web', port=12345)
    # web+dev+port → vite가 PORT env를 무시하므로 --port 강제 부착
    assert sup._compose_command(svc) == 'npm install && npm run dev -- --port 12345'


def test_port_flag_forced_for_vite_dev(tmp_path):
    (tmp_path / 'package.json').write_text('{}')
    binp = tmp_path / 'node_modules' / '.bin'
    binp.mkdir(parents=True)
    (binp / 'vite').write_text('')
    sup = Supervisor(log_lines=100, on_event=lambda *_: None)
    svc = _svc(tmp_path, 'npm run dev', type_='web', port=3062)
    assert sup._compose_command(svc) == 'npm run dev -- --port 3062'


def test_port_flag_not_added_for_npm_start(tmp_path):
    # node 서버(npm start)는 PORT env로 충분 → 플래그 안 붙임
    (tmp_path / 'package.json').write_text('{}')
    binp = tmp_path / 'node_modules' / '.bin'
    binp.mkdir(parents=True)
    (binp / 'vite').write_text('')
    sup = Supervisor(log_lines=100, on_event=lambda *_: None)
    svc = _svc(tmp_path, 'npm start', type_='web', port=3017)
    assert sup._compose_command(svc) == 'npm start'


def test_no_install_when_node_modules_present(tmp_path):
    (tmp_path / 'package.json').write_text('{}')
    binp = tmp_path / 'node_modules' / '.bin'
    binp.mkdir(parents=True)
    (binp / 'vite').write_text('')
    sup = Supervisor(log_lines=100, on_event=lambda *_: None)
    svc = _svc(tmp_path, 'npm run dev', type_='web')
    assert sup._compose_command(svc) == 'npm run dev'


def test_no_install_for_task(tmp_path):
    (tmp_path / 'package.json').write_text('{}')
    sup = Supervisor(log_lines=100, on_event=lambda *_: None)
    svc = _svc(tmp_path, 'python x.py', type_='task')
    assert sup._compose_command(svc) == 'python x.py'


def test_install_respects_setup_cmd_order(tmp_path):
    (tmp_path / 'package.json').write_text('{}')
    sup = Supervisor(log_lines=100, on_event=lambda *_: None)
    svc = _svc(tmp_path, 'npm run dev', type_='web')
    svc['setup_cmd'] = 'node scan.js'
    assert sup._compose_command(svc) == 'npm install && node scan.js && npm run dev'


def test_no_install_for_python_web_with_package_json(tmp_path):
    # GAS 등 package.json이 있지만 python으로 실행하는 서비스는 npm install 건너뜀
    (tmp_path / 'package.json').write_text('{}')
    sup = Supervisor(log_lines=100, on_event=lambda *_: None)
    svc = _svc(tmp_path, 'python -m http.server 3080', type_='web', port=3080)
    assert sup._compose_command(svc) == 'python -m http.server 3080'


def test_python_http_server_port_replaced(tmp_path):
    # python -m http.server 는 배정 포트로 교체됨 (bat 하드코딩 포트 → 배정 포트)
    sup = Supervisor(log_lines=100, on_event=lambda *_: None)
    svc = _svc(tmp_path, 'python -m http.server 3080', type_='web', port=3081)
    assert sup._compose_command(svc) == 'python -m http.server 3081'


def test_pnpm_install_detected(tmp_path):
    (tmp_path / 'package.json').write_text('{}')
    sup = Supervisor(log_lines=100, on_event=lambda *_: None)
    svc = _svc(tmp_path, 'pnpm dev', type_='web')
    assert sup._compose_command(svc) == 'pnpm install && pnpm dev'


def test_task_external_status_via_cwd(tmp_path):
    # 작업 폴더(cwd)에서 도는 프로세스가 있으면 external
    sup = Supervisor(log_lines=10, on_event=lambda *_: None)
    svc = _svc(tmp_path, 'node watcher.js', type_='task')
    idx = ({os.path.normcase(str(tmp_path))}, [])
    assert sup.effective_status(svc, idx) == 'external'
    assert sup.effective_status(svc, (set(), [])) == 'stopped'


def test_external_status_via_cmdline(tmp_path):
    # cwd가 달라도 명령행에 폴더 경로가 있으면 external (자동실행 절대경로 케이스)
    sup = Supervisor(log_lines=10, on_event=lambda *_: None)
    svc = _svc(tmp_path, 'node watcher.js', type_='task')
    cmd = os.path.normcase(f'pythonw {tmp_path}\\src\\main.py')
    idx = (set(), [cmd])
    assert sup.effective_status(svc, idx) == 'external'


def test_web_with_port_is_authoritative_on_port(tmp_path):
    # web 서비스의 생존 신호는 '포트'가 유일하고 확실하다.
    # 포트가 비어 있으면, 폴더 경로를 cwd/명령행에 가진 무관 프로세스
    # ('Claude Code 열기' 콘솔·에디터·터미널 등)가 있어도 stopped 여야 한다.
    sup = Supervisor(log_lines=10, on_event=lambda *_: None)
    svc = _svc(tmp_path, 'npm run dev', type_='web', port=59999)  # 비어있는 포트
    console = os.path.normcase(f'cmd /k cd /d {tmp_path} && claude')
    idx = ({os.path.normcase(str(tmp_path))}, [console])
    assert sup.effective_status(svc, idx) == 'stopped'


def test_scan_ignores_shells_and_claude_console():
    # 외부 감지 스냅샷은 셸/터미널/에디터/claude 프로세스를 제외해야 한다
    # (이들은 서비스 런타임이 아니라 폴더를 cwd로 갖거나 경로를 인용할 뿐)
    from supervisor import _is_ignorable_proc
    assert _is_ignorable_proc('cmd.exe', 'cmd /k cd /d c:\\proj\\aiit && claude') is True
    assert _is_ignorable_proc('powershell.exe', '') is True
    assert _is_ignorable_proc('Code.exe', 'code c:\\proj\\aiit') is True
    assert _is_ignorable_proc('node.exe', 'node c:\\users\\x\\claude\\cli.js') is True
    # 실제 서비스 런타임은 유지
    assert _is_ignorable_proc('node.exe', 'node c:\\proj\\aiit\\node_modules\\next\\...') is False
    assert _is_ignorable_proc('python.exe', 'python c:\\proj\\aiit\\src\\main.py') is False


def test_stop_external_task_by_path(tmp_path):
    # 허브가 안 띄운 외부 task(작업 폴더에서 도는 프로세스)를 path로 종료
    import subprocess
    code = 'import time\nwhile True: time.sleep(0.2)'
    proc = subprocess.Popen([sys.executable, '-c', code], cwd=str(tmp_path))
    time.sleep(0.3)
    assert proc.poll() is None  # 살아있음
    sup = Supervisor(log_lines=10, on_event=lambda *_: None)
    sup.stop('dummy', port=None, path=str(tmp_path))  # proc 없음 → path 경로로 kill
    for _ in range(30):
        if proc.poll() is not None:
            break
        time.sleep(0.1)
    assert proc.poll() is not None  # 실제로 종료됨
    if proc.poll() is None:
        proc.kill()


def _free_port():
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    port = s.getsockname()[1]
    s.close()
    return port


def _listener_pids(port):
    import psutil
    return {c.pid for c in psutil.net_connections(kind='inet')
            if c.laddr and c.laddr.port == port and c.status == psutil.CONN_LISTEN and c.pid}


def test_kill_by_port_kills_all_listeners(tmp_path):
    # 회귀: 같은 포트에 IPv4·IPv6로 따로 바인딩한 '두' 프로세스를 모두 죽여야 포트가 풀린다.
    # (예전엔 첫 리스너만 죽이고 return → 두 번째가 살아남아 '안 꺼짐')
    import subprocess
    from supervisor import _kill_by_port
    port = _free_port()
    v4 = ("import socket,time\n"
          "s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)\n"
          "s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)\n"
          f"s.bind(('127.0.0.1',{port}));s.listen()\n"
          "while True: time.sleep(0.2)")
    v6 = ("import socket,time\n"
          "s=socket.socket(socket.AF_INET6,socket.SOCK_STREAM)\n"
          f"s.bind(('::1',{port}));s.listen()\n"
          "while True: time.sleep(0.2)")
    p4 = subprocess.Popen([sys.executable, '-c', v4])
    p6 = subprocess.Popen([sys.executable, '-c', v6])
    try:
        for _ in range(50):
            if len(_listener_pids(port)) >= 2:
                break
            time.sleep(0.1)
        assert len(_listener_pids(port)) >= 2  # 두 리스너 모두 떠 있음
        _kill_by_port(port)
        freed = False
        for _ in range(50):
            if is_port_free(port):
                freed = True
                break
            time.sleep(0.1)
        assert freed, '포트가 풀리지 않음 — 리스너 일부가 생존'
    finally:
        for p in (p4, p6):
            if p.poll() is None:
                p.kill()


def test_kill_by_port_kills_respawning_parent(tmp_path):
    # 회귀: 워커가 죽으면 부모가 재spawn하는 슈퍼바이저(next dev·nodemon류)도 함께 죽여야
    # 포트가 계속 풀려 있다. (하위 트리만 죽이면 부모가 워커를 부활시켜 '안 꺼짐')
    import subprocess
    from supervisor import _kill_by_port
    port = _free_port()
    worker = tmp_path / 'w.py'
    worker.write_text("import socket,time\n"
                      "s=socket.socket();s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)\n"
                      f"s.bind(('127.0.0.1',{port}));s.listen()\n"
                      "while True: time.sleep(0.2)")
    parent = tmp_path / 'p.py'
    parent.write_text("import subprocess,sys,time\n"
                      f"w=r'{worker}'\n"
                      "while True:\n"
                      "  c=subprocess.Popen([sys.executable,w]);c.wait();time.sleep(0.2)")
    pp = subprocess.Popen([sys.executable, str(parent)])
    try:
        for _ in range(50):
            if not is_port_free(port):
                break
            time.sleep(0.1)
        assert not is_port_free(port)
        _kill_by_port(port)
        time.sleep(1.2)  # 재spawn 기회 부여
        assert is_port_free(port), '부모 슈퍼바이저가 워커를 재spawn함(부모 미종료)'
    finally:
        if pp.poll() is None:
            pp.kill()


def test_start_reassigns_when_port_busy(tmp_path):
    # 배정 포트가 막혀 있으면 에러로 끝내지 말고 재배정 콜백으로 빈 포트를 받아 기동한다
    import socket
    blocker = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    blocker.bind(('127.0.0.1', 0))
    blocker.listen()
    busy_port = blocker.getsockname()[1]
    events = []

    def reassign(svc):
        svc['port'] = 59998  # 비어있는 포트로 옮김
        return 59998

    sup = Supervisor(log_lines=50, on_event=lambda sid, kind, p: events.append((kind, p)),
                     reassign_fn=reassign)
    code = "import time\nprint('up', flush=True)\nwhile True: time.sleep(0.2)"
    svc = _svc(tmp_path, f'{sys.executable} -c "{code}"', type_='web', port=busy_port)
    sup.start(svc)
    for _ in range(20):
        if sup.status('dummy') == 'running':
            break
        time.sleep(0.1)
    try:
        assert svc['port'] == 59998
        assert sup.status('dummy') == 'running'  # 에러 아님, 실제 기동됨
        assert not any(kind == 'error' for kind, _ in events)
    finally:
        sup.stop('dummy')
        blocker.close()


def test_start_errors_when_busy_and_no_reassign(tmp_path):
    # 재배정 콜백이 없으면 기존 동작 유지: 포트 사용중 에러
    import socket
    blocker = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    blocker.bind(('127.0.0.1', 0))
    blocker.listen()
    busy_port = blocker.getsockname()[1]
    events = []
    sup = Supervisor(log_lines=50, on_event=lambda sid, kind, p: events.append((kind, p)))
    svc = _svc(tmp_path, 'npm run dev', type_='web', port=busy_port)
    sup.start(svc)
    try:
        assert any(kind == 'error' for kind, _ in events)
        assert ('state', 'error') in events  # 재배정 없으면 에러 상태로
    finally:
        blocker.close()


def test_is_port_free_detects_listener():
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    s.listen()
    port = s.getsockname()[1]
    assert is_port_free(port) is False
    s.close()
    assert is_port_free(port) is True


def test_is_port_free_detects_ipv6_only_listener():
    # vite처럼 ::1(IPv6)에만 바인딩한 서버도 사용중으로 감지해야 함
    import socket
    s = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
    s.bind(('::1', 0))
    s.listen()
    port = s.getsockname()[1]
    assert is_port_free(port) is False
    s.close()
