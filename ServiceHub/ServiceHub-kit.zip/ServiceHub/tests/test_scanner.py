import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))
import scanner


def _make_web_app(root: Path, name: str, port: int):
    d = root / name
    d.mkdir(parents=True)
    (d / 'package.json').write_text('{"scripts":{"dev":"vite"}}', encoding='utf-8')
    (d / f'시작 {port}.bat').write_text(
        f'@echo off\ncd /d "%~dp0"\nstart http://localhost:{port}\nnpm run dev\n',
        encoding='utf-8')
    return d


def _make_task_app(root: Path, name: str):
    d = root / name
    d.mkdir(parents=True)
    (d / 'auto_apply.py').write_text('print("run")', encoding='utf-8')
    (d / '실행.bat').write_text('python auto_apply.py', encoding='utf-8')
    return d


def test_scan_finds_web_service(tmp_path):
    _make_web_app(tmp_path, 'KeyDesk', 3040)
    found = scanner.scan_root(tmp_path, root_label='프로젝트/for_Local')
    svc = next(s for s in found if s['name'] == 'KeyDesk')
    assert svc['type'] == 'web'
    assert svc['intended_port'] == 3040
    assert svc['command'] == 'npm run dev'
    assert svc['id'].endswith('keydesk')


def test_scan_finds_task_service(tmp_path):
    _make_task_app(tmp_path, 'gangnam-bot')
    found = scanner.scan_root(tmp_path, root_label='에이전트')
    svc = next(s for s in found if s['name'] == 'gangnam-bot')
    assert svc['type'] == 'task'
    assert svc['intended_port'] is None


def test_node_worker_without_web_dep_is_task(tmp_path):
    # package.json + start 가 있어도 웹 의존성이 없으면 포트 없는 task로 분류
    d = tmp_path / '9.회의록작성'
    d.mkdir(parents=True)
    (d / 'package.json').write_text(
        '{"scripts":{"start":"node watcher.js"},'
        '"dependencies":{"chokidar":"^3","@notionhq/client":"^5"}}',
        encoding='utf-8')
    (d / 'watcher.js').write_text('// watcher', encoding='utf-8')
    found = scanner.scan_root(tmp_path, root_label='프로젝트/for_Local')
    svc = next(s for s in found if s['name'] == '9.회의록작성')
    assert svc['type'] == 'task'
    assert svc['intended_port'] is None
    assert svc['command'] == 'npm start'


def test_node_with_web_dep_is_web(tmp_path):
    d = tmp_path / 'cshub'
    d.mkdir(parents=True)
    (d / 'package.json').write_text(
        '{"scripts":{"start":"node server.js"},"dependencies":{"express":"^4"}}',
        encoding='utf-8')
    found = scanner.scan_root(tmp_path, root_label='프로젝트/for_Local')
    svc = next(s for s in found if s['name'] == 'cshub')
    assert svc['type'] == 'web'


def test_python_tray_app_with_src_layout(tmp_path):
    # 루트엔 .py 없고 src/main.py + requirements.txt + 시작.vbs 인 트레이앱
    d = tmp_path / 'AutoUnzipper'
    (d / 'src').mkdir(parents=True)
    (d / 'src' / 'main.py').write_text('print("run")', encoding='utf-8')
    (d / 'requirements.txt').write_text('psutil\n', encoding='utf-8')
    (d / '시작.vbs').write_text('run', encoding='utf-8')
    found = scanner.scan_root(tmp_path, root_label='프로젝트/for_Local')
    svc = next(s for s in found if s['name'] == 'AutoUnzipper')
    assert svc['type'] == 'task'
    assert svc['command'] == 'python src/main.py'
    assert svc['intended_port'] is None


def test_python_task_with_only_sijak_bat(tmp_path):
    # .py + '시작.bat'만 있는 python 워커(포트 없음)도 task로 잡혀야 함
    # (claude-telegram-bridge 처럼 실행.bat/requirements.txt/시작.vbs 없는 경우)
    d = tmp_path / 'claude-telegram-bridge'
    d.mkdir(parents=True)
    (d / 'bridge.py').write_text('print("run")', encoding='utf-8')
    (d / '시작.bat').write_text(
        '@echo off\nset TOKEN=x\npython "%~dp0bridge.py"\npause', encoding='utf-8')
    found = scanner.scan_root(tmp_path, root_label='프로젝트/for_Local')
    svc = next(s for s in found if s['name'] == 'claude-telegram-bridge')
    assert svc['type'] == 'task'
    assert svc['command'] == 'python "%~dp0bridge.py"'
    assert svc['intended_port'] is None


def test_python_tray_app_launched_via_start_pythonw(tmp_path):
    # 시작.bat이 'start "" pythonw "%~dp0tray.py"'로 트레이앱을 띄우는 경우.
    # bat 명령은 못 잡지만 진입점 tray.py로 'python tray.py'를 구성해 task로 잡혀야 함
    d = tmp_path / 'claude-telegram-bridge'
    d.mkdir(parents=True)
    (d / 'bridge.py').write_text('print("bridge")', encoding='utf-8')
    (d / 'tray.py').write_text('print("tray")', encoding='utf-8')
    (d / '시작.bat').write_text(
        '@echo off\nset TOKEN=x\nstart "" pythonw "%~dp0tray.py"', encoding='utf-8')
    found = scanner.scan_root(tmp_path, root_label='프로젝트/for_Local')
    svc = next(s for s in found if s['name'] == 'claude-telegram-bridge')
    assert svc['type'] == 'task'
    assert svc['command'] == 'python tray.py'
    assert svc['intended_port'] is None


def test_static_http_server_via_start_wrapped_bat(tmp_path):
    # pkg/py 없는 정적사이트. 'start "제목" python -m http.server N' 래핑을 해제해
    # web으로 잡고 포트도 추출해야 함 (고방-광고상품 패턴)
    d = tmp_path / '고방-광고상품'
    d.mkdir(parents=True)
    (d / 'index.html').write_text('<html></html>', encoding='utf-8')
    (d / '시작 8080.bat').write_text(
        '@echo off\nchcp 65001 >nul\ncd /d "%~dp0"\n'
        'start "고방광고 로컬서버" python -m http.server 8080 --bind 127.0.0.1\n'
        'timeout /t 2 /nobreak >nul\nstart "" http://localhost:8080\n',
        encoding='utf-8')
    found = scanner.scan_root(tmp_path, root_label='프로젝트/for_Release')
    svc = next(s for s in found if s['name'] == '고방-광고상품')
    assert svc['type'] == 'web'
    assert svc['intended_port'] == 8080
    assert svc['command'] == 'python -m http.server 8080 --bind 127.0.0.1'


def test_static_serve_via_nonstandard_bat_name(tmp_path):
    # bat 이름이 '시작*'이 아니어도(랜딩페이지 열기.bat) 정적 서버를 web으로 발견
    # 'npx serve -p N .' (네이버 블로그 제작 요청 앱 패턴)
    d = tmp_path / '네이버앱'
    d.mkdir(parents=True)
    (d / 'index.html').write_text('<html></html>', encoding='utf-8')
    (d / '랜딩페이지 열기.bat').write_text(
        '@echo off\ncd /d "%~dp0"\n'
        'start "" "http://localhost:4321/landing/"\nnpx serve -p 4321 .\n',
        encoding='utf-8')
    found = scanner.scan_root(tmp_path, root_label='프로젝트/for_Release')
    svc = next(s for s in found if s['name'] == '네이버앱')
    assert svc['type'] == 'web'
    assert svc['intended_port'] == 4321
    assert svc['command'] == 'npx serve -p 4321 .'


def test_node_server_in_subdir_via_cd(tmp_path):
    # 실제 서버가 하위 폴더(landing/)에 있고 bat이 cd 후 'node server.js'.
    # 포트는 같은 하위 폴더의 '시작 NNNN.bat' 파일명에서 보충 (빌리투어-상품화 패턴)
    d = tmp_path / '빌리투어-상품화'
    (d / 'landing').mkdir(parents=True)
    (d / 'index.html').write_text('<html></html>', encoding='utf-8')
    (d / 'landing' / 'server.js').write_text('// server', encoding='utf-8')
    (d / 'landing' / '시작 5600.bat').write_text('node server.js', encoding='utf-8')
    (d / '랜딩페이지 열기.bat').write_text(
        '@echo off\nchcp 65001\ncd /d "%~dp0\\landing"\nnode server.js\n',
        encoding='utf-8')
    found = scanner.scan_root(tmp_path, root_label='프로젝트/for_Release')
    svc = next(s for s in found if s['name'] == '빌리투어-상품화')
    assert svc['type'] == 'web'
    assert svc['intended_port'] == 5600
    assert svc['command'] == 'cd /d "landing" && node server.js'


def test_npm_app_in_nested_subdir_via_cd(tmp_path):
    # 실제 vite 앱이 동명 중첩 하위 폴더에 있고 bat이 cd 후 'npm run dev'.
    # 포트는 bat의 localhost:N 에서 추출 (youth-housing-diagnosis 패턴)
    d = tmp_path / 'youth-housing-diagnosis'
    nested = d / 'youth-housing-diagnosis'
    nested.mkdir(parents=True)
    (nested / 'package.json').write_text('{"scripts":{"dev":"vite"}}', encoding='utf-8')
    (d / '시작 5200.bat').write_text(
        '@echo off\ncd /d "%~dp0youth-housing-diagnosis"\n'
        'start http://localhost:5200\nnpm run dev\npause\n', encoding='utf-8')
    found = scanner.scan_root(tmp_path, root_label='프로젝트/for_Drop')
    svc = next(s for s in found if s['name'] == 'youth-housing-diagnosis')
    assert svc['type'] == 'web'
    assert svc['intended_port'] == 5200
    assert svc['command'] == 'cd /d "youth-housing-diagnosis" && npm run dev'


def test_plain_folder_with_unrelated_bat_stays_folder(tmp_path):
    # 빌드/설치용 bat만 있고 서버 기동이 없으면 web으로 오분류하지 말 것
    d = tmp_path / 'just-tools'
    d.mkdir()
    (d / 'build.bat').write_text('@echo off\nnpm run build\n', encoding='utf-8')
    found = scanner.scan_root(tmp_path, root_label='프로젝트/for_Local')
    svc = next(s for s in found if s['name'] == 'just-tools')
    assert svc['type'] == 'folder'


def test_servicehub_itself_listed_as_folder(tmp_path):
    # 매니저 자신도 목록에 노출하되, 실행/중지로 자기 자신을 죽이지 않도록 folder로만
    (tmp_path / 'ServiceHub' / 'src').mkdir(parents=True)
    (tmp_path / 'ServiceHub' / 'src' / 'main.py').write_text('x', encoding='utf-8')
    (tmp_path / 'ServiceHub' / 'requirements.txt').write_text('x', encoding='utf-8')
    found = scanner.scan_root(tmp_path, root_label='프로젝트/for_Local')
    svc = next(s for s in found if s['name'] == 'ServiceHub')
    assert svc['type'] == 'folder'
    assert svc['command'] is None


def test_vitest_dep_not_misread_as_web(tmp_path):
    # 'vite' 부분문자열이 'vitest'에 걸려 워커가 web으로 오분류되면 안 됨
    d = tmp_path / 'naver-blog-auto'
    d.mkdir(parents=True)
    (d / 'package.json').write_text(
        '{"scripts":{"start":"ts-node src/main.ts"},'
        '"dependencies":{"playwright":"^1","chokidar":"^5"},'
        '"devDependencies":{"vitest":"^4","ts-node":"^10"}}',
        encoding='utf-8')
    (d / 'src').mkdir()
    (d / 'src' / 'main.ts').write_text('// x', encoding='utf-8')
    found = scanner.scan_root(tmp_path, root_label='에이전트')
    svc = next(s for s in found if s['name'] == 'naver-blog-auto')
    assert svc['type'] == 'task'


def test_plain_folder_registered_as_folder(tmp_path):
    # 실행 대상이 아닌 일반 폴더도 'folder' 타입으로 등록되어야 함
    d = tmp_path / 'just-docs'
    d.mkdir()
    (d / 'README.md').write_text('hi', encoding='utf-8')
    found = scanner.scan_root(tmp_path, root_label='프로젝트/for_Local')
    svc = next(s for s in found if s['name'] == 'just-docs')
    assert svc['type'] == 'folder'
    assert svc['port'] is None


def test_hidden_folder_excluded(tmp_path):
    (tmp_path / '.cache').mkdir()
    found = scanner.scan_root(tmp_path, root_label='r')
    assert all(s['name'] != '.cache' for s in found)


def test_scan_skips_excluded_dirs(tmp_path):
    (tmp_path / 'node_modules' / 'x').mkdir(parents=True)
    (tmp_path / '.git').mkdir()
    found = scanner.scan_root(tmp_path, root_label='r')
    assert all(s['name'] not in ('node_modules', '.git', 'x') for s in found)


def test_scan_missing_root_returns_empty(tmp_path):
    assert scanner.scan_root(tmp_path / 'nope', root_label='r') == []


# ── 온보딩 미리보기(preview_candidates) ──
def test_preview_flat_repo_recommends_folder_itself(tmp_path):
    # 서비스가 루트레포 직속에 바로 있는 평평한 구조
    _make_web_app(tmp_path, 'app-a', 3060)
    _make_task_app(tmp_path, 'worker-b')
    cands = scanner.preview_candidates(tmp_path)
    top = cands[0]
    assert top['path'] == str(tmp_path)
    assert '직속' in top['label']
    assert top['count'] == 2 and top['recommended'] is True


def test_preview_categorized_repo_recommends_subfolders(tmp_path):
    # 카테고리 하위폴더 안에 서비스가 있는 구조(사용자 모노레포와 동일)
    _make_web_app(tmp_path / 'for_Local', 'app-a', 3060)
    _make_web_app(tmp_path / 'for_Release', 'app-b', 3061)
    (tmp_path / 'docs').mkdir()
    cands = scanner.preview_candidates(tmp_path)
    by = {c['label']: c for c in cands}
    assert by['for_Local']['count'] == 1 and by['for_Local']['recommended']
    assert by['for_Release']['count'] == 1 and by['for_Release']['recommended']
    assert by['docs']['count'] == 0 and by['docs']['recommended'] is False


def test_preview_bad_path_returns_empty():
    assert scanner.preview_candidates(Path('C:/no/such/dir/x')) == []
