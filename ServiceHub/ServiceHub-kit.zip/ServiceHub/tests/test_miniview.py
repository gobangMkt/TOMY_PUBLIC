import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

import miniview


def test_bottom_right_basic():
    # 작업영역 1920x1040, 창 330x440, 여백 16 → 우하단
    x, y = miniview.bottom_right(330, 440, 1920, 1040, margin=16)
    assert x == 1920 - 330 - 16
    assert y == 1040 - 440 - 16


def test_bottom_right_clamps_to_zero():
    # 창이 화면보다 크면 음수 대신 0
    x, y = miniview.bottom_right(2000, 2000, 1280, 720, margin=16)
    assert x == 0
    assert y == 0
