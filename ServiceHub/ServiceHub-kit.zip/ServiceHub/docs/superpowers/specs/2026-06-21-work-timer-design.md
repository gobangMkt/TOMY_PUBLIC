# ServiceHub 업무 타이머 + 대시보드 바로가기 + 팝업 상단부 리디자인

작성일: 2026-06-21

## 개요

ServiceHub에 RoutineLog 운동 타이머와 동일한 방식의 **전역 업무 타이머**를 추가하고,
미니 팝업 상단부를 키컬러 진한 블록으로 재구성하며, 팝업에 대시보드 바로가기를 추가한다.

세 가지 변경:
1. **업무 타이머** — 대시보드·팝업 양쪽에서 시작/종료, 진행 중 경과시간 표시(최소화 때도)
2. **대시보드 바로가기** — 팝업 헤더에서 브라우저로 대시보드(localhost) 열기
3. **팝업 상단부 리디자인** — 헤더+타이머바+게이지를 딥바이올렛 한 덩어리(흰 텍스트)로

## 1. 업무 타이머 — 동작 스펙

RoutineLog 헬스로그 운동 타이머와 동일한 원리: **시작 시각(절대 ISO)만 저장하고 경과는 `now - started_at`로 매초 계산**.

### 상태 모델 (config.json `work_timer`)

```json
"work_timer": {
  "started_at": "2026-06-21T09:00:00+09:00" 또는 null,
  "today_date": "2026-06-21",
  "today_seconds": 11520
}
```

- `started_at`: 진행 중이면 시작 절대시각(ISO, 로컬 TZ), 정지 상태면 `null`.
- `today_date`: `today_seconds`가 가리키는 날짜(YYYY-MM-DD).
- `today_seconds`: 그날 **종료된 세션들의 누적 초**(진행 중 경과는 미포함).

### 라이프사이클

- **시작**: `started_at = now`. 단 `today_date != 오늘`이면 먼저 `today_seconds = 0`, `today_date = 오늘`로 롤오버.
- **경과시간(진행 중)** = `now - started_at`. 클라가 1초 주기로 다시 계산해 표시(HH:MM:SS 또는 MM:SS).
- **종료**: `today_seconds += (now - started_at)`, `started_at = null`.
- **오늘 누적 표시** = `today_seconds + (진행 중이면 경과, 아니면 0)`, 포맷 "N시간 M분".
- **일시정지 없음** (RoutineLog 동일).

### 초기화 시점

- 경과시간 0으로: **[종료]** 누를 때.
- `today_seconds` 0으로: **자정**(날짜 키 롤오버) — 새 날 첫 시작/조회 시 리셋.

### 가드 (켜둔 채 깜빡한 경우)

서버가 조회(`GET /api/timer`)·주기 폴러(기존 2분 usage 폴러에 합류) 시점에 reconcile:

- **자정 자동 종료**: 진행 중인데 `started_at`의 날짜 < 오늘 → 그날 자정에 종료된 것으로 처리.
  자정 이전 몫은 (보관하지 않는 전날이므로) 버리고, `started_at = null`, 새 날 `today_seconds = 0`. 새 날은 정지 상태에서 시작.
- **12시간 가드**: 진행 중 경과가 12시간 초과 → 자동 종료. `today_seconds += 12h`(상한), `started_at = null`,
  `auto_stopped: "long_run"` 플래그를 1회 브로드캐스트 → 클라가 배너 "장시간 감지로 자동 종료됨" 표시.

## 2. 백엔드 (FastAPI)

`src/timer.py` 신설 (순수 로직, config 읽기/쓰기 + reconcile). `src/server.py`에 라우트 추가.

### API

| 메서드 | 경로 | 동작 | 응답 |
|---|---|---|---|
| GET | `/api/timer` | reconcile 후 현재 상태 | `TimerState` |
| POST | `/api/timer/start` | 시작(롤오버 포함) | `TimerState` |
| POST | `/api/timer/stop` | 종료(누적 합산) | `TimerState` |

`TimerState`:
```json
{ "running": true, "started_at": "…ISO…", "elapsed_seconds": 4980,
  "today_seconds": 16500, "today_date": "2026-06-21", "auto_stopped": null }
```
- `elapsed_seconds`: 서버 계산값(클라 초기 동기화·검증용). 클라는 이후 started_at 기준 자체 카운트.
- `auto_stopped`: `"long_run"` | `"midnight"` | `null` (직전 자동종료 사유, 배너용. 조회 1회 후 클리어).

### WebSocket

- 새 kind `'timer'`, payload = `TimerState`.
- start/stop/자동종료 시 `broadcast(None, 'timer', state)`로 전 클라 동기화.
- 주기 폴러가 reconcile 결과 변화(자동종료 발생) 시에도 브로드캐스트.

## 3. 프론트 — 팝업(mini)

### 상단부 구조 (`mini.html`)

`.m-top` 컨테이너로 **헤더 + 타이머바 + 게이지**를 감싸 딥바이올렛 배경·흰 텍스트.

```
.m-top  (background: 딥바이올렛, color: #fff)
  .m-head     ← ServiceHub · 가동수 · [대시][검색][재스캔][최소화][닫기]
  .m-timer    ← ● 업무중 01:23:45 · 오늘 3:12   [종료]   (정지 시 ▶ 업무 시작)
  .m-usage    ← 현재/전체/Sonnet 게이지 (흰 트랙·흰 텍스트)
.m-search (토글)
.m-list  (밝은 목록 — 기존 톤)
```

- **대시보드 바로가기**: 헤더에 아이콘 버튼 추가 → `pywebview.api.open_url('http://' + location.host + '/')` (대시보드를 외부 브라우저로). 새 pywebview API 불필요(기존 `open_url` 재사용).
- **타이머 바**: 진행 중 `● 업무중 HH:MM:SS · 오늘 N시간 M분 [종료]`, 정지 `▶ 업무 시작`. 1초 setInterval로 경과 갱신.

### 최소화(collapsed)

미니바에 **경과시간 + 가동수**가 항상 보이도록.

```
collapsed:  ● 01:23:45   3/37   [▲][x]
```
- 진행 중: `● HH:MM:SS`(맥동 점). 정지: 점 흐림 + 가동수만(`3/37`).
- 기존 `body.collapsed` 규칙 수정: `.m-timer`의 경과·`.m-count`는 보이고, 제목·게이지·검색·목록은 숨김.
- collapsed 폭(현재 210 논리폭) 안에서 `01:23:45  3/37  [▲][x]`가 들어가도록 미니바 레이아웃 조정.

### 스타일

- 딥바이올렛 솔리드 배경(그라데이션 금지). 라이트 테마 토큰에 `--top-bg`(예: `#5b3fd1`/`#4a2fb8` 계열), `--top-text: #fff`, `--top-muted: rgba(255,255,255,.7)` 추가.
- 게이지 트랙은 반투명 흰색, 채움은 흰색/밝은 톤. 안티클리셰: border-left 액센트·pill 남발·과한 라운딩 금지.

## 4. 프론트 — 대시보드(메인)

- **타이머 칩**: 헤더 우측 액션들 앞에 칩. 진행 중 `● 업무중 01:23:45 · 오늘 3:12 [종료]`, 정지 `▶ 업무 시작`.
- 1초 setInterval 경과 갱신, `/api/timer` 초기 로드 + WS `'timer'` 구독.
- 자동종료 배너(`auto_stopped`): 기존 토스트(`showToast`) 재사용.
- 대시보드 테마(Violet Night, 다크)는 유지 — 칩만 추가. (팝업 리디자인은 팝업에만)

## 5. 공통 클라 로직

`elapsed`/`today` 계산·포맷 함수는 app.js·mini.js 각각에 두되 동일 규칙:
- `fmtElapsed(ms)` → `H:MM:SS` (1시간↑) / `MM:SS`.
- `fmtToday(sec)` → "N시간 M분" / "M분".
- WS `'timer'` 수신 시 상태 교체 후 즉시 렌더, 진행 중이면 로컬 틱 계속.

## 6. 테스트

- `tests/test_timer.py` (신설): start→stop 누적, 날짜 롤오버 리셋, 자정 진행중 자동종료, 12시간 가드 자동종료+플래그, 정지 상태 조회 멱등.
- 기존 회귀 테스트(`test_supervisor.py` 등) 영향 없음 확인.
- 프론트: 팝업/대시보드/최소화 상태 Playwright 시각 검증.

## 7. 영향 파일

- 신설: `src/timer.py`, `tests/test_timer.py`, `docs/.../2026-06-21-work-timer-design.md`(본 문서)
- 수정: `src/server.py`(라우트·WS·폴러), `config.json`(work_timer 기본값), `static/mini.html`·`mini.css`·`mini.js`, `static/index.html`·`style.css`·`app.js`, `CLAUDE.md`(타이머 정책 1줄), `README.md`

## 8. 비목표 (YAGNI)

- 과거 날짜별 업무시간 히스토리/리포트 (오늘 누적만).
- 서비스별 타이머.
- 일시정지/수동 시간 편집.
- 유휴(절전) 자동 감지 — 12시간 가드로 갈음.
