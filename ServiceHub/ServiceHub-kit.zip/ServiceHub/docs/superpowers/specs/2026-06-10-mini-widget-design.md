# ServiceHub 미니 위젯 설계

작성일: 2026-06-10

## 목적

풀 대시보드(localhost:3050)는 그대로 두고, 화면 우하단에 **항상-위 작은 위젯 창**을
트레이로 켜고/끄며 서비스 현황을 빠르게 보고 시작/중지한다.

## 동작

- 트레이 메뉴에 **"미니뷰"** 항목 추가 → 클릭으로 미니 창 표시/숨김 토글
- 미니 창: 프레임리스, 항상-위(on_top), 우하단 고정, 약 320×420
- 내용: 가동 N/전체 카운트 + 루트별 서비스 목록, 각 행에 상태점 + ▶/■ 버튼
- 기존 `/api/services`·`/ws` 재사용 → 실시간 상태·시작/중지

## 컴포넌트 (각 단일 책임)

| 파일 | 역할 | 의존 |
|---|---|---|
| `static/mini.html` + `mini.js` + `mini.css` | 컴팩트 위젯 UI. 기존 API/WS 소비 | `/api/services`, `/ws` |
| `src/server.py` | `GET /mini` 라우트 추가 (mini.html 서빙, 캐시버스팅) | 기존 앱 |
| `src/miniview.py` (신규) | pywebview 창 생성·show/hide 토글·우하단 좌표 계산(ctypes user32) | pywebview |
| `src/tray.py` | 메뉴 "미니뷰" 항목 + 토글 콜백 | miniview |
| `src/main.py` | 트레이 `run_detached` + pywebview 메인 스레드 `start`로 흐름 재배치 | 위 전부 |
| `requirements.txt` | `pywebview` 추가 | — |

## 데이터 흐름

미니 창(WebView2)
  → fetch `/api/services` 폴링 + `/ws` 구독으로 상태 표시
  → ▶ 클릭 시 `POST /api/services/{id}/start|run`, ■ 클릭 시 `POST /api/services/{id}/stop`

백엔드 비즈니스 로직 추가 없음. 기존 엔드포인트 재사용.

## 스레드 구조 (핵심 변경)

pywebview·pystray 모두 메인 스레드를 요구 → 충돌. 해소:

1. uvicorn 서버: 데몬 스레드 (기존과 동일)
2. pystray 트레이: `icon.run_detached()` 로 백그라운드
3. pywebview: 메인 스레드에서 `webview.start()` (GUI 이벤트 루프, 블로킹)
   - 미니 창은 `create_window(hidden=True, on_top=True, frameless=True, x, y)` 로 미리 생성
   - 토글은 `window.show()` / `window.hide()`
4. 종료: 미니 창 destroy → `webview` 종료 → 트레이 stop → 서버 should_exit

## 우하단 좌표 계산

ctypes `user32.GetSystemMetrics` 로 주 모니터 작업영역(SM_CXMAXIMIZED/작업표시줄 제외) 확보.
`x = work_w - win_w - margin`, `y = work_h - win_h - margin`. 멀티모니터는 주 모니터 기준.

## 에러 처리

- WebView2 런타임 미설치 → pywebview 창 생성 실패 시 트레이 알림(winotify)으로 설치 안내,
  앱은 죽지 않고 대시보드는 정상 동작
- 미니 창 강제 닫힘(X) → hide 로 동작(앱 종료 아님)

## 빌드

`build.bat` PyInstaller 옵션에 pywebview 관련 hidden-import / 데이터 포함 추가.
`static/mini.*` 가 번들에 들어가는지 확인.

## 테스트

- `server`: `GET /mini` 가 200 + mini.html 반환
- `miniview`: 우하단 좌표 계산 함수 단위 테스트(작업영역·창크기 주입 → 좌표 검증)
- pywebview 창 자체는 GUI라 수동 검증(트레이 토글로 표시/숨김, ▶/■ 동작)

## 비고

- 미니뷰는 풀 대시보드와 독립 자산(mini.*). 풀 대시보드 코드는 변경 없음.
- ServiceHub 자신은 앞선 변경으로 folder 타입이라 미니뷰에서도 시작/중지 버튼 없이 노출.
