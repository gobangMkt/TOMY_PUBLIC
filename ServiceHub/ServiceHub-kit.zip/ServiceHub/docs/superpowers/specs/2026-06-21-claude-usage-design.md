# Claude 사용량 표시 — 설계 (Design Spec)

작성일: 2026-06-21
대상: ServiceHub (로컬 서비스 통합 관리 허브)

## 1. 목적

내 Claude 계정 사용량을 ServiceHub 대시보드와 미니뷰(팝업)에 함께 표시한다.
두 종류의 데이터를 보여준다.

- **한도 소진율 %** — claude.ai 설정 > 사용량 화면과 동일한 현재 세션 / 주간(모든 모델) / 주간(Sonnet) 비율.
- **로컬 토큰 집계** — Claude Code 사용분의 일별 토큰 추이·모델별 분포·누적 총계(+비용 추정치).

## 2. 데이터 소스 (검증 완료)

### 2.1 한도 % — OAuth usage 엔드포인트

- `GET https://api.anthropic.com/api/oauth/usage`
- 헤더: `Authorization: Bearer <accessToken>`, `anthropic-version: 2023-06-01`, `anthropic-beta: oauth-2025-04-20`, `User-Agent: claude-cli/1.0`
- 토큰 출처: `~/.claude/.credentials.json` → `claudeAiOauth.accessToken` (`expiresAt`, `refreshToken` 동거)
- **검증**: HTTP 200, 응답에 `five_hour.utilization`, `seven_day.utilization`, `seven_day_sonnet.utilization`, 각 `resets_at`, 그리고 정규화된 `limits[]`(kind/group/percent/severity/resets_at/is_active) 포함 확인.
- **권장 파싱**: `limits[]` 배열 사용(kind: `session` / `weekly_all` / `weekly_scoped`).
- 비공식 내부 엔드포인트 — 언제든 변경/중단될 수 있음을 전제로 graceful 처리(아래 5장).

### 2.2 로컬 토큰 — stats-cache 단일 소스

`~/.claude/stats-cache.json` 한 파일로 전부 해결(jsonl 직접 파싱 불필요). Claude Code가 주기적으로 갱신하며 `lastComputedDate`로 기준일을 알 수 있다.

- 누적 총계: `modelUsage.<model>.{inputTokens,outputTokens,cacheReadInputTokens,cacheCreationInputTokens}`, `totalSessions`, `totalMessages`.
- 일별·모델별: `dailyModelTokens` = `[{date, tokensByModel: {<model>: tokens}}]`.
- 일별 활동: `dailyActivity` = `[{date, messageCount, sessionCount, toolCallCount}]`.
- 범위: 최근 14일로 잘라 표시(기본값). 데이터 기준일은 `lastComputedDate`(최근 1~2일 지연 가능 — "기준일" 라벨로 표기).

> jsonl 증분 파싱은 범위 밖(YAGNI). stats-cache 갱신 지연이 문제가 되면 별도 슬라이스로 보강.

## 3. 백엔드 (FastAPI)

### 3.1 새 모듈 `src/usage.py`

- `fetch_limits() -> LimitsResult`
  - credentials 읽어 usage 호출, `limits[]` 정규화: `{session, weekly_all, weekly_scoped}` 각 `{percent, resets_at, severity}`.
  - 실패 시 `{ok: False, reason}` (만료/401/네트워크 구분), 마지막 성공값은 호출자(폴러)가 보관.
- `local_stats() -> LocalStats`
  - stats-cache.json 읽어 totals + daily[](최근 14일) + byModel[] 반환. 단일 파일 읽기라 가벼움(증분 캐시 불필요).
- `cost_estimate(by_model) -> dict`
  - 모델별 단가표 × 토큰. 구독제라 실제 청구는 0 → "참고용($)" 라벨. 단가표는 claude-api 기준 상수로 보관.
- 인증/만료 정책:
  - `expiresAt`가 과거면 호출 생략하고 `needs_login` 반환(자동 refresh는 후순위 옵션, 1차 범위 밖).

### 3.2 라우트

- `GET /api/usage` (server.py:171 `rescan` 뒤에 추가)
  - 응답: `{ limits: {...}|null, local: {totals, daily[], byModel[], cost}, status: 'ok'|'needs_login'|'stale'|'no_credentials', updatedAt }`

### 3.3 실시간 푸시

- 백그라운드 폴러: **2분 주기** `fetch_limits()` → 변경 시 WebSocket `broadcast(sid=None, kind='usage', payload=limits)`.
- 로컬 stats: `/api/usage` 요청 시 계산 + 5분 캐시(폴링까지는 불필요).
- 클라 `/ws` 리스너에 `kind === 'usage'` 분기 추가 → 게이지/칩 갱신.

## 4. 프론트엔드

차트 라이브러리 미설치 유지. 기존 SVG 손그림 패턴(도넛=`<circle>` dasharray, 스파크라인=`<path>`) 재사용. 안티-클리셰 준수(보라 그라데이션·pill 남발·과한 라운딩 금지).

### 4.1 대시보드 (`static/index.html` + `app.js` + `style.css`)

- 배치: **Overview 섹션 위에 독립 "Claude 사용량" 접이식 섹션 신설**.
- 구성:
  - 게이지 3종(세션 / 주간 모든모델 / 주간 Sonnet) — % + 리셋까지 남은 시간.
  - 일별 토큰 추이 — 막대(최근 14일).
  - 모델별 분포 — 도넛(기존 상태 도넛과 동일 패턴).
  - 누적 총계 칩 — 총 토큰 · 총 세션 · 총 메시지 · 비용추정($, 참고용).

### 4.2 미니뷰 (`static/mini.html` + `mini.js` + `mini.css`)

- 배치: **상단에 사용량 영역을 별도 섹션으로 구분**, 그 아래 기존 서비스 목록.
- 구성: 컴팩트 게이지 3종 + **현재 세션은 작은 한 줄로 최소화 표기**.

## 5. 에러 처리

| 상황 | 동작 |
|------|------|
| 토큰 만료 / 401 | 사용량 섹션에 "재로그인 필요" 배지. **로컬 토큰 그래프는 계속 표시**. |
| usage API 실패(네트워크/5xx) | 마지막 성공값 + "stale(N분 전)" 표시. |
| `.credentials.json` 없음 | 한도 섹션 "연결 안 됨" 안내. 로컬 그래프는 표시. |
| jsonl 파싱 일부 실패 | 해당 라인 skip, 나머지 집계 진행(견고성). |

## 6. 테스트

- `tests/test_usage.py`
  - `limits[]` 파싱: fixture JSON → 세션/주간/Sonnet 정규화 검증.
  - jsonl 집계: fixture jsonl → 일별/모델별 토큰 합계 검증, 비-assistant 라인 무시 검증.
  - 비용 계산: 단가표 × 토큰 검증.
  - 증분 캐시: mtime 미변경 시 재파싱 생략 검증.
  - usage HTTP 호출은 **mock**(실 네트워크 의존 금지). 만료/401/네트워크실패 분기 검증.

## 7. 범위 밖 (YAGNI)

- OAuth 토큰 자동 refresh (1차는 만료 시 재로그인 안내만).
- claude.ai 웹 대화분 토큰(로컬에 없음) 집계.
- 사용량 알림/임계 경고(추후 별도 슬라이스 가능).
- 기간 사용자 지정 UI(기본 14일 고정).

## 8. 보안/규약 메모

- usage 엔드포인트는 비공식·미문서. 로컬 개인 대시보드 용도로만 사용(외부 노출·재배포 없음).
- 토큰 값은 로그·응답·UI 어디에도 출력하지 않는다(헤더로만 사용).
