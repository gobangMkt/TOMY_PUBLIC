# ServiceHub — 로컬 서비스 통합 관리 허브 설계

## Context
내가 만든 로컬 서비스가 7~13개로 늘면서 두 가지가 불편하다.
1. 각 앱을 `시작 {포트}.bat`으로 따로 띄우면 **cmd 창이 난립**한다.
2. 포트가 겹쳐(예: `0.CS도움앱`·`인스타자동화` 둘 다 3017) **충돌로 동시에 못 띄운다.**

목표: 트레이에 상주하는 단일 매니저에서 모든 로컬 서비스를 **창 없이 시작/중지하고, 실시간 상태·로그를 보고, 포트를 자동 조율**한다. 포트 번호 자체는 신경 쓰고 싶지 않다.

## 핵심 결정
- **스택**: Python 3 + FastAPI/uvicorn(대시보드·API·WebSocket) + pystray·Pillow(트레이) + winotify(알림) + psutil(프로세스/포트). → AutoUnzipper의 검증된 트레이 exe 파이프라인(`tray.py`/`notifier.py`/`build.bat`/PyInstaller) 재사용.
- **대시보드**: FastAPI가 서빙하는 단일 HTML/JS 페이지(빌드 단계 없음). WebSocket으로 실시간 갱신.
- **매니저 포트**: 3050 고정.
- **서비스 목록**: 다중 루트 자동 스캔 + config 수동 오버라이드.
- 리버스 프록시는 **불필요**(YAGNI) — 단일 URL이 목표가 아니라 창 난립·충돌 제거가 목표.

## 컴포넌트 (각자 단일 책임)

### scanner (`src/scanner.py`)
- `config.json`의 `roots` 배열을 순회하며 각 1단계 하위 폴더를 검사.
- 제외: `node_modules`, `.claude/worktrees`, `.git`, `__pycache__`, `dist`, `build`.
- 각 폴더에서 타입·기동명령·의도 포트를 추론:
  - `package.json`에 `dev`/`start` 스크립트 → **web** 타입, 기동명령 = `npm run dev`(없으면 `npm start`).
  - 폴더 내 `시작 *.bat` 파싱 → `start http://localhost:(\d+)` 로 **의도 포트** 추출, `npm`/`node`/`call` 라인으로 기동·셋업 명령 추출.
  - `package.json` 없고 `*.py` + `실행.bat` 또는 `requirements.txt` → **task** 타입(일회성), 기동명령 = bat 또는 `python <entry>.py`.
- 결과: `DiscoveredService{ id, name, root, path, type, command, setup_cmd, intended_port }` 리스트.

### registry (`src/registry.py`)
- 자동발견 결과 + `config.json`의 `overrides`(서비스 id별 port/name/command/type/enabled) 병합.
- **포트 배정**: web 서비스에 유니크 포트 부여. 의도 포트가 비충돌이면 유지, 충돌하면 3060+ 풀에서 다음 빈 포트 할당. **배정 결과를 `config.json`에 영속화**해 재시작 후에도 안정.
- 조회 API: `list()`, `get(id)`.

### supervisor (`src/supervisor.py`)
- `start(id)`: 시작 전 포트 LISTEN 검사(점유 시 에러). 자식 프로세스를 **`CREATE_NO_WINDOW`** 로 spawn, `cwd`=서비스 path, 환경변수 `PORT` 주입. stdout/stderr를 **링버퍼(최근 N줄) + 로그파일**(`logs/<id>.log`)로 캡처. setup_cmd 있으면 먼저 동기 실행.
- `stop(id)`: psutil로 **프로세스 트리 전체 kill**(자식 npm→node 포함).
- `status(id)`: `stopped` / `starting` / `running`(프로세스 생존 + 포트 LISTEN) / `error` / `exited`(task 정상 종료).
- task 타입: `run(id)`는 1회 구동, 종료 코드까지 출력 캡처 후 `exited`로.

### dashboard (`src/server.py` + `static/`)
- FastAPI 앱. 라우트:
  - `GET /` → 단일 페이지.
  - `GET /api/services` → registry 목록 + 상태.
  - `POST /api/services/{id}/start|stop|run`.
  - `GET /api/services/{id}/logs` → 링버퍼 덤프.
  - `WS /ws` → 상태 변화·로그 라인 실시간 push.
- UI: 루트별 그룹 카드 그리드. 카드 = 이름·타입뱃지(web/task)·상태점·포트·`[시작][중지][열기][로그]`. 상단 "전체 중지". 로그는 하단 드로어에서 스트리밍.

### tray (`src/tray.py`) + 엔트리 (`src/main.py`)
- `main.py`가 uvicorn 서버를 백그라운드 스레드로 띄우고 pystray 트레이를 메인 스레드에서 run.
- 트레이 메뉴: 대시보드 열기(localhost:3050), 전체 중지, 부팅 자동실행 토글, 종료. 아이콘에 실행중 개수 표시(가능 범위).
- 종료 시 모든 자식 프로세스 정리.

## config.json 스키마
```json
{
  "manager_port": 3050,
  "port_pool_start": 3060,
  "roots": [
    "프로젝트/for_Local",
    "프로젝트/for_Release",
    "프로젝트/for_Drop",
    "에이전트"
  ],
  "log_lines": 500,
  "overrides": {
    "<service-id>": { "port": 3041, "name": "...", "command": "...", "type": "web|task", "enabled": true }
  },
  "assigned_ports": { "<service-id>": 3060 }
}
```
- `roots`는 repo 루트(`my-claude-project`) 기준 상대경로. 자유 추가/제거.
- `assigned_ports`는 매니저가 자동 기록(수동 편집 불필요).

## 데이터 흐름
트레이 기동 → scanner가 roots 스캔 → registry 병합·포트배정·config 영속화 → 대시보드 표시 → 사용자 [시작] → supervisor 포트검사 후 spawn → WebSocket으로 상태/로그 push → [중지] 트리킬.

## 에러 처리
- 포트 점유(외부 프로세스): 시작 거부 + 카드 에러배지 + winotify 알림.
- 기동 명령 실패/조기 종료: `error` 상태 + 로그에 stderr 노출.
- 스캔 실패(깨진 폴더): 해당 폴더 skip + 경고 로그, 전체 중단 안 함.

## 테스트
- `tests/` pytest: scanner(샘플 폴더 fixture로 타입·포트 추론), registry(충돌 포트 재배정·영속화), supervisor(더미 스크립트 start/stop/트리킬·포트검사).
- 수동 E2E: `시작 3050.bat` → localhost:3050에서 운동일지(3020) 시작→상태 running·[열기] 동작→로그 스트리밍 확인→중지→cmd 창 미발생 확인→충돌쌍(3017) 둘 다 시작되어 다른 포트로 뜨는지 확인.

## 배포·관례
- 위치: `프로젝트/for_Local/ServiceHub`.
- `시작 3050.bat`(관례), `시작.vbs`(창 없이 기동), `설치(첫1회만).bat`(venv+pip), `build.bat`(PyInstaller exe).
- exe는 TOMY_PUBLIC로 팀 배포(AutoUnzipper와 동일 패턴). frozen 경로 함정 주의(`sys._MEIPASS` / config는 exe 옆 외부 파일로).

## YAGNI (이번 범위 제외)
- 리버스 프록시/단일 URL, 인증, 원격 접근, 자동 재시작/헬스체크 정책, 서비스 의존성 그래프.
