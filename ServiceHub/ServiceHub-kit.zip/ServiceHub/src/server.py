import asyncio
import re as _re
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Body
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

import config as cfg_mod
import scanner
import usage


def _sync_bats(services: list) -> list:
    """각 web 서비스의 시작 {port}.bat 을 현재 배정 포트 기준으로 생성/갱신."""
    results = []
    for svc in services:
        if svc.get('type') != 'web' or not svc.get('port') or not svc.get('command'):
            continue
        path = Path(svc['path'])
        if not path.is_dir():
            continue
        cmd = svc['command'].strip()
        # 자체 bat/vbs/cmd를 호출하는 서비스는 건너뜀 (자체 실행파일 보유)
        if _re.search(r'\.(bat|vbs|cmd)\s*$', cmd, _re.I):
            continue
        port = svc['port']
        # 배정 포트 기준 실행 명령 결정
        if _re.match(r'python3?\s+-m\s+http\.server', cmd):
            run_cmd = f'python -m http.server {port}'
        elif _re.search(r'\b(run dev|pnpm dev|yarn dev)\b', cmd):
            base = _re.sub(r'\s+--\s+--port\s+\d+', '', cmd).strip()
            run_cmd = f'{base} -- --port {port}'
        else:
            run_cmd = cmd
        bat_name = f'시작 {port}.bat'
        bat_path = path / bat_name
        content = '\r\n'.join([
            '@echo off', 'chcp 65001', 'cd /d "%~dp0"',
            f'start http://localhost:{port}', run_cmd,
        ]) + '\r\n'
        # 포트 번호가 다른 구형 시작*.bat 제거
        for old in sorted(path.glob('시작*.bat')):
            if old.name != bat_name and _re.match(r'^시작\s*\d+\.bat$', old.name):
                try:
                    old.unlink()
                    results.append({'service': svc['name'], 'action': 'removed', 'bat': old.name})
                except OSError:
                    pass
        # bat 생성/갱신 (ASCII + CRLF)
        try:
            bat_path.write_bytes(content.encode('ascii'))
            results.append({'service': svc['name'], 'action': 'synced', 'bat': bat_name})
        except OSError as e:
            results.append({'service': svc['name'], 'action': 'error', 'bat': bat_name, 'note': str(e)})
    return results

_STATIC = Path(__file__).parent.parent / 'static'


class UTF8JSONResponse(JSONResponse):
    # 헤더에 charset=utf-8 명시 — 없으면 PowerShell(PS5.1) Invoke-RestMethod가 응답을
    # Latin-1로 디코딩해 한글 경로/이름이 깨진다(온보딩 API round-trip 실패 방지).
    media_type = 'application/json; charset=utf-8'


def create_app(registry, supervisor, rescan_fn, timer=None,
               cfg=None, save_fn=None, mini_toggle=None):
    app = FastAPI(title='ServiceHub', default_response_class=UTF8JSONResponse)
    clients: set[WebSocket] = set()
    loop_holder = {}

    def broadcast(sid, kind, payload):
        loop = loop_holder.get('loop')
        if not loop:
            return
        msg = {'id': sid, 'kind': kind, 'payload': payload}
        for ws in list(clients):
            asyncio.run_coroutine_threadsafe(_safe_send(ws, msg, clients), loop)

    app.state.broadcast = broadcast

    app.state.usage_cache = {'limits': None, 'status': 'init', 'updatedAt': None}

    def _usage_payload():
        c = app.state.usage_cache
        return {'limits': c['limits'], 'status': c['status'], 'updatedAt': c['updatedAt']}

    app.state.usage_payload = _usage_payload

    async def poll_usage_once():
        loop = asyncio.get_event_loop()
        res = await loop.run_in_executor(None, usage.fetch_limits)
        if res['ok']:
            app.state.usage_cache.update(limits=res['limits'], status='ok')
        else:
            app.state.usage_cache['status'] = res['reason']  # 이전 limits 유지
        app.state.usage_cache['updatedAt'] = int(time.time())
        broadcast(None, 'usage', _usage_payload())

    app.state.poll_usage_once = poll_usage_once

    @app.middleware('http')
    async def _no_cache(request, call_next):
        resp = await call_next(request)
        if request.url.path in ('/', '/mini') or request.url.path.startswith('/static'):
            resp.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        return resp

    @app.on_event('startup')
    async def _startup():
        loop_holder['loop'] = asyncio.get_event_loop()

        async def _poll_loop():
            while True:
                try:
                    await poll_usage_once()
                except Exception:
                    pass
                # 타이머 자정·12h 가드 reconcile — 자동종료 발생 시 전 클라에 통지
                if timer is not None:
                    try:
                        st = timer.get_state()
                        if st.get('auto_stopped'):
                            broadcast(None, 'timer', st)
                    except Exception:
                        pass
                await asyncio.sleep(120)
        asyncio.create_task(_poll_loop())

    def _render(page: str, assets: tuple) -> str:
        html = (_STATIC / page).read_text(encoding='utf-8')
        for asset in assets:
            try:
                v = int((_STATIC / asset).stat().st_mtime)
            except OSError:
                continue
            html = html.replace(f'/static/{asset}', f'/static/{asset}?v={v}')
        return html

    @app.get('/', response_class=HTMLResponse)
    def index():
        return _render('index.html', ('app.js', 'onboard.js', 'style.css'))

    @app.get('/mini', response_class=HTMLResponse)
    def mini():
        return _render('mini.html', ('mini.js', 'mini.css'))

    @app.get('/api/services')
    def list_services():
        # 포트 체크가 서비스마다 블로킹 → 병렬로 한 번에 (직렬이면 N×timeout 누적)
        svcs = registry.list()
        # 외부 실행 감지용 프로세스 스냅샷(cwd+명령행)은 비싸므로 1회만 계산해 공유
        idx = (supervisor.scan_index()
               if any(s.get('type') in ('web', 'task') for s in svcs) else None)
        with ThreadPoolExecutor(max_workers=16) as ex:
            statuses = list(ex.map(lambda s: supervisor.effective_status(s, idx), svcs))
        return [{**s, 'status': st} for s, st in zip(svcs, statuses)]

    @app.post('/api/services/{sid}/start')
    def start(sid: str):
        svc = registry.get(sid)
        if not svc:
            raise HTTPException(404, 'unknown service')
        supervisor.start(svc)
        return {'ok': True}

    @app.post('/api/services/{sid}/stop')
    def stop(sid: str):
        svc = registry.get(sid)
        if not svc:
            raise HTTPException(404, 'unknown service')
        supervisor.stop(sid, port=svc.get('port'), path=svc.get('path'))
        return {'ok': True}

    @app.post('/api/services/{sid}/run')
    def run(sid: str):
        svc = registry.get(sid)
        if not svc:
            raise HTTPException(404, 'unknown service')
        supervisor.start(svc)
        return {'ok': True}

    @app.get('/api/services/{sid}/logs')
    def logs(sid: str):
        if not registry.get(sid):
            raise HTTPException(404, 'unknown service')
        return {'logs': supervisor.logs(sid)}

    @app.post('/api/services/{sid}/open-claude')
    def open_claude(sid: str):
        svc = registry.get(sid)
        if not svc:
            raise HTTPException(404, 'unknown service')
        supervisor.open_claude(svc['path'])
        return {'ok': True}

    @app.post('/api/services/{sid}/open-folder')
    def open_folder(sid: str):
        svc = registry.get(sid)
        if not svc:
            raise HTTPException(404, 'unknown service')
        supervisor.open_folder(svc['path'])
        return {'ok': True}

    @app.post('/api/stop-all')
    def stop_all():
        supervisor.stop_all()
        return {'ok': True}

    @app.post('/api/sync-bats')
    def sync_bats():
        return {'results': _sync_bats(registry.list())}

    @app.post('/api/rescan')
    def rescan():
        rescan_fn()
        return {'ok': True}

    @app.get('/api/usage')
    def get_usage():
        local = usage.local_stats()
        local['cost'] = usage.cost_estimate(local.get('byModel') or [])
        # 폴러가 아직 안 돌았으면(init) 1회 동기 fetch로 초기값 확보
        if app.state.usage_cache['status'] == 'init':
            res = usage.fetch_limits()
            if res['ok']:
                app.state.usage_cache.update(limits=res['limits'], status='ok')
            else:
                app.state.usage_cache['status'] = res['reason']
        return {**_usage_payload(), 'local': local}

    @app.post('/api/usage/relogin')
    def usage_relogin():
        supervisor.trigger_claude_login()
        return {'ok': True}

    @app.get('/api/timer')
    def get_timer():
        if timer is None:
            raise HTTPException(404, 'timer disabled')
        return timer.get_state()

    @app.post('/api/timer/start')
    def timer_start():
        if timer is None:
            raise HTTPException(404, 'timer disabled')
        st = timer.start()
        broadcast(None, 'timer', st)
        return st

    @app.post('/api/timer/stop')
    def timer_stop():
        if timer is None:
            raise HTTPException(404, 'timer disabled')
        st = timer.stop()
        broadcast(None, 'timer', st)
        return st

    # ── 미니뷰 토글 (트레이 메뉴와 동일 동작을 대시보드에서) ──
    @app.post('/api/miniview/toggle')
    def miniview_toggle():
        if mini_toggle is None:
            raise HTTPException(404, 'miniview disabled')
        try:
            mini_toggle()
        except Exception as e:
            raise HTTPException(500, f'miniview toggle failed: {e}')
        return {'ok': True}

    # ── 첫 실행 온보딩: 루트레포 선택 → 스캔 root 확정 ──
    @app.get('/api/onboard/status')
    def onboard_status():
        roots = (cfg or {}).get('roots', [])
        return {
            'onboarded': cfg_mod.is_onboarded(cfg or {}),
            'roots': roots,
            'repoRoot': str(cfg_mod._REPO_ROOT),
        }

    @app.post('/api/onboard/browse')
    def onboard_browse():
        # '찾기' 버튼: 같은 PC에서 네이티브 폴더 다이얼로그(tkinter)를 별도 프로세스로 띄운다.
        # frozen exe에선 sys.executable -c 가 불가 → 빈 경로 반환(UI가 수동 입력으로 폴백).
        import subprocess
        import sys as _sys
        if getattr(_sys, 'frozen', False):
            return {'path': '', 'note': 'frozen'}
        code = ("import tkinter as tk;from tkinter import filedialog;"
                "r=tk.Tk();r.withdraw();r.attributes('-topmost',True);"
                "p=filedialog.askdirectory(title='ServiceHub - 루트레포 폴더 선택');"
                "print(p or '')")
        try:
            out = subprocess.run([_sys.executable, '-c', code],
                                 capture_output=True, text=True, timeout=180)
            lines = [x for x in out.stdout.splitlines() if x.strip()]
            path = lines[-1].strip() if lines else ''
        except Exception:
            path = ''
        return {'path': path}

    @app.post('/api/onboard/preview')
    def onboard_preview(body: dict = Body(...)):
        folder = (body or {}).get('folder', '').strip().strip('"')
        if not folder:
            return {'ok': False, 'reason': 'empty', 'candidates': []}
        p = Path(folder)
        if not p.is_dir():
            return {'ok': False, 'reason': 'not_a_dir', 'candidates': []}
        return {'ok': True, 'folder': str(p), 'candidates': scanner.preview_candidates(p)}

    @app.post('/api/onboard/save')
    def onboard_save(body: dict = Body(...)):
        roots = [str(r).strip().strip('"') for r in (body or {}).get('roots', []) if str(r).strip()]
        if not roots:
            raise HTTPException(400, '스캔할 폴더를 최소 1개 선택하세요')
        if cfg is None or save_fn is None:
            raise HTTPException(500, 'config unavailable')
        cfg['roots'] = roots            # 절대경로 저장 → resolve_roots가 그대로 통과
        cfg['onboarded'] = True
        save_fn(cfg)
        rescan_fn()
        broadcast(None, 'rescan', {'count': len(registry.list())})
        return {'ok': True, 'count': len(registry.list()), 'roots': roots}

    @app.websocket('/ws')
    async def ws(ws: WebSocket):
        await ws.accept()
        clients.add(ws)
        try:
            while True:
                await ws.receive_text()
        except WebSocketDisconnect:
            clients.discard(ws)

    if _STATIC.exists():
        app.mount('/static', StaticFiles(directory=str(_STATIC)), name='static')
    return app


async def _safe_send(ws, msg, clients):
    try:
        await ws.send_json(msg)
    except Exception:
        clients.discard(ws)
