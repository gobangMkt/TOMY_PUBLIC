import os
import re
import shlex
import socket
import subprocess
import sys
import threading
from collections import deque
from pathlib import Path

import psutil

_NO_WINDOW = subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0


def is_port_free(port: int) -> bool:
    # vite 등은 ::1(IPv6)에만 바인딩하므로 IPv4·IPv6 둘 다 확인. 하나라도 붙으면 사용중
    # settimeout 없으면 Windows가 닫힌 포트 거부를 ~2초 지연시켜 서비스마다 누적됨
    for family, addr in ((socket.AF_INET, '127.0.0.1'), (socket.AF_INET6, '::1')):
        try:
            with socket.socket(family, socket.SOCK_STREAM) as s:
                s.settimeout(0.3)
                if s.connect_ex((addr, port)) == 0:
                    return False
        except OSError:
            continue
    return True


# 서비스 런타임이 아니라 폴더를 cwd로 갖거나 경로를 인용할 뿐인 프로세스.
# 이들이 외부 실행 감지에 잡히면, 멀쩡히 멈춘 서비스가 '실행중'으로 오판된다.
# (대표 사례: 허브의 'Claude Code 열기' 버튼이 띄우는 `cmd /k cd /d <경로> && claude` 콘솔)
_IGNORE_PROC_NAMES = {
    'cmd.exe', 'powershell.exe', 'pwsh.exe', 'bash.exe', 'sh.exe', 'wsl.exe',
    'windowsterminal.exe', 'conhost.exe', 'openconsole.exe', 'explorer.exe',
    'code.exe', 'devenv.exe', 'cursor.exe',
}
_IGNORE_CMD_SUBSTR = ('claude',)


def _is_ignorable_proc(name: str, joined_cmd: str) -> bool:
    if (name or '').lower() in _IGNORE_PROC_NAMES:
        return True
    return any(s in (joined_cmd or '') for s in _IGNORE_CMD_SUBSTR)


def scan_processes() -> tuple[set, list]:
    # 외부 실행 감지용 스냅샷: 실행중 프로세스의 작업폴더(cwd) 집합 + 명령행 문자열 목록
    # 셸/터미널/에디터/claude는 서비스 런타임이 아니므로 제외(오탐 방지)
    cwds, cmds = set(), []
    for p in psutil.process_iter(['name', 'cmdline']):
        cl = None
        try:
            cl = p.info.get('cmdline')
        except (psutil.Error, OSError):
            cl = None
        joined = os.path.normcase(' '.join(cl)) if cl else ''
        if _is_ignorable_proc(p.info.get('name') or '', joined):
            continue
        try:
            cwds.add(os.path.normcase(p.cwd()))
        except (psutil.Error, OSError):
            pass
        if joined:
            cmds.append(joined)
    return cwds, cmds


def path_running(path: str, index: tuple[set, list]) -> bool:
    # 폴더 경로가 실행중 프로세스의 cwd 이거나 명령행에 포함되면 실행중으로 본다
    # (자동실행이 다른 cwd에서 절대경로로 띄워도 명령행 매칭으로 잡힘)
    cwds, cmds = index
    t = os.path.normcase(path)
    if t in cwds:
        return True
    return any(t in c for c in cmds)


def _own_pids() -> set:
    # 허브 자신과 그 조상 PID. 스윕 중 절대 종료하면 안 된다(자기 자신·부모 셸/탐색기 보호).
    pids = set()
    try:
        p = psutil.Process()
        while p is not None and p.pid > 4:
            pids.add(p.pid)
            p = p.parent()
    except psutil.Error:
        pass
    return pids


def _kill_tree(root, protected: set) -> None:
    # root와 그 자손을 terminate→(3s 대기)→kill. 보호 PID는 건드리지 않는다.
    try:
        targets = [root, *root.children(recursive=True)]
    except psutil.NoSuchProcess:
        return
    for t in targets:
        if t.pid in protected:
            continue
        try:
            t.terminate()
        except psutil.NoSuchProcess:
            pass
    _, alive = psutil.wait_procs(targets, timeout=3)
    for a in alive:
        if a.pid in protected:
            continue
        try:
            a.kill()
        except psutil.NoSuchProcess:
            pass


def _kill_root(listener, protected: set):
    # 리스너에서 위로 올라가, 셸/터미널/claude(_is_ignorable_proc)나 보호 대상 직전까지의
    # 최상위 '서비스' 조상을 찾는다. next dev·npm·nodemon 등 워커를 재spawn하는
    # 슈퍼바이저를 함께 잡아야 포트가 다시 점유되지 않는다(부모만 살면 워커가 부활함).
    root = listener
    try:
        p = listener.parent()
        while p is not None and p.pid > 4 and p.pid not in protected:
            try:
                cl = os.path.normcase(' '.join(p.cmdline() or []))
            except psutil.Error:
                cl = ''
            if _is_ignorable_proc(p.name() or '', cl):
                break
            root = p
            p = p.parent()
    except psutil.Error:
        pass
    return root


def _kill_by_port(port: int) -> bool:
    # 포트를 LISTEN 중인 '모든' 프로세스를 종료한다(IPv4·IPv6 별도 바인딩이나 중복 리스너가
    # 있으면 하나만 죽여선 포트가 안 풀린다). 각 리스너는 재spawn 슈퍼바이저까지 거슬러 올라가
    # 트리째 종료한다. 허브 자신/셸/claude는 _kill_root·protected로 보호된다.
    try:
        conns = psutil.net_connections(kind='inet')
    except (psutil.AccessDenied, OSError):
        return False
    protected = _own_pids()
    pids = {c.pid for c in conns
            if c.laddr and c.laddr.port == port and c.status == psutil.CONN_LISTEN
            and c.pid and c.pid not in protected}
    if not pids:
        return False
    roots = {}
    for pid in pids:
        try:
            r = _kill_root(psutil.Process(pid), protected)
            roots[r.pid] = r
        except psutil.NoSuchProcess:
            pass
    for r in roots.values():
        _kill_tree(r, protected)
    return bool(roots)


def _kill_by_path(path: str) -> bool:
    # 외부 실행 프로세스: 작업폴더(cwd)가 일치하거나 명령행에 경로가 포함되면 트리째 종료
    target = os.path.normcase(path)
    protected = _own_pids()
    victims = []
    for p in psutil.process_iter(['cmdline']):
        if p.pid in protected:
            continue
        hit = False
        try:
            hit = os.path.normcase(p.cwd()) == target
        except (psutil.Error, OSError):
            pass
        if not hit:
            try:
                cl = p.info.get('cmdline')
                hit = bool(cl) and target in os.path.normcase(' '.join(cl))
            except (psutil.Error, OSError):
                pass
        if hit:
            victims.append(p)
    if not victims:
        return False
    for p in victims:
        _kill_tree(p, protected)
    return True


class _Proc:
    def __init__(self, popen, log_lines):
        self.popen = popen
        self.logs = deque(maxlen=log_lines)
        self.state = 'starting'


class Supervisor:
    def __init__(self, log_lines: int, on_event, reassign_fn=None):
        self._log_lines = log_lines
        self._on_event = on_event  # (service_id, kind, payload)
        self._reassign_fn = reassign_fn  # (svc) -> 새 포트 | None. 기동 시 포트 충돌나면 호출
        self._procs: dict[str, _Proc] = {}
        self._lock = threading.Lock()

    _NODE_RUNNERS = frozenset({'npm', 'npx', 'node', 'pnpm', 'yarn', 'bun', 'deno'})

    @staticmethod
    def _auto_install_cmd(svc: dict) -> str | None:
        # web(node) 서비스인데 node_modules가 없으면 패키지 매니저 install 명령 반환
        if svc.get('type') != 'web':
            return None
        path = Path(svc['path'])
        if not (path / 'package.json').exists():
            return None
        # python 등 비-node 명령이면 npm install 불필요 (GAS 프로젝트 등 package.json만 있는 경우)
        mgr = ((svc.get('command') or '').strip().split() or [''])[0].lower()
        if mgr not in Supervisor._NODE_RUNNERS:
            return None
        # node_modules 가 없거나 .bin 이 비어 있으면(불완전 설치) install 한다
        bin_dir = path / 'node_modules' / '.bin'
        try:
            installed = bin_dir.is_dir() and any(bin_dir.iterdir())
        except OSError:
            installed = False
        if installed:
            return None
        return {'pnpm': 'pnpm install', 'yarn': 'yarn install',
                'bun': 'bun install'}.get(mgr, 'npm install')

    def _compose_command(self, svc: dict) -> str:
        # 실행 순서: (자동 install) → setup_cmd → command(+포트강제)
        parts = []
        install = self._auto_install_cmd(svc)
        if install:
            parts.append(install)
        if svc.get('setup_cmd'):
            parts.append(svc['setup_cmd'])
        parts.append(self._with_port_flag(svc))
        return ' && '.join(parts)

    _HTTP_SERVER_RE = re.compile(r'^(python3?(?:\.exe)?\s+-m\s+http\.server)\s+\d+\s*$')

    @staticmethod
    def _with_port_flag(svc: dict) -> str:
        # vite/next dev 는 PORT 환경변수를 무시하므로 배정 포트를 명령행으로 강제한다
        cmd = svc['command']
        port = svc.get('port')
        if svc.get('type') == 'web' and port:
            if '--port' not in cmd and re.search(r'\b(run dev|pnpm dev|yarn dev)\b', cmd):
                return f'{cmd} -- --port {port}'
            # python -m http.server {N} → 배정 포트로 교체
            m = Supervisor._HTTP_SERVER_RE.match(cmd.strip())
            if m:
                return f'{m.group(1)} {port}'
        return cmd

    def start(self, svc: dict) -> None:
        sid = svc['id']
        with self._lock:
            existing = self._procs.get(sid)
        if existing and existing.popen.poll() is None:
            # 이미 실행 중 → 무반응 대신 현재 상태를 다시 알려 화면을 동기화
            self._set_state(sid, existing.state)
            self._emit(sid, 'log', '[ServiceHub] 이미 실행 중입니다')
            return
        if svc['type'] == 'web' and svc.get('port') and not is_port_free(svc['port']):
            busy = svc['port']
            new_port = self._reassign_fn(svc) if self._reassign_fn else None
            if not new_port:
                self._emit(sid, 'error', f"포트 {busy} 이미 사용 중")
                self._set_state(sid, 'error')
                return
            self._emit(sid, 'log', f"[ServiceHub] 포트 {busy} 사용 중 → {new_port}로 재배정")
            self._emit(sid, 'port', new_port)

        env = dict(os.environ)
        if svc.get('port'):
            env['PORT'] = str(svc['port'])

        if self._auto_install_cmd(svc):
            self._emit(sid, 'log', '[ServiceHub] node_modules 없음 → 의존성 설치 후 실행')
        cmd = self._compose_command(svc)

        # 명령어 파싱: 직접 실행 파일 경로로 시작하거나 멀티라인이면 shell=False + list 형태로 실행
        # (Windows에서 shell=True + \n 혼합 명령은 cmd.exe가 인용부호 내 개행을 처리 못함)
        use_shell = True
        cmd_arg = cmd
        if isinstance(cmd, str):
            stripped = cmd.strip()
            # 직접 경로 실행 파일 감지: "C:\..." -c "..." 또는 C:\...\python.exe ...
            first_token = shlex.split(stripped, posix=False)[0].strip('"') if stripped else ''
            if first_token and Path(first_token).is_file() and Path(first_token).suffix.lower() in ('.exe', '.py'):
                try:
                    parts = shlex.split(stripped, posix=False)
                    # strip outer quotes
                    parts = [p[1:-1] if (p.startswith('"') and p.endswith('"')) else p for p in parts]
                    cmd_arg = parts
                    use_shell = False
                except ValueError:
                    pass

        popen = subprocess.Popen(
            cmd_arg, cwd=svc['path'], env=env, shell=use_shell,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding='utf-8', errors='replace',
            creationflags=_NO_WINDOW,
        )
        proc = _Proc(popen, self._log_lines)
        with self._lock:
            self._procs[sid] = proc
        self._set_state(sid, 'starting')
        threading.Thread(target=self._pump, args=(sid, svc), daemon=True).start()

    def _pump(self, sid: str, svc: dict):
        proc = self._procs[sid]
        running_marked = False
        # task 타입은 프로세스가 시작되면 즉시 running으로 표시
        if svc['type'] == 'task':
            running_marked = True
            self._set_state(sid, 'running')
        for line in proc.popen.stdout:
            line = line.rstrip('\n')
            proc.logs.append(line)
            self._emit(sid, 'log', line)
            if not running_marked and svc['type'] == 'web':
                running_marked = True
                self._set_state(sid, 'running')
        proc.popen.wait()
        code = proc.popen.returncode
        self._set_state(sid, 'exited' if (svc['type'] == 'task' and code == 0) else
                        ('stopped' if code in (0, None, -15, 15) else 'error'))

    def stop(self, sid: str, port: int | None = None, path: str | None = None) -> None:
        with self._lock:
            proc = self._procs.get(sid)
        protected = _own_pids()
        if proc:
            # 허브가 직접 띄운 프로세스: 트리째 종료
            try:
                _kill_tree(psutil.Process(proc.popen.pid), protected)
            except psutil.NoSuchProcess:
                pass
        # 트리킬로 못 잡은 리스너(재parent된 워커·다중 리스너·외부 실행)를 포트/경로로 스윕한다.
        # (proc가 있어도 수행 — 트리 밖으로 새 나간 리스너까지 확실히 정리)
        if port:
            _kill_by_port(port)
        elif path:
            _kill_by_path(path)
        self._set_state(sid, 'stopped')

    def status(self, sid: str) -> str:
        with self._lock:
            proc = self._procs.get(sid)
        if not proc:
            return 'stopped'
        return proc.state

    def scan_index(self) -> tuple[set, list]:
        return scan_processes()

    def open_claude(self, path: str) -> None:
        # 해당 폴더에서 새 콘솔로 Claude Code 실행
        subprocess.Popen(f'start "Claude Code" cmd /k "cd /d "{path}" && claude"', shell=True)

    def trigger_claude_login(self) -> None:
        # OAuth 토큰 만료 시 재로그인용 — 새 콘솔에서 claude 실행, 브라우저 로그인 유도
        subprocess.Popen('start "Claude 재로그인" cmd /k "claude"', shell=True)

    def open_folder(self, path: str) -> None:
        subprocess.Popen(['explorer', os.path.normpath(path)])

    def effective_status(self, svc: dict, proc_index: tuple[set, list] | None = None) -> str:
        # 실행 대상이 아닌 폴더는 상태 개념이 없다
        if svc.get('type') == 'folder':
            return 'idle'
        # 허브가 직접 띄운 살아있는 프로세스가 있으면 그 상태 우선
        sid = svc['id']
        with self._lock:
            proc = self._procs.get(sid)
        if proc and proc.popen.poll() is None:
            return proc.state
        # web은 '포트'가 유일하고 확실한 생존 신호다(--port 강제로 포트 불일치는 방지됨).
        # 포트 점유=external, 포트 비어있음=정지. path/명령행 폴백을 쓰면 폴더를 cwd로 갖거나
        # 경로를 인용하는 무관 프로세스(에디터·콘솔 등)가 오탐되므로 web은 포트로만 판정한다.
        if svc.get('type') == 'web' and svc.get('port'):
            if not is_port_free(svc['port']):
                return 'external'
            return proc.state if proc else 'stopped'
        # 포트 없는 web 또는 task → 폴더 경로가 실행중 프로세스에 잡히면 external
        # (자동실행이 다른 cwd로 떠도 명령행 경로로 감지)
        if svc.get('type') in ('web', 'task') and svc.get('path'):
            idx = proc_index if proc_index is not None else scan_processes()
            if path_running(svc['path'], idx):
                return 'external'
        if proc:
            return proc.state
        return 'stopped'

    def logs(self, sid: str) -> list[str]:
        with self._lock:
            proc = self._procs.get(sid)
        return list(proc.logs) if proc else []

    def stop_all(self) -> None:
        for sid in list(self._procs.keys()):
            self.stop(sid)

    def _set_state(self, sid: str, state: str):
        proc = self._procs.get(sid)
        if proc:
            proc.state = state
        self._emit(sid, 'state', state)

    def _emit(self, sid, kind, payload):
        try:
            self._on_event(sid, kind, payload)
        except Exception:
            pass
