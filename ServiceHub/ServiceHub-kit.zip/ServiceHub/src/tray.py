import os
import sys
import webbrowser
import winreg
from pathlib import Path

from PIL import Image, ImageDraw
import pystray
from pystray import MenuItem as item

from config import CONFIG_PATH, _base_dir

AUTOSTART_KEY = r'Software\Microsoft\Windows\CurrentVersion\Run'
AUTOSTART_NAME = 'ServiceHub'


def _build_autostart_cmd() -> str:
    if getattr(sys, 'frozen', False):
        return f'"{sys.executable}"'
    script = Path(__file__).parent / 'main.py'
    exe = Path(sys.executable)
    pythonw = exe.with_name('pythonw.exe')
    runner = pythonw if pythonw.exists() else exe
    return f'"{runner}" "{script}"'


def _is_autostart_enabled() -> bool:
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, AUTOSTART_KEY)
        winreg.QueryValueEx(key, AUTOSTART_NAME)
        winreg.CloseKey(key)
        return True
    except OSError:
        return False


def _create_icon_image(color: str) -> Image.Image:
    size = 64
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle([4, 4, size - 4, size - 4], radius=14, fill=color)
    # 흰색 "전원/허브" 점 3개
    for i, y in enumerate((22, 32, 42)):
        draw.ellipse([20, y - 3, 26, y + 3], fill='white')
        draw.rectangle([30, y - 1, 46, y + 1], fill='white')
    return img


class TrayApp:
    def __init__(self, port: int, on_quit, on_toggle_mini=None):
        self._port = port
        self._on_quit = on_quit
        self._on_toggle_mini = on_toggle_mini
        self.icon = pystray.Icon(
            AUTOSTART_NAME,
            _create_icon_image('#3b82f6'),
            f'ServiceHub — localhost:{port}',
            menu=pystray.Menu(
                item('미니뷰 표시/숨김', self._toggle_mini, default=True),
                item('대시보드 열기', self._open_dashboard),
                pystray.Menu.SEPARATOR,
                item('설정 파일 열기', self._open_config),
                item('부팅 시 자동 시작', self._toggle_autostart,
                     checked=lambda _: _is_autostart_enabled()),
                pystray.Menu.SEPARATOR,
                item('종료', self._quit),
            ),
        )

    def run(self):
        self.icon.run()

    def _open_dashboard(self):
        webbrowser.open(f'http://localhost:{self._port}')

    def _toggle_mini(self):
        if self._on_toggle_mini:
            self._on_toggle_mini()

    def _open_config(self):
        os.startfile(str(CONFIG_PATH))

    def _toggle_autostart(self):
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, AUTOSTART_KEY, 0, winreg.KEY_SET_VALUE)
        if _is_autostart_enabled():
            winreg.DeleteValue(key, AUTOSTART_NAME)
        else:
            winreg.SetValueEx(key, AUTOSTART_NAME, 0, winreg.REG_SZ, _build_autostart_cmd())
        winreg.CloseKey(key)

    def _quit(self):
        self._on_quit()
        self.icon.stop()
