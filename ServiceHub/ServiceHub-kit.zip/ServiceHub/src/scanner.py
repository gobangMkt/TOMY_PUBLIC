import json
import re
from pathlib import Path

EXCLUDE = {'node_modules', '.git', '.claude', '__pycache__', 'dist', 'build', '.next'}
SELF_NAME = 'ServiceHub'  # 매니저 자신: 실행/중지는 대시보드를 죽이므로 폴더로만 노출
_PORT_RE = re.compile(r'localhost:(\d+)')

# README.md 에서 배포 URL 자동 탐지
_DEPLOY_URL_RE = re.compile(r'https://[^\s\)\]\'\"<>]+')
_DEPLOY_EXCLUDE = (
    'github.com', 'raw.githubusercontent.com', 'npmjs.com',
    'fonts.googleapis.com', 'fonts.gstatic.com', 'img.shields.io',
    'shields.io', 'schema.org', 'localhost', 'badge',
    'docs.google.com',  # 스프레드시트·문서 = 데이터 소스, 배포 링크 아님
)


def _parse_deploy_urls(folder: Path) -> list:
    readme = folder / 'README.md'
    if not readme.exists():
        return []
    try:
        text = readme.read_text(encoding='utf-8', errors='ignore')
    except OSError:
        return []
    urls = []
    for m in _DEPLOY_URL_RE.finditer(text):
        url = m.group(0).rstrip('.,;:)`')  # 백틱/마침표 등 trailing 제거
        if any(h in url for h in _DEPLOY_EXCLUDE):
            continue
        if url not in urls:
            urls.append(url)
    return urls
# 이 중 하나라도 의존성에 있으면 웹 서버로 본다. 없으면 포트 없는 워커(task)로 분류
_WEB_DEPS = (
    'express', 'vite', 'next', 'react-scripts', '@sveltejs', 'nuxt', 'koa',
    'fastify', 'webpack-dev-server', 'http-server', 'serve', 'astro',
    '@remix-run', '@angular', 'gatsby', '@nestjs',
)


def _slug(name: str) -> str:
    return re.sub(r'[^a-z0-9가-힣]+', '-', name.lower()).strip('-')


def _root_prefix(root_label: str) -> str:
    return _slug(root_label.replace('프로젝트/', '').replace('/', '_'))


def _parse_bat(folder: Path, extra_names: tuple = ()):
    # 폴더 내 첫 '시작*.bat' 또는 extra_names bat에서 포트와 기동/셋업 명령 추출
    port, command, setup = None, None, None

    def _read_bat(bat: Path):
        nonlocal port, command, setup
        text = bat.read_text(encoding='utf-8', errors='ignore')
        m = _PORT_RE.search(text)
        if m:
            port = int(m.group(1))
        for line in text.splitlines():
            s = line.strip()
            low = s.lower()
            if low.startswith('call '):
                setup = s[5:].strip()
            elif low.startswith('npm ') or low.startswith('node '):
                command = s
            elif low.startswith('python '):
                command = s

    for bat in folder.glob('시작*.bat'):
        _read_bat(bat)
        break
    if command is None:
        for name in extra_names:
            bat = folder / name
            if bat.exists():
                _read_bat(bat)
                break
    return port, command, setup


# bat 기반 정적/중첩 서비스 발견용 ----------------------------------------
# 기동 런타임으로 인정하는 첫 토큰. 이 중 하나로 시작하는 줄(또는 start 래핑 해제 후)을 명령으로 본다
_RUNNERS = ('node', 'npx', 'npm', 'pnpm', 'yarn', 'bun', 'deno', 'python', 'py')
# 명령 안에 이게 있으면 포트가 안 보여도 '웹 서버'로 확신 (정적 서버류)
_STATIC_HINTS = ('http.server', 'http-server', 'serve', 'live-server', 'serve.json')
# bat 파일명이 이런 의미면 서버 기동이 아니라 빌드/설치/등록류 → 발견 후보에서 제외
_SKIP_BAT = ('설치', 'build', '빌드', '등록', '로그인', '스프레드시트', '처리', 'setup')
_PORT_RES = (
    re.compile(r'localhost:(\d+)'),
    re.compile(r'127\.0\.0\.1:(\d+)'),
    re.compile(r'(?:--port|-p)[ =](\d+)'),
    re.compile(r'http\.server\s+(\d+)'),
)
_CD_RE = re.compile(r'^cd\s+/d\s+"?%~dp0[\\/]*([^"\r\n]*)"?\s*$', re.I)


def _extract_runcmd(line: str):
    # 줄에서 실제 기동 명령을 추출. 'start "제목" <cmd>' 래핑을 풀고, 브라우저 열기(start http)는 버린다
    s = line.strip()
    if not s:
        return None
    low = s.lower()
    if low.startswith('start '):
        rest = s[6:].strip()
        if rest.startswith('"'):  # start "제목" ... → 제목 따옴표 제거
            end = rest.find('"', 1)
            if end != -1:
                rest = rest[end + 1:].strip()
        rl = rest.lower()
        if rl.startswith('http') or rl.startswith('"http'):
            return None  # 브라우저 열기 줄
        s, low = rest, rl
    head = low.split()[0] if low.split() else ''
    return s if head in _RUNNERS else None


def _find_port_near(folder: Path, subdir: str):
    # 포트가 본 bat에 없으면 폴더(및 cd 대상 하위 폴더)의 '시작 NNNN.bat' 파일명/내용에서 보충
    dirs = [folder] + ([folder / subdir] if subdir else [])
    for d in dirs:
        if not d.is_dir():
            continue
        for bat in sorted(d.glob('시작*.bat')):
            m = re.search(r'시작\s*(\d{2,5})', bat.name)
            if m:
                return int(m.group(1))
            text = bat.read_text(encoding='utf-8', errors='ignore')
            for pat in _PORT_RES:
                mm = pat.search(text)
                if mm:
                    return int(mm.group(1))
    return None


def _bat_service(folder: Path):
    # pkg/py로 못 잡힌 폴더를 bat 기반으로 발견: (command, port) 또는 None.
    # 정적 서버(http.server/serve)·하위폴더 cd 후 node/npm 기동 등 다양한 시작 bat을 해석한다.
    cands = list(folder.glob('시작*.bat')) + [
        b for b in sorted(folder.glob('*.bat'))
        if not b.name.startswith('시작')
        and not any(k in b.name.lower() for k in _SKIP_BAT)]
    for bat in cands:
        text = bat.read_text(encoding='utf-8', errors='ignore')
        subdir, runcmd = '', None
        for line in text.splitlines():
            m = _CD_RE.match(line.strip())
            if m:
                subdir = m.group(1).strip().strip('"')
                continue
            if runcmd is None:
                rc = _extract_runcmd(line)
                if rc:
                    runcmd = rc
        if not runcmd:
            continue
        port = None
        for pat in _PORT_RES:
            mm = pat.search(text)
            if mm:
                port = int(mm.group(1))
                break
        if port is None:
            port = _find_port_near(folder, subdir)
        is_static = any(h in runcmd.lower() for h in _STATIC_HINTS)
        if port is None and not is_static:
            continue  # 포트도 정적힌트도 없으면 서버라 단정 못함 → 다음 후보
        command = f'cd /d "{subdir}" && {runcmd}' if subdir else runcmd
        return command, port
    return None


def _dep_matches(dep: str, w: str) -> bool:
    # 정확/접두 매칭. 부분문자열이면 'vite'가 'vitest'에 잘못 걸림
    return dep == w or dep.startswith(w + '-') or dep.startswith(w + '/')


def _is_web_pkg(data: dict, port) -> bool:
    if port:  # '시작 {포트}.bat'에서 포트를 찾았으면 웹으로 확정
        return True
    deps = {**data.get('dependencies', {}), **data.get('devDependencies', {})}
    return any(_dep_matches(d, w) for d in deps for w in _WEB_DEPS)


def _detect(folder: Path):
    if folder.name == SELF_NAME:
        return 'folder', None, None, None  # 자기 자신은 폴더/Claude 열기만 제공
    pkg = folder / 'package.json'
    if pkg.exists():
        try:
            data = json.loads(pkg.read_text(encoding='utf-8'))
        except (json.JSONDecodeError, OSError):
            data = {}
        scripts = data.get('scripts', {})
        port, bat_cmd, setup = _parse_bat(folder)
        if 'dev' in scripts:
            command = 'npm run dev'
            setup = None  # npm 스크립트로 기동 → .bat의 call(build/start)을 setup으로 오인 방지(의존성은 auto-install이 처리)
        elif 'start' in scripts:
            command = 'npm start'
            setup = None
        else:
            command = bat_cmd
        if command:
            if _is_web_pkg(data, port):
                return 'web', command, setup, port
            return 'task', command, setup, None
    # task: python 파일(루트 또는 src/) + 실행.bat / requirements.txt / 시작.vbs
    has_py = any(folder.glob('*.py')) or any((folder / 'src').glob('*.py'))
    has_setup = ((folder / '실행.bat').exists() or (folder / 'requirements.txt').exists()
                 or (folder / '시작.vbs').exists() or any(folder.glob('시작*.bat')))
    if has_py and has_setup:
        _, bat_cmd, setup = _parse_bat(folder, extra_names=('실행.bat',))
        entry = _find_py_entry(folder)  # main/app/run.py (루트 또는 src/)
        command = bat_cmd or (f'python {entry}' if entry else None)
        if command:
            return 'task', command, setup, None
    # pkg/py로 못 잡았지만 시작 bat이 정적·하위폴더 서버를 띄우면 web으로 발견
    bat_web = _bat_service(folder)
    if bat_web:
        command, port = bat_web
        return 'web', command, None, port
    # 실행 대상이 아니어도 폴더 자체는 등록 → 'Claude Code 열기'만 제공
    return 'folder', None, None, None


def _find_py_entry(folder: Path):
    # main/app/run/tray.py 를 루트와 src/ 에서 탐색 (트레이앱은 main/tray.py 패턴이 흔함)
    for base in (folder, folder / 'src'):
        for stem in ('main', 'app', 'run', 'tray'):
            p = base / f'{stem}.py'
            if p.exists():
                return p.relative_to(folder).as_posix()
    return None


def scan_root(root_path: Path, root_label: str) -> list[dict]:
    if not root_path.exists():
        return []
    prefix = _root_prefix(root_label)
    services = []
    for child in sorted(root_path.iterdir()):
        if not child.is_dir() or child.name in EXCLUDE or child.name.startswith('.'):
            continue
        det = _detect(child)
        if det is None:
            continue
        svc_type, command, setup, port = det
        services.append({
            'id': f'{prefix}__{_slug(child.name)}',
            'name': child.name,
            'root': root_label,
            'path': str(child),
            'type': svc_type,
            'command': command,
            'setup_cmd': setup,
            'intended_port': port,
            'port': port,
            'deploy_urls': _parse_deploy_urls(child),
        })
    return services


def _runnable_children(folder: Path) -> tuple[int, list[str]]:
    # folder의 1단계 자식 중 실행 가능한(web/task) 서비스 수와 샘플 이름. 스캔 규칙과 동일 기준.
    n, samples = 0, []
    try:
        children = sorted(folder.iterdir())
    except OSError:
        return 0, []
    for c in children:
        if not c.is_dir() or c.name in EXCLUDE or c.name.startswith('.'):
            continue
        det = _detect(c)
        if det and det[0] != 'folder':
            n += 1
            if len(samples) < 4:
                samples.append(c.name)
    return n, samples


def preview_candidates(folder: Path) -> list[dict]:
    """온보딩: 선택한 루트레포 폴더를 훑어 스캔 root 후보를 추천한다.
    - 폴더 '직속' 자식이 서비스면 폴더 자체가 root 후보(직속)
    - 그 외 카테고리 하위폴더 각각을 root 후보로(손자=서비스). 스캔은 root의 1단계 자식만 보므로 이 구조가 맞다.
    반환: [{path, label, count, samples, recommended}] — count>0이면 recommended(기본 체크)."""
    if not folder or not folder.is_dir():
        return []
    out = []
    n0, s0 = _runnable_children(folder)
    if n0 > 0:
        out.append({'path': str(folder), 'label': f'{folder.name} (직속)',
                    'count': n0, 'samples': s0, 'recommended': True})
    try:
        children = sorted(folder.iterdir())
    except OSError:
        children = []
    for c in children:
        if not c.is_dir() or c.name in EXCLUDE or c.name.startswith('.'):
            continue
        det = _detect(c)
        if det and det[0] != 'folder':
            continue  # 자체가 서비스면 위 '직속'에 이미 반영됨
        n, s = _runnable_children(c)
        out.append({'path': str(c), 'label': c.name, 'count': n,
                    'samples': s, 'recommended': n > 0})
    return out


def scan_all(roots_resolved: list[tuple[str, Path]]) -> list[dict]:
    out = []
    for label, path in roots_resolved:
        try:
            out.extend(scan_root(path, label))
        except OSError:
            continue
    return out
