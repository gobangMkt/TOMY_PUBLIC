"""전역 업무 타이머. RoutineLog 운동 타이머와 동일 원리:
시작 절대시각(started_at)만 저장하고 경과는 now-started_at으로 계산.

상태(config.work_timer):
  started_at: ISO(로컬TZ) 또는 None
  today_date: today_seconds가 가리키는 날짜(YYYY-MM-DD)
  today_seconds: 그날 '종료된' 세션 누적 초(진행 중 경과 미포함)

가드:
  - 자정: 진행 중인데 시작일 != 오늘 → 자동 종료(전날 몫은 버림, 오늘만 보관)
  - 12시간 초과: 자동 종료, 상한 12h를 누적에 더하고 long_run 플래그
"""
import threading
from datetime import datetime

MAX_RUN_SECONDS = 12 * 3600


def _local_now() -> datetime:
    return datetime.now().astimezone()


def _day(dt: datetime) -> str:
    return dt.strftime('%Y-%m-%d')


class WorkTimer:
    def __init__(self, cfg: dict, save_fn, now_fn=_local_now):
        self._cfg = cfg
        self._save = save_fn
        self._now = now_fn
        self._lock = threading.Lock()
        self._cfg.setdefault(
            'work_timer', {'started_at': None, 'today_date': None, 'today_seconds': 0})

    def _st(self) -> dict:
        return self._cfg['work_timer']

    def _reconcile(self, now: datetime) -> str | None:
        """자정 롤오버 + 12h 가드 적용. 자동종료 사유 반환(없으면 None). 변경 시 저장."""
        st = self._st()
        today = _day(now)
        auto = None
        changed = False
        if st.get('today_date') != today:
            st['today_date'] = today
            st['today_seconds'] = 0
            changed = True
        started = st.get('started_at')
        if started:
            start_dt = datetime.fromisoformat(started)
            if _day(start_dt) != today:
                # 진행 중 자정 넘김 → 자동 종료(전날 진행분 폐기, 오늘 0부터)
                st['started_at'] = None
                auto = 'midnight'
                changed = True
            elif (now - start_dt).total_seconds() > MAX_RUN_SECONDS:
                st['today_seconds'] = int(st.get('today_seconds', 0)) + MAX_RUN_SECONDS
                st['started_at'] = None
                auto = 'long_run'
                changed = True
        if changed:
            self._save(self._cfg)
        return auto

    def _state_dict(self, now: datetime, auto: str | None) -> dict:
        st = self._st()
        started = st.get('started_at')
        elapsed = 0
        if started:
            elapsed = int((now - datetime.fromisoformat(started)).total_seconds())
        return {
            'running': bool(started),
            'started_at': started,
            'elapsed_seconds': max(0, elapsed),
            'today_seconds': int(st.get('today_seconds', 0)),
            'today_date': st.get('today_date'),
            'auto_stopped': auto,
        }

    def get_state(self) -> dict:
        with self._lock:
            now = self._now()
            auto = self._reconcile(now)
            return self._state_dict(now, auto)

    def start(self) -> dict:
        with self._lock:
            now = self._now()
            self._reconcile(now)
            st = self._st()
            if not st.get('started_at'):
                st['started_at'] = now.isoformat()
                self._save(self._cfg)
            return self._state_dict(now, None)

    def stop(self) -> dict:
        with self._lock:
            now = self._now()
            self._reconcile(now)
            st = self._st()
            started = st.get('started_at')
            if started:
                elapsed = int((now - datetime.fromisoformat(started)).total_seconds())
                st['today_seconds'] = int(st.get('today_seconds', 0)) + max(0, elapsed)
                st['started_at'] = None
                self._save(self._cfg)
            return self._state_dict(now, None)
