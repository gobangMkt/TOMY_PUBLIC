class Registry:
    def __init__(self, cfg: dict, save_fn):
        self._cfg = cfg
        self._save = save_fn
        self._services: dict[str, dict] = {}

    def rebuild(self, discovered: list[dict]) -> None:
        overrides = self._cfg.get('overrides', {})
        assigned = dict(self._cfg.get('assigned_ports', {}))
        pool_start = self._cfg.get('port_pool_start', 3060)

        used = set()
        web = []
        merged = {}
        for d in discovered:
            svc = dict(d)
            ov = overrides.get(svc['id'], {})
            for key in ('name', 'command', 'type', 'setup_cmd'):
                if key in ov:
                    svc[key] = ov[key]
            svc['enabled'] = ov.get('enabled', True)
            # deploy_urls: override 우선, 없으면 scanner가 README에서 자동 탐지한 목록 유지
            auto_urls = svc.get('deploy_urls', [])
            ov_urls = ov.get('deploy_urls')
            ov_url = ov.get('deploy_url')
            if ov_urls is not None:
                svc['deploy_urls'] = ov_urls if isinstance(ov_urls, list) else [ov_urls]
            elif ov_url:
                svc['deploy_urls'] = [ov_url]
            else:
                svc['deploy_urls'] = auto_urls
            merged[svc['id']] = svc
            if svc['type'] == 'web':
                web.append(svc)
            else:
                svc['port'] = None

        # 1순위: override 포트 또는 이전 배정 포트 확정
        for svc in web:
            ov_port = overrides.get(svc['id'], {}).get('port')
            fixed = ov_port or assigned.get(svc['id'])
            if fixed and fixed not in used:
                svc['port'] = fixed
                used.add(fixed)
            else:
                svc['port'] = None
        # 2순위: 의도포트가 비충돌이면 유지
        for svc in web:
            if svc['port'] is None and svc['intended_port'] and svc['intended_port'] not in used:
                svc['port'] = svc['intended_port']
                used.add(svc['port'])
        # 3순위: 풀에서 다음 빈 포트
        nxt = pool_start
        for svc in web:
            if svc['port'] is None:
                while nxt in used:
                    nxt += 1
                svc['port'] = nxt
                used.add(nxt)

        new_assigned = {s['id']: s['port'] for s in web}
        self._services = merged
        if new_assigned != self._cfg.get('assigned_ports'):
            self._cfg['assigned_ports'] = new_assigned
            self._save(self._cfg)

    def reassign_port(self, sid: str, is_free) -> int | None:
        # 런타임 충돌 시 재정리: 다른 web 서비스가 쓰는 포트 + OS가 점유한 포트를 피해
        # 풀에서 다음 빈 포트를 잡아 배정하고 config에 영속화. web이 아니면 None.
        svc = self._services.get(sid)
        if not svc or svc.get('type') != 'web':
            return None
        pool_start = self._cfg.get('port_pool_start', 3060)
        used = {s['port'] for k, s in self._services.items()
                if k != sid and s.get('type') == 'web' and s.get('port')}
        port = pool_start
        while port <= 65535 and (port in used or not is_free(port)):
            port += 1
        if port > 65535:
            return None
        svc['port'] = port
        assigned = dict(self._cfg.get('assigned_ports', {}))
        assigned[sid] = port
        if assigned != self._cfg.get('assigned_ports'):
            self._cfg['assigned_ports'] = assigned
            self._save(self._cfg)
        return port

    def list(self) -> list[dict]:
        return list(self._services.values())

    def get(self, sid: str) -> dict | None:
        return self._services.get(sid)
