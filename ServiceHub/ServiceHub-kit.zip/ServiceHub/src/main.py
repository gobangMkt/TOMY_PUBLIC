import os
import sys
import threading
from pathlib import Path

# pythonw(GUI) 실행 시 stdout/stderr가 None → uvicorn 로깅이 거기에 쓰다 죽는다. devnull로 가드.
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')

sys.path.insert(0, str(Path(__file__).parent))

import uvicorn

import config as cfg_mod
import scanner
from registry import Registry
from supervisor import Supervisor, is_port_free
from server import create_app
from timer import WorkTimer
from tray import TrayApp
from miniview import MiniView
import notifier


def build():
    cfg = cfg_mod.load_config()
    registry = Registry(cfg, save_fn=cfg_mod.save_config)

    app_holder = {}
    mini_holder = {}  # 미니뷰는 main()에서 생성 → 토글 콜백이 늦게 채워진 인스턴스를 참조

    def on_event(sid, kind, payload):
        app = app_holder.get('app')
        if app and hasattr(app.state, 'broadcast'):
            app.state.broadcast(sid, kind, payload)

    supervisor = Supervisor(
        log_lines=cfg.get('log_lines', 500), on_event=on_event,
        reassign_fn=lambda svc: registry.reassign_port(svc['id'], is_port_free),
    )

    def rescan():
        # roots는 온보딩으로 바뀔 수 있어 매 스캔마다 cfg에서 재도출
        roots = list(zip(cfg['roots'], cfg_mod.resolve_roots(cfg['roots'])))
        registry.rebuild(scanner.scan_all(roots))

    rescan()
    timer = WorkTimer(cfg, save_fn=cfg_mod.save_config)

    def mini_toggle():
        m = mini_holder.get('mini')
        if m:
            m.toggle()

    app = create_app(registry, supervisor, rescan_fn=rescan, timer=timer,
                     cfg=cfg, save_fn=cfg_mod.save_config, mini_toggle=mini_toggle)
    app_holder['app'] = app
    return cfg, app, supervisor, mini_holder


def main():
    cfg, app, supervisor, mini_holder = build()
    port = cfg['manager_port']

    server = uvicorn.Server(uvicorn.Config(app, host='127.0.0.1', port=port, log_level='warning'))
    t = threading.Thread(target=server.run, daemon=True)
    t.start()

    mini = MiniView(f'http://127.0.0.1:{port}/mini')
    mini_holder['mini'] = mini
    quit_event = threading.Event()

    def on_quit():
        supervisor.stop_all()
        server.should_exit = True
        quit_event.set()
        os._exit(0)          # webview GUI 루프는 cross-thread 종료가 까다로워 강제 종료

    # pywebview·pystray 모두 자기 스레드의 Win32 메시지 루프를 요구.
    # 트레이는 전용 데몬 스레드에서 icon.run()(자체 메시지 루프 → 메뉴 클릭 동작),
    # webview는 메인 스레드 점유. run_detached는 메시지 루프가 없어 메뉴가 안 먹힘.
    tray = TrayApp(port, on_quit, on_toggle_mini=mini.toggle)
    threading.Thread(target=tray.icon.run, daemon=True).start()
    try:
        mini.create()
        mini.start()         # 정상: 종료까지 메인 스레드 블록
    except Exception as e:
        # WebView2 런타임 미설치 등 → 미니뷰만 비활성, 대시보드/트레이는 유지
        notifier.notify_error(f'미니뷰를 열 수 없습니다(WebView2 런타임 확인). {e}')
        quit_event.wait()


if __name__ == '__main__':
    main()
