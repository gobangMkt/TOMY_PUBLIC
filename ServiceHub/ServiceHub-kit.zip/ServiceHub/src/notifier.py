from winotify import Notification, audio

APP_ID = 'ServiceHub'


def notify_error(message: str):
    toast = Notification(app_id=APP_ID, title='ServiceHub — 오류', msg=message, duration='short')
    toast.set_audio(audio.Default, loop=False)
    toast.show()
