import json
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

CRED_PATH = Path.home() / '.claude' / '.credentials.json'
PROJECTS_DIR = Path.home() / '.claude' / 'projects'
USAGE_URL = 'https://api.anthropic.com/api/oauth/usage'

# $/백만 토큰. claude-api 기준. 구독제라 실제 청구 0 → 참고용 추정.
PRICING = {
    'opus':   {'input': 15.0, 'output': 75.0, 'cache_read': 1.50, 'cache_write': 18.75},
    'sonnet': {'input': 3.0,  'output': 15.0, 'cache_read': 0.30, 'cache_write': 3.75},
    'haiku':  {'input': 1.0,  'output': 5.0,  'cache_read': 0.10, 'cache_write': 1.25},
}


def _model_family(model):
    m = (model or '').lower()
    if 'opus' in m:
        return 'opus'
    if 'haiku' in m:
        return 'haiku'
    return 'sonnet'


def parse_limits(data):
    """usage 응답의 limits[]를 {session, weekly_all, weekly_scoped}로 정규화."""
    out = {'session': None, 'weekly_all': None, 'weekly_scoped': None}
    for lim in (data.get('limits') or []):
        key = lim.get('kind')
        if key not in out:
            continue
        scope = lim.get('scope') or {}
        label = (scope.get('model') or {}).get('display_name')
        out[key] = {
            'percent': lim.get('percent'),
            'resets_at': lim.get('resets_at'),
            'severity': lim.get('severity'),
            'label': label,
        }
    return out


def _load_token():
    if not CRED_PATH.exists():
        return None, 'no_credentials'
    try:
        data = json.loads(CRED_PATH.read_text(encoding='utf-8'))
    except (ValueError, OSError):
        return None, 'no_credentials'
    oauth = data.get('claudeAiOauth') or {}
    token = oauth.get('accessToken')
    exp = oauth.get('expiresAt')
    if not token:
        return None, 'no_credentials'
    if exp and exp < time.time() * 1000:
        return None, 'needs_login'
    return token, None


def fetch_limits(timeout=10):
    token, err = _load_token()
    if err:
        return {'ok': False, 'reason': err, 'limits': None}
    req = urllib.request.Request(USAGE_URL, headers={
        'Authorization': f'Bearer {token}',
        'anthropic-version': '2023-06-01',
        'anthropic-beta': 'oauth-2025-04-20',
        'User-Agent': 'claude-cli/1.0',
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        reason = 'needs_login' if e.code in (401, 403) else 'http_error'
        return {'ok': False, 'reason': reason, 'limits': None}
    except (urllib.error.URLError, OSError, ValueError):
        return {'ok': False, 'reason': 'network', 'limits': None}
    return {'ok': True, 'reason': None, 'limits': parse_limits(data)}


# 세션 jsonl을 직접 집계한다(Claude Code의 stats-cache.json은 /usage 실행 때만 갱신돼
# 며칠씩 멈춘다). 파일 mtime+size로 증분 캐싱: 바뀐 파일만 재파싱.
# path -> {'sig': (mtime, size), 'tokens': [(msgid, date, fam, i, o, cr, cc)], 'msgs': [(uuid, type)]}
_file_cache = {}
_RAW_KEYS = ('inputTokens', 'outputTokens', 'cacheReadInputTokens', 'cacheCreationInputTokens')


def _local_date(ts):
    # UTC ISO('...Z') → 시스템 로컬 날짜. astimezone() 무인자 = 로컬 tz 변환.
    return datetime.fromisoformat(ts.replace('Z', '+00:00')).astimezone().strftime('%Y-%m-%d')


def _parse_session(path):
    tokens, msgs = [], []
    try:
        fh = path.open(encoding='utf-8')
    except OSError:
        return {'tokens': tokens, 'msgs': msgs}
    with fh:
        for ln, line in enumerate(fh):
            line = line.strip()
            if not line:
                continue
            try:
                o = json.loads(line)
            except ValueError:
                continue
            typ = o.get('type')
            if typ in ('user', 'assistant'):
                msgs.append((o.get('uuid') or f'{path.name}:{ln}', typ))
            msg = o.get('message') or {}
            u = msg.get('usage')
            ts = o.get('timestamp')
            if not u or not ts:
                continue
            try:
                date = _local_date(ts)
            except (ValueError, TypeError):
                continue
            fam = _model_family(msg.get('model'))
            # msgid 없으면 합성키로 항상 카운트(dedup 충돌 방지)
            mid = msg.get('id') or f'{path.name}:{ln}'
            tokens.append((mid, date, fam,
                           u.get('input_tokens', 0), u.get('output_tokens', 0),
                           u.get('cache_read_input_tokens', 0),
                           u.get('cache_creation_input_tokens', 0)))
    return {'tokens': tokens, 'msgs': msgs}


def _collect_sessions():
    if not PROJECTS_DIR.exists():
        return []
    present = set()
    for path in PROJECTS_DIR.rglob('*.jsonl'):
        try:
            st = path.stat()
        except OSError:
            continue
        key = str(path)
        present.add(key)
        sig = (st.st_mtime, st.st_size)
        ent = _file_cache.get(key)
        if not ent or ent['sig'] != sig:
            parsed = _parse_session(path)
            _file_cache[key] = {'sig': sig, **parsed}
    for stale in [k for k in _file_cache if k not in present]:
        del _file_cache[stale]
    return list(_file_cache.values())


def local_stats(days=14):
    sessions = _collect_sessions()
    if not sessions:
        return {'available': False, 'totals': None, 'daily': [], 'byModel': []}
    tok_by_id = {}  # msgid -> entry (resume 중복 dedup)
    msg_uuids = set()
    for ent in sessions:
        for t in ent['tokens']:
            tok_by_id[t[0]] = t
        for uuid, _typ in ent['msgs']:
            msg_uuids.add(uuid)
    fam = {}        # family -> {family, tokens, raw}
    by_date = {}    # date -> {family -> tokens}
    for _mid, date, f, i, o, cr, cc in tok_by_id.values():
        acc = fam.setdefault(f, {'family': f, 'tokens': 0,
                                 'raw': {k: 0 for k in _RAW_KEYS}})
        acc['raw']['inputTokens'] += i
        acc['raw']['outputTokens'] += o
        acc['raw']['cacheReadInputTokens'] += cr
        acc['raw']['cacheCreationInputTokens'] += cc
        tot = i + o + cr + cc
        acc['tokens'] += tot
        dd = by_date.setdefault(date, {})
        dd[f] = dd.get(f, 0) + tot
    by_model = sorted(fam.values(), key=lambda x: x['tokens'], reverse=True)
    daily = [{'date': d, 'tokens': sum(fam_tokens.values()), 'byModel': fam_tokens}
             for d, fam_tokens in sorted(by_date.items())][-days:]
    totals = {
        'tokens': sum(m['tokens'] for m in by_model),
        'sessions': len(sessions),
        'messages': len(msg_uuids),
        'computedDate': datetime.now().strftime('%Y-%m-%d'),
    }
    return {'available': True, 'totals': totals, 'daily': daily, 'byModel': by_model}


def cost_estimate(by_model):
    total = 0.0
    for m in by_model:
        p = PRICING[m['family']]
        r = m.get('raw') or {}
        total += (r.get('inputTokens', 0) * p['input']
                  + r.get('outputTokens', 0) * p['output']
                  + r.get('cacheReadInputTokens', 0) * p['cache_read']
                  + r.get('cacheCreationInputTokens', 0) * p['cache_write']) / 1_000_000
    return round(total, 2)
