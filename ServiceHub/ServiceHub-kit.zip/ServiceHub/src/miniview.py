import ctypes

WIN_W, WIN_H, MARGIN = 400, 480, 16
BAR_W, BAR_H = 220, 44          # 최소화(미니바) 크기
MIN_W, MIN_H = 280, 240         # 그립 리사이즈 최소 크기


class _RECT(ctypes.Structure):
    _fields_ = [('left', ctypes.c_long), ('top', ctypes.c_long),
                ('right', ctypes.c_long), ('bottom', ctypes.c_long)]


def bottom_right(win_w: int, win_h: int, work_w: int, work_h: int, margin: int = MARGIN):
    # 작업영역 크기 기준 우하단 좌표(작업영역 원점 0,0 가정)
    return max(0, work_w - win_w - margin), max(0, work_h - win_h - margin)


def _work_rect() -> _RECT:
    # 주 모니터 작업영역 RECT(left/top/right/bottom, 작업표시줄 제외). 실패 시 보수적 추정값
    u = ctypes.windll.user32
    try:
        u.SetProcessDPIAware()
    except Exception:
        pass
    r = _RECT()
    if u.SystemParametersInfoW(0x0030, 0, ctypes.byref(r), 0):  # SPI_GETWORKAREA
        return r
    r.left, r.top, r.right, r.bottom = 0, 0, 1920, 1040
    return r


class MiniView:
    # pywebview 미니 창. 메인 스레드에서 start()로 GUI 루프 점유, 토글은 다른 스레드에서 호출 가능.
    def __init__(self, url: str):
        self._url = url
        self._window = None
        self._visible = False
        self._expanded = (WIN_W, WIN_H)  # 펼친 상태 크기(미니바 복원·그립 갱신용)

    class _Api:
        def __init__(self, outer):
            self._outer = outer

        def hide(self):
            self._outer.hide()

        def open_url(self, url):
            import webbrowser
            webbrowser.open(url)

        def get_size(self):
            return self._outer.get_size()

        def resize_to(self, opts):
            self._outer.resize_to(int(opts['w']), int(opts['h']))

        def set_collapsed(self, opts):
            self._outer.set_collapsed(
                bool(opts.get('collapsed')), int(opts.get('w', 0)), int(opts.get('h', 0)))

    def create(self):
        import webview
        self._window = webview.create_window(
            'ServiceHub', self._url, js_api=self._Api(self),
            width=WIN_W, height=WIN_H, min_size=(140, 38),  # 최소화(미니바) 높이 허용
            frameless=True, on_top=True, hidden=True, resizable=True,
        )
        return self._window

    def start(self):
        import webview
        import threading
        import time

        def place_later():
            time.sleep(1.5)  # 창 핸들이 준비될 때까지 대기 후 배치
            self._place()

        threading.Thread(target=place_later, daemon=True).start()
        webview.start()  # 메인 스레드 블로킹(GUI 이벤트 루프)

    def _move_br(self, w: int, h: int):
        # 작업영역 우하단에 (w,h)로 배치(하단 고정). MoveWindow는 cross-thread 허용.
        hd = self._hwnd()
        if not hd:
            return
        wa = _work_rect()
        x = max(wa.left, wa.right - w - MARGIN)
        y = max(wa.top, wa.bottom - h - MARGIN)
        ctypes.windll.user32.MoveWindow(hd, x, y, w, h, True)

    def _place(self):
        # 시작 시 실제 창 크기를 읽어 우하단 배치(DPI/멀티모니터 보정)
        w, h = self.get_size()
        if w <= 0 or w > 4000:
            w, h = WIN_W, WIN_H
        self._expanded = (w, h)
        self._move_br(w, h)

    def get_size(self):
        u = ctypes.windll.user32
        hd = self._hwnd()
        if not hd:
            return [WIN_W, WIN_H]
        rc = _RECT()
        u.GetWindowRect(hd, ctypes.byref(rc))
        return [rc.right - rc.left, rc.bottom - rc.top]

    def resize_to(self, w: int, h: int):
        # 그립 드래그로 호출. 우하단 고정 리사이즈 + 펼친 크기 기억.
        w = max(MIN_W, min(w, 4000))
        h = max(MIN_H, min(h, 4000))
        self._expanded = (w, h)
        self._move_br(w, h)

    def set_collapsed(self, collapsed: bool, w: int = 0, h: int = 0):
        # 최소화 = 우하단 미니바로 축소(JS가 DPR 적용한 물리 크기 전달) / 복원 = 직전 펼친 크기
        if collapsed:
            self._move_br(w or BAR_W, h or BAR_H)
        else:
            self._move_br(*self._expanded)

    def _hwnd(self) -> int:
        # pywebview 6.x EdgeChromium은 GUI 스레드 밖의 show()/hide()를 무시한다.
        # 창 핸들을 잡아 cross-thread 허용되는 Win32 ShowWindow로 직접 토글한다.
        try:
            h = int(self._window.native.Handle)
            if h:
                return h
        except Exception:
            pass
        return ctypes.windll.user32.FindWindowW(None, 'ServiceHub')

    def toggle(self):
        self.hide() if self._visible else self.show()

    def show(self):
        h = self._hwnd()
        if h:
            ctypes.windll.user32.ShowWindow(h, 5)  # SW_SHOW
            ctypes.windll.user32.SetForegroundWindow(h)
            self._visible = True

    def hide(self):
        h = self._hwnd()
        if h:
            ctypes.windll.user32.ShowWindow(h, 0)  # SW_HIDE
            self._visible = False
