import json
import sys
from pathlib import Path


def _base_dir() -> Path:
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).parent
    return Path(__file__).parent.parent


def _detect_repo_root() -> Path:
    # ServiceHub(_base_dir) 기준 위로 올라가며 'my-claude-project'를 찾는다. 못 찾으면 3단계 상위.
    base = _base_dir()
    for p in [base, *base.parents]:
        if p.name == 'my-claude-project':
            return p
    return base.parents[2] if len(base.parents) >= 3 else base


_REPO_ROOT = _detect_repo_root()
CONFIG_PATH = _base_dir() / 'config.json'

DEFAULT_CONFIG = {
    'manager_port': 3050,
    'port_pool_start': 3060,
    'log_lines': 500,
    'roots': [
        '프로젝트/for_Local',
        '프로젝트/for_Release',
        '프로젝트/for_Drop',
        '에이전트',
        # 스캔은 root의 1단계 자식만 본다. 중첩 서비스는 부모 경로를 직접 등록
        '에이전트/notion-agents/agents',
    ],
    'overrides': {},
    'assigned_ports': {},
    'work_timer': {'started_at': None, 'today_date': None, 'today_seconds': 0},
    # 팀원 배포용: 첫 실행 온보딩(루트레포 선택)을 마쳤는지. roots가 실제로 존재하면 사실상 완료로 간주
    'onboarded': False,
}


def is_onboarded(cfg: dict) -> bool:
    if cfg.get('onboarded'):
        return True
    # 스캔 대상 root가 하나라도 실제로 존재하면 이미 설정된 환경으로 본다(기존 모노레포 사용자)
    return any(p.exists() for p in resolve_roots(cfg.get('roots', [])))


def resolve_roots(roots: list[str]) -> list[Path]:
    out = []
    for r in roots:
        p = Path(r)
        out.append(p if p.is_absolute() else _REPO_ROOT / p)
    return out


def load_config() -> dict:
    if not CONFIG_PATH.exists():
        save_config(DEFAULT_CONFIG)
        return DEFAULT_CONFIG.copy()
    with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
        cfg = json.load(f)
    for k, v in DEFAULT_CONFIG.items():
        cfg.setdefault(k, v)
    return cfg


def save_config(cfg: dict) -> None:
    with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
