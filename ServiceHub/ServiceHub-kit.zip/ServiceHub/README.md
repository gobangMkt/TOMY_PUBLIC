# ServiceHub

## 개요
`my-claude-project`의 로컬 서비스(웹앱·워커)를 **한 곳에서 발견·시작·중지·모니터링**하는 트레이 상주 통합 관리 허브. 여러 포트의 로컬 프로젝트를 일일이 터미널로 띄우던 1인 개발 환경을, 트레이 아이콘 + `localhost:3050` 대시보드 하나로 묶는다.

## 코어

### 핵심 기능
- **첫 실행 온보딩** — 팀원이 받아 처음 열면 대시보드가 "루트레포 폴더 선택" 화면을 띄운다. 고른 폴더의 하위를 스캔해 서비스 있는 폴더를 자동추천 → 체크로 확정하면 그 절대경로가 `config.roots`에 저장돼 이후 그 레포를 관리한다(모노레포 이름 탐지에 의존하지 않음). 기존 모노레포 사용자는 자동 스킵.
- 트레이 상주 + `localhost:3050` 대시보드 (콘솔 창 없이 동작)
- **미니뷰 토글** — 트레이 메뉴 + 대시보드 헤더 "미니뷰" 버튼 양쪽에서 위젯 표시/숨김
- 지정 루트 폴더를 스캔해 **서비스 자동 발견** — `시작*.bat`의 포트/기동 명령, `package.json` 의존성으로 web/task 분류
- 대시보드에서 서비스 **시작/중지** — 창 없이 spawn, 종료 시 자식 프로세스 트리킬
- **포트 자동 조율** — 서비스마다 유니크 포트 배정, 충돌 시 풀(`3060`+)에서 할당하고 config에 영속화
- WebSocket으로 상태·로그 실시간 표시
- 트레이에서 토글하는 미니뷰 위젯(pywebview, WebView2 런타임 사용)
- **Claude 계정 사용량 표시** — 한도 소진율(세션/주간/Sonnet %, `api.anthropic.com/api/oauth/usage` 2분 폴링)과 로컬 토큰 집계(일별·모델별·누적, `~/.claude/stats-cache.json`)를 대시보드·미니뷰에 함께 표시
- **업무 타이머** — 전역 단일 타이머(RoutineLog 운동 타이머와 동일 원리). 시작 절대시각만 저장해 경과를 매초 계산(재시작·새로고침해도 이어짐), 오늘 누적(자정 리셋). 자정/12시간 가드 자동종료. 대시보드 헤더 칩 + 미니뷰 상단 타이머 바, **최소화 시에도 경과시간 노출**
- **미니뷰 대시보드 바로가기** — 미니뷰 헤더에서 브라우저로 대시보드(`localhost`) 열기

### 기술 스택
Python 3.10–3.13 권장 · FastAPI · uvicorn · websockets · psutil · pystray · Pillow · winotify · pywebview · PyInstaller · pytest
> 3.14는 동작하지만 `pythonnet`/`pywebview` 휠이 버전별이라 빌드툴이 없으면 설치가 실패할 수 있다. 가급적 3.11~3.13 사용.

### 동작 구조
1. 트레이 기동 → `roots` 폴더 스캔 → 서비스 자동 발견(web/task)
2. `registry`가 포트를 유니크 배정(충돌 시 `port_pool_start`=3060 풀) → `config.json`에 영속화
3. 대시보드에서 시작/중지 → `supervisor`가 창 없이 spawn / 프로세스 트리킬
4. `server`(FastAPI)가 WebSocket으로 상태·로그를 대시보드·미니뷰에 실시간 브로드캐스트
5. 매니저(127.0.0.1)는 uvicorn을 데몬 스레드로, 미니뷰(pywebview)는 메인 스레드, 트레이(pystray)는 전용 스레드에서 각자 Win32 메시지 루프로 구동
6. `server` 백그라운드 폴러가 2분마다 `usage.fetch_limits()`(OAuth 토큰은 `~/.claude/.credentials.json`)로 한도 %를 받아 `kind:'usage'` WS 푸시 → 게이지 갱신. 로컬 토큰 집계는 `/api/usage` 요청 시 `stats-cache.json`에서 계산

```
src/
├─ main.py        진입점 (스레드 구성: uvicorn/tray/webview)
├─ config.py      config.json 로드·저장, roots 경로 해석
├─ scanner.py     루트 스캔 → 서비스 발견(bat 파싱·의존성 분류)
├─ registry.py    서비스 레지스트리 + 포트 유니크 배정/영속화
├─ supervisor.py  프로세스 spawn·트리킬·로그 버퍼
├─ server.py      FastAPI 앱 + WebSocket 브로드캐스트 + 사용량 폴러
├─ usage.py       Claude 사용량 — OAuth 한도 % + stats-cache 토큰 집계
├─ timer.py       업무 타이머 — 시작시각 저장·경과 계산·자정/12h 가드
├─ tray.py        시스템 트레이 아이콘·메뉴
├─ miniview.py    pywebview 미니 위젯
└─ notifier.py    토스트 알림
```

## 실행/배포 방법
```
설치.bat            # 팀원 원샷 설치 — 의존성 설치·검증 후 콘솔 없이 기동 (install.ps1)
시작.vbs            # 평소 실행 — 콘솔 없이 트레이로만 동작 (pythonw src\main.py)
시작 3050.bat       # 콘솔 보며 실행(디버그, python src/main.py)
제거.bat            # 제거 — 부팅 자동실행 해제 + 이 폴더에서 띄운 프로세스 종료 (uninstall.ps1)
build.bat           # exe 빌드 (PyInstaller)
```
- **전제조건**: Python 3.10+ (PATH 등록). 미니뷰 위젯은 WebView2 런타임 필요 — 미설치 시 미니뷰만 비활성, 대시보드·트레이는 정상 동작.
- **포트**: 매니저 `3050`, 발견된 서비스 포트 풀 시작 `3060` (`config.json`에서 조정).
- **설정 (`config.json`)**: 시크릿 없음. `roots`(스캔 폴더, repo 루트 상대경로), `overrides`(서비스 id별 port/name/command/type/enabled 수동 지정), `assigned_ports`(매니저 자동 기록 — 편집 불필요).

### 테스트
```
python -m pytest tests/ -v
```

## 배포링크
- 로컬 접속: `http://localhost:3050`
- 실행 `.bat`: `프로젝트\for_Local\ServiceHub\시작 3050.bat` (디버그) / 평소엔 `시작.vbs`

---

## 팀원 로컬 설치 — 설치킷

> 이 폴더(zip 또는 `git clone`)를 받은 팀원은 **폴더에서 Claude Code를 열고 아래 한 줄만** 말하면 끝. Claude가 설치·기동·온보딩까지 대신 한다. Claude가 없으면 `설치.bat` 더블클릭으로도 된다.
>
> ```
> README의 '팀원 로컬 설치' 런북대로 설치해줘.
> ```

### 👉 팀원 Claude가 그대로 실행하는 런북

**Claude에게: 아래를 위에서부터 순서대로 실행하라. 각 단계는 검증까지 포함하며, 실패 시 다음으로 넘어가지 말고 그 줄의 조치를 사용자에게 안내하라. 이 폴더(README가 있는 곳)를 작업 디렉터리로 삼는다.**

1. **Python 확인** — `python --version`.
   - 없거나 3.11 미만이면 **여기서 멈추고** 사용자에게 안내: "https://www.python.org/downloads/ 에서 Python 3.11~3.13 설치(설치 첫 화면 **'Add python.exe to PATH' 체크**) 후 다시 불러 주세요." (Claude는 Python 자체를 대신 설치하지 말 것.)
2. **원샷 설치·기동** — `powershell -ExecutionPolicy Bypass -NoProfile -File .\install.ps1`.
   - 의존성 설치 → 검증 → 콘솔 없이 트레이로 기동까지 수행한다. 끝에 "기동 확인 (200이면 성공)" 이 나오면 성공.
   - `install.ps1`이 막히면 폴백: `python -m pip install -r requirements.txt` → `python -c "import fastapi,uvicorn,psutil,pystray,PIL,winotify;print('OK')"` → `Start-Process (python -c "import sys,os;print(os.path.join(os.path.dirname(sys.executable),'pythonw.exe'))") -ArgumentList "src\main.py" -WorkingDirectory (Get-Location)`.
3. **기동 검증** — `Invoke-WebRequest http://localhost:3050 -UseBasicParsing -TimeoutSec 6` 이 **200**이면 OK. (이미 실행 중이면 install.ps1이 중복 실행을 막고 그대로 통과.)
4. **온보딩 (루트레포 지정) — Claude가 API로 대신 처리**:
   1. 사용자에게 **딱 하나만 질문**: "ServiceHub로 관리할 **루트레포 폴더의 절대경로**를 알려주세요 (예: `C:\work\my-repo`). 그 안의 프로젝트들을 자동 발견합니다." (이 경로는 사용자만 안다.)
   2. **먼저 UTF-8 헬퍼 정의** (한글 경로/이름이 있으면 필수 — PS5.1은 기본 바디를 UTF-8로 안 보냄):
      ```powershell
      function PostJson($url,$obj){
        $body=[System.Text.Encoding]::UTF8.GetBytes(($obj|ConvertTo-Json))
        Invoke-RestMethod -Method Post $url -ContentType 'application/json; charset=utf-8' -Body $body
      }
      ```
      받은 경로로 후보 조회:
      ```powershell
      $folder = 'C:\work\my-repo'   # ← 사용자가 준 경로
      $pv = PostJson 'http://localhost:3050/api/onboard/preview' @{folder=$folder}; $pv | ConvertTo-Json -Depth 5
      ```
      `ok:false`면 경로가 잘못된 것 → 사용자에게 재확인. `candidates`가 뜨면 각 항목의 `label`·`count`(발견 서비스 수)를 사용자에게 보여주고, `recommended:true`(서비스 있는 폴더)를 기본 선택으로 제안.
   3. 사용자가 확정하면 그 후보들의 `path`만 저장:
      ```powershell
      $roots = $pv.candidates | Where-Object { $_.recommended } | ForEach-Object { $_.path }   # 또는 사용자가 고른 것만
      $save = PostJson 'http://localhost:3050/api/onboard/save' @{roots=$roots}; $save | ConvertTo-Json
      ```
      `ok:true, count:N` 이면 완료(N개 서비스 발견). 저장 즉시 대시보드가 갱신된다.
   - (수동 대안: 브라우저로 `http://localhost:3050` 열면 같은 온보딩 화면이 뜬다 — 경로 붙여넣기/찾기 → 체크 → 시작하기.)
5. **완료 보고** — 사용자에게: "설치·기동·온보딩 완료. 트레이 아이콘(작업표시줄 우측 `^` 영역)과 http://localhost:3050 에서 확인하세요." + 아래 **선택 옵션** 안내.

### 직접 설치 (Claude 없이)
1. 폴더를 받는다(위치 무관 — 모노레포 안이든 단독이든).
2. **`설치.bat`** 더블클릭 → 의존성 설치·검증 후 트레이로 기동. (Python 없으면 안내 → 설치 후 재실행.)
3. `http://localhost:3050` → **첫 화면 온보딩**에서 루트레포 폴더 선택(경로 붙여넣기/찾기 → 체크 → 시작하기).

### 선택 옵션 (환경마다 다름 — 원하면)
- **부팅 시 자동 실행**: 트레이 아이콘 우클릭 → **"부팅 시 자동 시작"** 토글. (또는 설치 시 `powershell -ExecutionPolicy Bypass -File install.ps1 -Autostart`.)
- **미니뷰 위젯**: 트레이 우클릭 → "미니뷰 표시/숨김", 또는 대시보드 헤더 **"미니뷰"** 버튼. WebView2 런타임이 없으면 미니뷰만 비활성(대시보드·트레이는 정상). 필요 시 [WebView2 Runtime](https://developer.microsoft.com/microsoft-edge/webview2/) 설치.
- **제거**: **`제거.bat`** 더블클릭 → 부팅 자동실행 해제 + 이 폴더에서 띄운 프로세스 종료. (소스·설정은 남음, 완전 삭제는 폴더 삭제.)

### 사전 전제
- **OS**: Windows 10/11.
- **Python**: 3.11~3.13 권장(3.14는 `pywebview`/`pythonnet` 휠 부재로 미니뷰 설치가 실패할 수 있음 — 대시보드·트레이는 정상).
- **Node.js**(선택): web(node) 서비스를 시작/모니터링할 때만. 없으면 ServiceHub 본체·python 서비스는 정상, **web 서비스만** 시작 불가.
- **위치는 무관**: 모노레포(`my-claude-project`) 안에 둘 필요 없다. 온보딩에서 고른 폴더의 절대경로가 `config.roots`에 저장된다.

성공 기준: **200 + 트레이 아이콘(숨김 `^` 영역) 표시.** 이후 브라우저 `http://localhost:3050`에서 온보딩으로 루트레포 선택.

### 트러블슈팅 (증상 → 원인 → 조치)

| 증상 | 원인 | 조치 |
|------|------|------|
| `설치.bat`이 "Python이 없습니다" | PATH에 Python 없음 | Python 3.11~3.13 설치(Add to PATH 체크) 후 재실행 |
| 온보딩에서 **"찾기"가 안 열림** | frozen/권한 등 | 폴더 경로를 왼쪽 입력란에 **직접 붙여넣기** (예: `C:\work\my-repo`) 후 Enter |
| 온보딩에서 **후보가 안 뜸(0)** | 고른 폴더에 서비스가 없음 | 상위/다른 폴더 선택. 서비스는 `package.json`·시작 bat·`*.py`+실행수단이 있는 폴더의 1단계 자식으로 인식됨 |
| 미니뷰 토스트 `No module named 'webview'` | `pywebview` 미설치 | `python -m pip install pywebview` 후 재기동. 대시보드는 정상이라 무시 가능 |
| 미니뷰 토스트 `WebView2 런타임 확인` | Edge WebView2 런타임 없음 | [WebView2 Runtime](https://developer.microsoft.com/microsoft-edge/webview2/) 설치. 미니뷰만 영향 |
| 대시보드 200 아님 / `시작.vbs` 무반응 | ① 이미 실행 중(3050 점유) ② pythonw 미존재 | `Get-NetTCPConnection -LocalPort 3050 -State Listen` 확인. 떠 있으면 정상(중복 실행이 조용히 실패). 아니면 재설치 |
| **온보딩이 다시 안 뜸**(재설정하고 싶음) | 이미 `onboarded:true` | `config.json`에서 `"onboarded": false`로 바꾸고 `roots`를 비운 뒤 재기동, 또는 트레이 "설정 파일 열기"에서 `roots` 직접 수정 |
| web 서비스 시작 시 멈춤/에러 | Node 미설치, 또는 pnpm/yarn 매니저 없음 | Node.js 설치. `node_modules` 없으면 자동 `npm/pnpm/yarn install` 후 실행 |
| `pip install` 중 `pythonnet` 빌드 실패 | Python 3.14 등 휠 부재 | Python 3.11~3.13 사용 |

### 완전 재시작이 필요할 때
```powershell
Get-Process pythonw -ErrorAction SilentlyContinue | Stop-Process -Force   # 모든 pythonw 종료(주의: 다른 python 트레이앱도 함께 꺼짐)
# 이후 install.ps1 재실행 또는 시작.vbs
```
