@echo off
chcp 65001
cd /d "%~dp0"
echo [ServiceHub] PyInstaller 빌드...
pyinstaller --onefile --windowed --name ServiceHub ^
  --add-data "static;static" --add-data "config.json;." ^
  --collect-all webview --hidden-import clr ^
  src/main.py
echo [완료] dist/ServiceHub.exe
pause
