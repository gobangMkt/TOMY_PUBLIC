const groupsEl = document.getElementById('groups');
const drawer = document.getElementById('log-drawer');
const logBody = document.getElementById('log-body');
const logTitle = document.getElementById('log-title');
let openLogId = null;
const cards = new Map();
const history = [];          // 실행중 수 시계열(클라 누적, 최근 30틱)
const HIST_MAX = 30;
const kpiVals = {};          // 카운트업 현재값 캐시

async function api(path, method = 'GET') {
  const r = await fetch(path, { method });
  return r.json();
}

/* fill-only 아이콘 (viewBox 0 0 20 20, stroke 없음) */
const IC = {
  play: '<svg class="ic" viewBox="0 0 20 20" aria-hidden="true"><path d="M6 4.5v11l9-5.5z"/></svg>',
  stop: '<svg class="ic" viewBox="0 0 20 20" aria-hidden="true"><rect x="5" y="5" width="10" height="10" rx="2"/></svg>',
  open: '<svg class="ic" viewBox="0 0 20 20" aria-hidden="true"><path d="M11 3h6v6l-2.3-2.3-3.6 3.6-1.4-1.4 3.6-3.6z"/><path d="M5 5h4v2H7v6h6v-2h2v4H5z"/></svg>',
  logs: '<svg class="ic" viewBox="0 0 20 20" aria-hidden="true"><rect x="4" y="5.5" width="12" height="1.8" rx=".9"/><rect x="4" y="9.1" width="12" height="1.8" rx=".9"/><rect x="4" y="12.7" width="8" height="1.8" rx=".9"/></svg>',
  claude: '<svg class="ic" viewBox="0 0 20 20" aria-hidden="true"><path d="M10 1.5l1.7 5.1 5.1 1.7-5.1 1.7L10 15.1l-1.7-5.1L3.2 8.3l5.1-1.7z"/></svg>',
  folder: '<svg class="ic" viewBox="0 0 20 20" aria-hidden="true"><path d="M2.5 5.6A1.6 1.6 0 0 1 4.1 4h3l1.6 2H16a1.6 1.6 0 0 1 1.6 1.6v5.8A1.6 1.6 0 0 1 16 15H4.1a1.6 1.6 0 0 1-1.6-1.6z"/></svg>',
};

const RUNNING = new Set(['running', 'starting', 'external']);
const STATUS = {
  running: { label: '실행중', color: 'var(--accent)' },
  external: { label: '실행중(외부)', color: 'var(--accent2)' },
  starting: { label: '시작중', color: 'var(--warn)' },
  stopped: { label: '중지', color: 'var(--dim)' },
  error: { label: '오류', color: 'var(--err)' },
  exited: { label: '완료', color: 'var(--info)' },
  idle: { label: '폴더', color: 'var(--dim)' },
};
const statusLabel = (s) => (STATUS[s] || { label: s }).label;
const statusColor = (s) => (STATUS[s] || { color: 'var(--dim)' }).color;
const ROOT_SHORT = (r) => r.replace('프로젝트/', '').replace('에이전트', 'agent');

/* ───────── 통계 ───────── */
function computeStats(services) {
  const st = { total: services.length, up: 0, ext: 0, stopped: 0, error: 0,
    byStatus: {}, byRoot: {} };
  for (const s of services) {
    st.byStatus[s.status] = (st.byStatus[s.status] || 0) + 1;
    const rk = ROOT_SHORT(s.root);
    st.byRoot[rk] = st.byRoot[rk] || { up: 0, total: 0 };
    st.byRoot[rk].total++;
    if (RUNNING.has(s.status)) { st.up++; st.byRoot[rk].up++; }
    if (s.status === 'external') st.ext++;
    if (s.status === 'error') st.error++;
    if (s.status === 'stopped') st.stopped++;
  }
  return st;
}

/* ───────── 카운트업 애니메이션 ───────── */
function animateCount(el, to) {
  const key = el.dataset.k;
  const from = kpiVals[key] ?? 0;
  if (from === to) { el.textContent = to; return; }
  kpiVals[key] = to;
  const dur = 600, t0 = performance.now();
  const tick = (now) => {
    const p = Math.min(1, (now - t0) / dur);
    const e = 1 - Math.pow(1 - p, 3);
    el.textContent = Math.round(from + (to - from) * e);
    if (p < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

/* ───────── 상단 컴팩트 칩 ───────── */
const CHIP_DEFS = [
  { k: 'total', label: '전체', c: 'var(--text)', cls: '' },
  { k: 'up', label: '가동', c: 'var(--accent)', cls: 'live' },
  { k: 'ext', label: '외부', c: 'var(--accent2)', cls: '' },
  { k: 'stopped', label: '중지', c: 'var(--dim)', cls: '' },
];
function renderChips(st) {
  const el = document.getElementById('stat-chips');
  if (!el.children.length) {
    el.innerHTML = CHIP_DEFS.map((d) =>
      `<span class="chip ${d.cls}" style="--c:${d.c}"><b data-k="${d.k}">0</b>${d.label}</span>`).join('');
  }
  for (const d of CHIP_DEFS) animateCount(el.querySelector(`[data-k="${d.k}"]`), st[d.k]);
}

/* ───────── 도넛(상태 분포) ───────── */
const DONUT_ORDER = ['running', 'external', 'starting', 'exited', 'error', 'stopped'];
const R = 52, C = 2 * Math.PI * R;
function renderDonut(st) {
  const segs = document.getElementById('donut-segs');
  const total = st.total || 1;
  let offset = 0;
  segs.innerHTML = '';
  for (const key of DONUT_ORDER) {
    const n = st.byStatus[key] || 0;
    if (!n) continue;
    const frac = n / total;
    const len = frac * C;
    const c = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    c.setAttribute('cx', 60); c.setAttribute('cy', 60); c.setAttribute('r', R);
    c.setAttribute('stroke', statusColor(key));
    c.setAttribute('stroke-dasharray', `${Math.max(0, len - 2)} ${C - Math.max(0, len - 2)}`);
    c.setAttribute('stroke-dashoffset', -offset);
    segs.appendChild(c);
    offset += len;
  }
  animateCount(document.getElementById('donut-up'), st.up);
  document.getElementById('donut-total').textContent = `총 ${st.total}`;
  // 범례
  const legend = document.getElementById('legend');
  legend.innerHTML = DONUT_ORDER.filter((k) => st.byStatus[k])
    .map((k) => `<li><i style="background:${statusColor(k)}"></i>${statusLabel(k)} ${st.byStatus[k]}</li>`).join('');
}

/* ───────── Sparkline(가동 추이) ───────── */
function pushHistory(up) {
  history.push(up);
  if (history.length > HIST_MAX) history.shift();
}
function renderSpark() {
  if (!history.length) return;
  const W = 300, H = 90, pad = 6;
  const max = Math.max(1, ...history);
  const n = history.length;
  const x = (i) => (n === 1 ? W / 2 : (i / (n - 1)) * W);
  const y = (v) => H - pad - (v / max) * (H - pad * 2);
  const pts = history.map((v, i) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`);
  const line = `M${pts.join(' L')}`;
  const area = `M${x(0).toFixed(1)},${H} L${pts.join(' L')} L${x(n - 1).toFixed(1)},${H} Z`;
  document.getElementById('spark-line').setAttribute('d', line);
  document.getElementById('spark-area').setAttribute('d', area);
  document.getElementById('spark-now').textContent = `현재 ${history[history.length - 1]}`;
  document.getElementById('spark-peak').textContent = `피크 ${max}`;
}

/* ───────── 루트별 분포 바 ───────── */
function renderRootBars(st) {
  const el = document.getElementById('rootbars');
  const entries = Object.entries(st.byRoot);
  const max = Math.max(1, ...entries.map(([, v]) => v.total));
  el.innerHTML = entries.map(([name, v]) => `
    <li>
      <span class="r-name" title="${name}">${name}</span>
      <span class="r-track"><span class="r-fill" style="width:${(v.total / max) * 100}%"></span></span>
      <span class="r-num">${v.up}/${v.total}</span>
    </li>`).join('');
}

function renderOverview(services) {
  const st = computeStats(services);
  renderChips(st);
  renderDonut(st);
  pushHistory(st.up);
  renderSpark();
  renderRootBars(st);
}

/* ───────── 서비스 카드 ───────── */
function pillHTML(s) {
  return `<span class="s-pill ${s.status}">${statusLabel(s.status)}</span>`;
}

function deployIconsHTML(s) {
  const urls = Array.isArray(s.deploy_urls) ? s.deploy_urls
    : (s.deploy_url ? [s.deploy_url] : []);
  if (!urls.length) return '';
  return urls.map((url, i) =>
    `<a class="deploy-icon" href="${url}" target="_blank" rel="noopener" title="${url}" aria-label="배포 링크${urls.length > 1 ? ` ${i + 1}` : ''}">${IC.open}</a>`
  ).join('');
}

function metaHTML(s) {
  const noPort = s.type === 'task' || s.type === 'folder';
  const portPart = noPort ? '' : `<span class="port">:${s.port ?? '-'}</span>`;
  return `<span class="tbadge ${s.type}">${s.type}</span>${portPart}`;
}

const isLive = (st) => st === 'running' || st === 'external';
function cardStateClass(st) {
  if (st === 'starting') return 'is-starting';
  if (isLive(st)) return 'is-live';
  if (st === 'stopped' || st === 'exited') return 'is-stopped';
  return '';
}

function render(services) {
  const byRoot = {};
  for (const s of services) (byRoot[s.root] ??= []).push(s);
  groupsEl.innerHTML = '';
  cards.clear();
  let idx = 0;
  for (const [root, list] of Object.entries(byRoot)) {
    // 실행중을 위로 정렬 → 실행 대상이 한눈에
    list.sort((a, b) => (RUNNING.has(b.status) - RUNNING.has(a.status)) || a.name.localeCompare(b.name, 'ko'));
    const upN = list.filter((s) => RUNNING.has(s.status)).length;
    const g = document.createElement('section');
    g.className = 'group';
    g.innerHTML = `<h2><span class="g-dot"></span>${ROOT_SHORT(root)}<span class="g-count"><b>${upN}</b> / ${list.length} 가동</span></h2><div class="grid"></div>`;
    const grid = g.querySelector('.grid');
    for (const s of list) grid.appendChild(card(s, idx++));
    groupsEl.appendChild(g);
  }
  renderOverview(services);
  applyFilter();
}

/* ───────── 검색 필터 (클라 측, 통계는 전체 기준 유지) ───────── */
let query = '';
const searchEl = document.getElementById('search');
const searchClear = document.getElementById('search-clear');
const searchEmpty = document.getElementById('search-empty');

function applyFilter() {
  let anyVisible = false;
  for (const g of groupsEl.querySelectorAll('.group')) {
    let groupVisible = false;
    for (const cardEl of g.querySelectorAll('.card')) {
      const c = cards.get(cardEl.dataset.id);
      const show = !c || matchService(c.svc, query);
      cardEl.style.display = show ? '' : 'none';
      if (show) groupVisible = true;
    }
    g.style.display = groupVisible ? '' : 'none';
    if (groupVisible) anyVisible = true;
  }
  const q = query.trim();
  if (q && !anyVisible) {
    searchEmpty.innerHTML = `<b>'${q}'</b>와 일치하는 서비스가 없습니다`;
    searchEmpty.hidden = false;
  } else {
    searchEmpty.hidden = true;
  }
}

function setQuery(v) {
  query = v;
  if (searchEl.value !== v) searchEl.value = v;
  searchClear.hidden = !v;
  applyFilter();
}

searchEl.oninput = () => setQuery(searchEl.value);
searchClear.onclick = () => { setQuery(''); searchEl.focus(); };

document.addEventListener('keydown', (e) => {
  const onSearch = document.activeElement === searchEl;
  if (e.key === 'Escape' && (onSearch || query)) { setQuery(''); searchEl.blur(); return; }
  if (onSearch) return;
  const tag = document.activeElement?.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA') return;
  if (e.key === '/' || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f')) {
    e.preventDefault();
    searchEl.focus();
    searchEl.select();
  }
});

function primaryHTML(s) {
  if (s.status === 'starting') return { cls: 'busy', html: '<span class="spin"></span>시작 중…', dis: true };
  if (isLive(s.status)) return { cls: 'halt', html: `${IC.stop}중지`, dis: false };
  return { cls: 'go', html: `${IC.play}${s.type === 'task' ? '실행' : '시작'}`, dis: false };
}

function card(s, idx = 0) {
  const el = document.createElement('div');
  el.className = `card ${cardStateClass(s.status)}`;
  el.style.animationDelay = `${Math.min(idx * 28, 480)}ms`;
  el.style.setProperty('--statc', statusColor(s.status));
  const isTask = s.type === 'task';
  const isFolder = s.type === 'folder';
  let btns;
  if (isFolder) {
    btns = `
      <button class="act act-primary go" data-act="claude">${IC.claude}Claude 열기</button>
      <button class="act act-icon" data-act="folder" title="폴더 열기" aria-label="폴더 열기">${IC.folder}</button>`;
  } else {
    const p = primaryHTML(s);
    // external(허브 밖에서 포트 점유) web → 시작이 중지로 가려져 재배정 기동을 못 건다.
    // '강제 시작' 노출: 충돌 시 백엔드가 빈 포트로 재배정 후 띄운다.
    const force = (!isTask && s.status === 'external')
      ? `<button class="act act-icon force" data-act="force" title="강제 시작 — 포트 충돌 시 빈 포트로 재배정 후 기동" aria-label="강제 시작">${IC.play}</button>`
      : '';
    btns = `
      <button class="act act-primary ${p.cls}" data-act="primary" ${p.dis ? 'disabled' : ''}>${p.html}</button>
      ${force}
      ${isTask ? '' : `<button class="act act-icon" data-act="open" title="열기" aria-label="열기">${IC.open}</button>`}
      <button class="act act-icon" data-act="claude" title="Claude 열기" aria-label="Claude 열기">${IC.claude}</button>
      <button class="act act-icon" data-act="folder" title="폴더 열기" aria-label="폴더 열기">${IC.folder}</button>
      <button class="act act-icon" data-act="logs" title="로그" aria-label="로그">${IC.logs}</button>`;
  }
  el.dataset.id = s.id;
  el.innerHTML = `
    <div class="top">
      <span class="name" title="${s.name}">${s.name}</span>
      <div class="top-right">
        ${deployIconsHTML(s)}
        ${isFolder ? '' : pillHTML(s)}
      </div>
    </div>
    <div class="meta">${metaHTML(s)}</div>
    <div class="btns">${btns}</div>`;

  const primaryBtn = el.querySelector('[data-act="primary"]');
  if (primaryBtn) primaryBtn.onclick = async () => {
    const cur = cards.get(s.id).svc.status;
    if (cur === 'starting') return;
    if (isLive(cur)) {
      applyStatus({ id: s.id, status: 'stopped' });
      await api(`/api/services/${s.id}/stop`, 'POST');
    } else {
      applyStatus({ id: s.id, status: 'starting' });
      await api(`/api/services/${s.id}/${isTask ? 'run' : 'start'}`, 'POST');
    }
    setTimeout(refresh, 1100);
  };
  const forceBtn = el.querySelector('[data-act="force"]');
  if (forceBtn) forceBtn.onclick = async () => {
    applyStatus({ id: s.id, status: 'starting' });
    await api(`/api/services/${s.id}/start`, 'POST');  // 포트 점유 시 백엔드가 재배정 후 기동
    setTimeout(refresh, 1100);
  };
  const openBtn = el.querySelector('[data-act="open"]');
  if (openBtn) openBtn.onclick = () => window.open(`http://localhost:${s.port}`, '_blank');
  el.querySelector('[data-act="claude"]').onclick = () => api(`/api/services/${s.id}/open-claude`, 'POST');
  const folderBtn = el.querySelector('[data-act="folder"]');
  if (folderBtn) folderBtn.onclick = () => api(`/api/services/${s.id}/open-folder`, 'POST');
  const logsBtn = el.querySelector('[data-act="logs"]');
  if (logsBtn) logsBtn.onclick = () => showLogs(s);
  cards.set(s.id, { el, svc: s });
  return el;
}

function applyStatus(s) {
  const c = cards.get(s.id);
  if (!c) return false;
  const justStarted = !isLive(c.svc.status) && isLive(s.status); // 실행중으로 막 전환
  c.svc.status = s.status;
  const el = c.el;
  if (justStarted) {
    el.classList.remove('igniting');
    void el.offsetWidth;            // reflow → 애니메이션 재생 보장
    el.classList.add('igniting');
    setTimeout(() => el.classList.remove('igniting'), 950);
  }
  el.className = `card ${cardStateClass(s.status)}`;
  const pill = el.querySelector('.s-pill');
  if (pill) {
    pill.className = `s-pill ${s.status}`;
    pill.textContent = statusLabel(s.status);
  }
  el.style.setProperty('--statc', statusColor(s.status));
  const pb = el.querySelector('[data-act="primary"]');
  if (pb) {
    const p = primaryHTML(c.svc);
    pb.className = `act act-primary ${p.cls}`;
    pb.innerHTML = p.html;
    pb.disabled = p.dis;
  }
  return true;
}

async function refresh() {
  const services = await api('/api/services');
  let structureChanged = false;
  for (const s of services) { if (!applyStatus(s)) structureChanged = true; }
  if (structureChanged || cards.size !== services.length) render(services);
  else renderOverview(services);
}

async function showLogs(s) {
  openLogId = s.id;
  logTitle.textContent = `${s.name} · 로그`;
  const { logs } = await api(`/api/services/${s.id}/logs`);
  logBody.textContent = logs.join('\n');
  logBody.scrollTop = logBody.scrollHeight;
  drawer.classList.remove('hidden');
}

const ovToggle = document.getElementById('ov-toggle');
const overview = document.getElementById('overview');
ovToggle.onclick = () => {
  const open = overview.classList.toggle('collapsed') === false;
  ovToggle.setAttribute('aria-expanded', String(open));
  if (open) renderSpark();
};

function showToast(msg, ok = true) {
  const t = document.createElement('div');
  t.className = 'toast';
  t.style.color = ok ? 'var(--accent)' : 'var(--err)';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 300); }, 3000);
}

document.getElementById('log-close').onclick = () => { drawer.classList.add('hidden'); openLogId = null; };
document.getElementById('stop-all').onclick = async () => { await api('/api/stop-all', 'POST'); setTimeout(refresh, 1000); };

/* ───────── 업무 타이머 (헤더 칩) ───────── */
const timerEl = document.getElementById('work-timer');
const tpad = (n) => String(n).padStart(2, '0');
function fmtElapsed(sec) {
  sec = Math.max(0, Math.floor(sec));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return h ? `${h}:${tpad(m)}:${tpad(s)}` : `${tpad(m)}:${tpad(s)}`;
}
function fmtToday(sec) {
  const m = Math.floor(Math.max(0, sec) / 60), h = Math.floor(m / 60);
  return h ? `${h}시간 ${m % 60}분` : `${m}분`;
}

let workTimer = { running: false, started_at: null, today_seconds: 0 };
let workTick = null;
function liveElapsed() {
  if (!workTimer.running || !workTimer.started_at) return 0;
  return (Date.now() - new Date(workTimer.started_at).getTime()) / 1000;
}
function paintTimer() {
  const run = workTimer.running, el = liveElapsed();
  timerEl.classList.toggle('running', run);
  if (run) {
    const today = (workTimer.today_seconds || 0) + el;
    timerEl.innerHTML =
      `<span class="wt-dot"></span><span class="wt-label">업무중</span>` +
      `<span class="wt-elapsed">${fmtElapsed(el)}</span>` +
      `<span class="wt-today">· 오늘 ${fmtToday(today)}</span>` +
      `<button class="wt-btn stop" data-tact="stop">${IC.stop}종료</button>`;
  } else {
    timerEl.innerHTML =
      (workTimer.today_seconds ? `<span class="wt-today">오늘 ${fmtToday(workTimer.today_seconds)}</span>` : '') +
      `<button class="wt-btn go" data-tact="start">${IC.play}업무 시작</button>`;
  }
  timerEl.querySelector('[data-tact]').onclick = (e) => onTimer(e.currentTarget.dataset.tact);
}
function startTick() { if (!workTick) workTick = setInterval(paintTimer, 1000); }
function stopTick() { if (workTick) { clearInterval(workTick); workTick = null; } }
function applyTimer(s) {
  if (!s) return;
  workTimer = s;
  paintTimer();
  s.running ? startTick() : stopTick();
  if (s.auto_stopped) {
    showToast(s.auto_stopped === 'long_run'
      ? '장시간 감지로 업무 타이머가 자동 종료됐습니다' : '자정이 지나 업무 타이머가 자동 종료됐습니다', true);
  }
}
async function onTimer(act) {
  if (act === 'start') {
    workTimer = { ...workTimer, running: true, started_at: new Date().toISOString() };
    paintTimer(); startTick();
    applyTimer(await api('/api/timer/start', 'POST'));
  } else {
    stopTick();
    applyTimer(await api('/api/timer/stop', 'POST'));
  }
}
async function loadTimer() { try { applyTimer(await api('/api/timer')); } catch (e) { /* noop */ } }
document.getElementById('rescan').onclick = async () => { await api('/api/rescan', 'POST'); load(); };
document.getElementById('miniview').onclick = async () => {
  try { await api('/api/miniview/toggle', 'POST'); } catch (e) { /* WebView2 미설치 등 — 무시 */ }
};
document.getElementById('sync-bats').onclick = async () => {
  const { results } = await api('/api/sync-bats', 'POST');
  const synced = results.filter(r => r.action === 'synced').length;
  const removed = results.filter(r => r.action === 'removed').length;
  const errors = results.filter(r => r.action === 'error').length;
  const msg = errors
    ? `bat 정리 완료 (오류 ${errors}개)`
    : `bat 정리 완료 · ${synced}개 갱신${removed ? `, ${removed}개 제거` : ''}`;
  showToast(msg, !errors);
};

const MODEL_COLORS = { opus: '#a78bfa', sonnet: '#54c7b8', haiku: '#e0a0c8' };
const STATUS_LABEL = {
  ok: '', init: '연결 중…', needs_login: '재로그인 필요',
  no_credentials: '연결 안 됨', network: '연결 실패', http_error: '연결 실패',
};

function resetIn(iso) {
  if (!iso) return '';
  const ms = new Date(iso) - new Date();
  if (ms <= 0) return '곧 재설정';
  const h = Math.floor(ms / 3.6e6), m = Math.floor((ms % 3.6e6) / 6e4);
  if (h >= 24) return `${Math.floor(h / 24)}일 후 재설정`;
  return h ? `${h}시간 ${m}분 후 재설정` : `${m}분 후 재설정`;
}

function fmtTok(n) {
  if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
  return String(n);
}

function renderGauges(limits, status) {
  const lim = limits || {};
  const rows = [
    ['세션', lim.session],
    ['주간 전체', lim.weekly_all],
    [(lim.weekly_scoped && lim.weekly_scoped.label) || 'Sonnet', lim.weekly_scoped],
  ];
  const el = document.getElementById('gauges');
  if (!limits && status && status !== 'ok') {
    const relogin = status === 'needs_login'
      ? ` <button class="relogin-btn" id="relogin-btn" type="button">지금 재로그인</button>` : '';
    el.innerHTML = `<div class="gauge-empty">${STATUS_LABEL[status] || '사용량 없음'}${relogin}</div>`;
    if (status === 'needs_login') document.getElementById('relogin-btn').onclick = doRelogin;
    return;
  }
  el.innerHTML = rows.map(([name, d]) => {
    const pct = (d && d.percent != null) ? d.percent : 0;
    const sev = (d && d.severity === 'warning') ? ' warn' : '';
    return `<div class="gauge"><div class="g-top"><span>${name}</span><b>${pct}%</b></div>
      <div class="g-track"><i class="g-fill${sev}" style="width:${Math.min(100, pct)}%"></i></div>
      <div class="g-sub">${d ? resetIn(d.resets_at) : ''}</div></div>`;
  }).join('');
}

let usageDaily = [];
let selDay = -1;

function renderUsageBars(daily) {
  usageDaily = daily || [];
  const svg = document.getElementById('u-bars');
  const labels = document.getElementById('u-bar-days');
  svg.innerHTML = '';
  labels.innerHTML = '';
  const sub = document.getElementById('u-daysub');
  if (!usageDaily.length) { if (sub) sub.textContent = ''; return; }
  const max = Math.max(...usageDaily.map(d => d.tokens), 1);
  const n = usageDaily.length, gap = 2, w = (300 - gap * (n - 1)) / n;
  const NS = 'http://www.w3.org/2000/svg';
  usageDaily.forEach((d, i) => {
    const h = Math.max(1, (d.tokens / max) * 84);
    const r = document.createElementNS(NS, 'rect');
    r.setAttribute('x', (i * (w + gap)).toFixed(1));
    r.setAttribute('y', (90 - h).toFixed(1));
    r.setAttribute('width', w.toFixed(1));
    r.setAttribute('height', h.toFixed(1));
    r.setAttribute('rx', '1');
    r.setAttribute('fill', 'var(--accent)');
    r.style.cursor = 'pointer';
    r.onclick = () => selectDay(i);
    const t = document.createElementNS(NS, 'title');
    t.textContent = `${d.date}: ${fmtTok(d.tokens)} tok`;
    r.appendChild(t);
    svg.appendChild(r);
    const lab = document.createElement('button');
    lab.type = 'button';
    lab.className = 'u-day';
    lab.textContent = (d.date || '').slice(8);  // DD
    lab.title = d.date || '';
    lab.onclick = () => selectDay(i);
    labels.appendChild(lab);
  });
  if (selDay < 0 || selDay >= n) selDay = n - 1;  // 기본: 최신일 선택
  selectDay(selDay);
}

function selectDay(i) {
  selDay = i;
  const d = usageDaily[i];
  const svg = document.getElementById('u-bars');
  [...svg.children].forEach((r, idx) => r.setAttribute('opacity', idx === i ? '1' : '0.5'));
  const labels = document.getElementById('u-bar-days');
  [...labels.children].forEach((l, idx) => l.classList.toggle('sel', idx === i));
  const sub = document.getElementById('u-daysub');
  if (sub && d) {
    const parts = Object.entries(d.byModel || {}).sort((a, b) => b[1] - a[1])
      .map(([f, t]) => `${f} ${fmtTok(t)}`).join(' · ');
    sub.innerHTML = `${d.date} · <b>${fmtTok(d.tokens)}</b> tok` + (parts ? ` · ${parts}` : '');
  }
}

function renderUsageDonut(byModel) {
  const segs = document.getElementById('u-donut-segs');
  segs.innerHTML = '';
  const legend = document.getElementById('u-legend');
  legend.innerHTML = '';
  const total = byModel.reduce((s, m) => s + m.tokens, 0) || 1;
  const C = 2 * Math.PI * 52;
  const NS = 'http://www.w3.org/2000/svg';
  let offset = 0;
  byModel.forEach(m => {
    const len = (m.tokens / total) * C;
    const c = document.createElementNS(NS, 'circle');
    c.setAttribute('cx', '60'); c.setAttribute('cy', '60'); c.setAttribute('r', '52');
    c.setAttribute('fill', 'none');
    c.setAttribute('stroke', MODEL_COLORS[m.family] || '#9aa4b2');
    c.setAttribute('stroke-width', '14');
    c.setAttribute('stroke-dasharray', `${Math.max(0, len - 2)} ${C - Math.max(0, len - 2)}`);
    c.setAttribute('stroke-dashoffset', (-offset).toFixed(1));
    c.setAttribute('transform', 'rotate(-90 60 60)');
    segs.appendChild(c);
    offset += len;
    const li = document.createElement('li');
    li.innerHTML = `<i style="background:${MODEL_COLORS[m.family] || '#9aa4b2'}"></i>` +
      `${m.family} <b>${Math.round(m.tokens / total * 100)}%</b>`;
    legend.appendChild(li);
  });
}

function renderUsageTotals(local) {
  const el = document.getElementById('usage-totals');
  if (!local || !local.available) { el.textContent = ''; return; }
  const t = local.totals;
  el.innerHTML =
    `<span>총 <b>${fmtTok(t.tokens)}</b> tok</span>` +
    `<span><b>${t.sessions}</b> 세션</span>` +
    `<span><b>${t.messages}</b> 메시지</span>` +
    `<span>~$<b>${local.cost}</b> <em>참고</em></span>` +
    (t.computedDate ? `<span class="u-asof">기준 ${t.computedDate}</span>` : '');
}

function renderUsageStatus(status) {
  const el = document.getElementById('usage-status');
  el.textContent = STATUS_LABEL[status] || '';
  el.className = 'usage-status' + (status && status !== 'ok' && status !== 'init' ? ' bad' : '');
}

async function doRelogin() {
  await api('/api/usage/relogin', 'POST');
  showToast('새 콘솔 창에서 Claude 로그인을 완료하세요');
}

async function loadUsage() {
  try {
    const u = await api('/api/usage');
    renderGauges(u.limits, u.status);
    renderUsageStatus(u.status);
    if (u.local) {
      renderUsageBars(u.local.daily);
      renderUsageDonut(u.local.byModel || []);
      renderUsageTotals(u.local);
    }
  } catch (e) { /* 사용량 실패는 대시보드 본 기능에 영향 없음 */ }
}

function connectWS() {
  const ws = new WebSocket(`ws://${location.host}/ws`);
  ws.onmessage = (e) => {
    const { id, kind, payload } = JSON.parse(e.data);
    if (kind === 'state') {
      const c = cards.get(id);
      if (c) { c.svc.status = payload; applyStatus(c.svc); }
    }
    if (kind === 'port') {
      const c = cards.get(id);
      if (c && c.svc.port !== payload) { c.svc.port = payload; load(); }
    }
    if (kind === 'log' && id === openLogId) {
      logBody.textContent += '\n' + payload;
      logBody.scrollTop = logBody.scrollHeight;
    }
    if (kind === 'usage') {
      renderGauges(payload.limits, payload.status);
      renderUsageStatus(payload.status);
    }
    if (kind === 'timer') applyTimer(payload);
  };
  ws.onclose = () => setTimeout(connectWS, 2000);
}

async function load() { render(await api('/api/services')); }
load();
loadUsage();
loadTimer();
connectWS();
setInterval(refresh, 3000);
setInterval(loadUsage, 300000);  // 일별 토큰 자동 갱신(자정 롤오버 포함)
