/* 서비스 검색 매칭 — 브라우저 전역 + node require 양립(빌드 없음) */
(function (root, factory) {
  const api = factory();
  if (typeof window !== 'undefined') Object.assign(window, api);
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(this, function () {
  // 대시보드/미니뷰가 화면에 쓰는 루트 라벨과 동일 규칙(검색 대상도 이 라벨)
  function rootShort(r) {
    return String(r || '').replace('프로젝트/', '').replace('에이전트', 'agent');
  }

  // 서비스가 검색어와 일치하는지. 빈 쿼리는 전체 통과. 이름 + 루트 라벨 부분일치(대소문자 무시).
  function matchService(svc, query) {
    const q = String(query == null ? '' : query).trim().toLowerCase();
    if (!q) return true;
    const hay = `${(svc && svc.name) || ''} ${rootShort(svc && svc.root)}`.toLowerCase();
    return hay.includes(q);
  }

  return { rootShort, matchService };
});
