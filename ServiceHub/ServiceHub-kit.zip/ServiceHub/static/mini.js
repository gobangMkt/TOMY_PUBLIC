const listEl = document.getElementById('m-list');
const upEl = document.getElementById('m-up');
const totalEl = document.getElementById('m-total');
const liveDot = document.getElementById('m-livedot');
const timerEl = document.getElementById('m-timer');
const headElapsedEl = document.getElementById('m-head-elapsed');
const rows = new Map();

const api = (p, m = 'GET') => fetch(p, { method: m }).then((r) => r.json());

const IC = {
  play: '<svg class="ic" viewBox="0 0 20 20"><path d="M6 4.5v11l9-5.5z"/></svg>',
  stop: '<svg class="ic" viewBox="0 0 20 20"><rect x="5" y="5" width="10" height="10" rx="2"/></svg>',
  open: '<svg class="ic" viewBox="0 0 20 20"><path d="M11 3h6v6l-2.3-2.3-3.6 3.6-1.4-1.4 3.6-3.6z"/><path d="M5 5h4v2H7v6h6v-2h2v4H5z"/></svg>',
  claude: '<svg class="ic" viewBox="0 0 20 20"><path d="M10 1.5l1.7 5.1 5.1 1.7-5.1 1.7L10 15.1l-1.7-5.1L3.2 8.3l5.1-1.7z"/></svg>',
  folder: '<svg class="ic" viewBox="0 0 20 20"><path d="M2.5 5.6A1.6 1.6 0 0 1 4.1 4h3l1.6 2H16a1.6 1.6 0 0 1 1.6 1.6v5.8A1.6 1.6 0 0 1 16 15H4.1a1.6 1.6 0 0 1-1.6-1.6z"/></svg>',
};
const RUNNING = new Set(['running', 'starting', 'external']);
const isLive = (s) => s === 'running' || s === 'external';
const COLOR = {
  running: 'var(--accent)', external: 'var(--accent)', starting: 'var(--accent)',
  stopped: 'var(--dim)', exited: 'var(--dim)', error: 'var(--err)', idle: 'var(--dim)',
};
const color = (s) => COLOR[s] || 'var(--dim)';
const ROOT_SHORT = (r) => r.replace('프로젝트/', '').replace('에이전트', 'agent');

function primaryBtnHTML(s) {
  if (s.status === 'starting') return `<button class="m-btn m-primary busy" disabled><span class="spin"></span>시작 중</button>`;
  if (isLive(s.status)) return `<button class="m-btn m-primary halt" data-act="primary">${IC.stop}중지</button>`;
  return `<button class="m-btn m-primary go" data-act="primary">${IC.play}${s.type === 'task' ? '실행' : '시작'}</button>`;
}

function actionsHTML(s) {
  const b = [];
  if (s.type !== 'folder') b.push(primaryBtnHTML(s));
  if (s.type === 'web') b.push(`<button class="m-btn" data-act="open" title="웹 열기">${IC.open}</button>`);
  b.push(`<button class="m-btn" data-act="claude" title="Claude 열기">${IC.claude}</button>`);
  b.push(`<button class="m-btn" data-act="folder" title="폴더 열기">${IC.folder}</button>`);
  return b.join('');
}

function miniDeployIconsHTML(s) {
  const urls = Array.isArray(s.deploy_urls) ? s.deploy_urls
    : (s.deploy_url ? [s.deploy_url] : []);
  if (!urls.length) return '';
  return urls.map((url, i) =>
    `<button class="m-deploy-btn" data-deploy-url="${url}" title="${url}" aria-label="배포 링크${urls.length > 1 ? ` ${i + 1}` : ''}">${IC.open}</button>`
  ).join('');
}

function cardHTML(s) {
  const mid = s.type === 'web'
    ? `<div class="m-cmid"><span class="m-port">:${s.port ?? '-'}</span></div>` : '';
  return `<div class="m-ctop">
      <span class="m-rdot"></span>
      <span class="m-name" title="${s.name}">${s.name}</span>
      ${miniDeployIconsHTML(s)}
    </div>
    ${mid}
    <div class="m-cbtns">${actionsHTML(s)}</div>`;
}

function onAct(act, s) {
  if (act === 'primary') return toggle(s);
  if (act === 'open') return window.pywebview?.api?.open_url?.(`http://localhost:${s.port}`);
  if (act === 'claude') return api(`/api/services/${s.id}/open-claude`, 'POST');
  if (act === 'folder') return api(`/api/services/${s.id}/open-folder`, 'POST');
}

async function toggle(s) {
  if (s.status === 'starting') return;
  const isTask = s.type === 'task';
  if (isLive(s.status)) {
    s.status = 'stopped';
    paint(); await api(`/api/services/${s.id}/stop`, 'POST');
  } else {
    s.status = 'starting';
    paint(); await api(`/api/services/${s.id}/${isTask ? 'run' : 'start'}`, 'POST');
  }
  setTimeout(refresh, 1100);
}

let services = [];
let query = '';
function paint() {
  const up = services.filter((s) => RUNNING.has(s.status)).length;
  upEl.textContent = up;
  totalEl.textContent = services.length;
  liveDot.classList.toggle('live', up > 0);

  const visible = services.filter((s) => matchService(s, query));
  const byRoot = {};
  for (const s of visible) (byRoot[s.root] ??= []).push(s);
  listEl.innerHTML = '';
  rows.clear();
  if (!services.length) { listEl.innerHTML = '<div class="m-empty">서비스 없음</div>'; return; }
  if (!visible.length) {
    listEl.innerHTML = `<div class="m-empty">'${query.trim()}' 일치 없음</div>`;
    return;
  }
  for (const [root, list] of Object.entries(byRoot)) {
    list.sort((a, b) => (RUNNING.has(b.status) - RUNNING.has(a.status)) || a.name.localeCompare(b.name, 'ko'));
    const g = document.createElement('div');
    g.className = 'm-group';
    g.innerHTML = `<div class="m-glabel">${ROOT_SHORT(root)}</div><div class="m-cards"></div>`;
    const grid = g.querySelector('.m-cards');
    for (const s of list) {
      const card = document.createElement('div');
      const live = s.status === 'running' || s.status === 'starting';
      card.className = 'm-card' + (live ? ' is-live' : s.status === 'external' ? ' is-ext' : '');
      card.style.setProperty('--st', color(s.status));
      card.innerHTML = cardHTML(s);
      card.querySelectorAll('[data-act]').forEach((b) => { b.onclick = () => onAct(b.dataset.act, s); });
      card.querySelectorAll('[data-deploy-url]').forEach((b) => {
        b.onclick = (e) => {
          e.stopPropagation();
          window.pywebview?.api?.open_url?.(b.dataset.deployUrl);
        };
      });
      grid.appendChild(card);
      rows.set(s.id, s);
    }
    listEl.appendChild(g);
  }
}

async function refresh() {
  services = await api('/api/services');
  paint();
}

const rescanBtn = document.getElementById('m-rescan');
rescanBtn.onclick = async () => {
  if (rescanBtn.classList.contains('spinning')) return;
  rescanBtn.classList.add('spinning');
  try { await api('/api/rescan', 'POST'); await refresh(); }
  finally { rescanBtn.classList.remove('spinning'); }
};

document.getElementById('m-hide').onclick = () => {
  window.pywebview?.api?.hide?.();
};

// 대시보드 바로가기 — 외부 브라우저로 허브 대시보드 열기
document.getElementById('m-dash').onclick = () => {
  window.pywebview?.api?.open_url?.(`http://${location.host}/`);
};

/* ───────── 업무 타이머 ───────── */
const pad = (n) => String(n).padStart(2, '0');
function fmtElapsed(sec) {
  sec = Math.max(0, Math.floor(sec));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return h ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}
function fmtToday(sec) {
  const m = Math.floor(Math.max(0, sec) / 60), h = Math.floor(m / 60);
  return h ? `${h}시간 ${m % 60}분` : `${m}분`;
}

let timer = { running: false, started_at: null, today_seconds: 0 };
let timerTick = null;
const PLAY = '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M6 4.5v11l9-5.5z"/></svg>';
const STOP = '<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="5" y="5" width="10" height="10" rx="2"/></svg>';

function liveElapsed() {
  if (!timer.running || !timer.started_at) return 0;
  return (Date.now() - new Date(timer.started_at).getTime()) / 1000;
}

function paintTimer() {
  const run = timer.running;
  const el = liveElapsed();
  timerEl.classList.toggle('running', run);
  if (run) {
    const todayTotal = (timer.today_seconds || 0) + el;
    timerEl.innerHTML =
      `<span class="mt-dot"></span><span class="mt-label">업무중</span>` +
      `<span class="mt-elapsed">${fmtElapsed(el)}</span>` +
      `<span class="mt-today">· 오늘 ${fmtToday(todayTotal)}</span>` +
      `<button class="mt-btn stop" data-tact="stop">${STOP}종료</button>`;
    headElapsedEl.textContent = fmtElapsed(el);
  } else {
    timerEl.innerHTML =
      `<span class="mt-dot"></span><span class="mt-label">업무 타이머</span>` +
      (timer.today_seconds ? `<span class="mt-today">· 오늘 ${fmtToday(timer.today_seconds)}</span>` : '') +
      `<button class="mt-btn go" data-tact="start">${PLAY}시작</button>`;
    headElapsedEl.textContent = '';
  }
  timerEl.querySelector('[data-tact]').onclick = (e) =>
    onTimer(e.currentTarget.dataset.tact);
}

function startTick() { if (!timerTick) timerTick = setInterval(paintTimer, 1000); }
function stopTick() { if (timerTick) { clearInterval(timerTick); timerTick = null; } }

function applyTimer(s) {
  if (!s) return;
  timer = s;
  paintTimer();
  s.running ? startTick() : stopTick();
  if (s.auto_stopped) {
    showMiniToast(s.auto_stopped === 'long_run'
      ? '장시간 감지로 업무 타이머가 자동 종료됐어요'
      : '자정이 지나 업무 타이머가 자동 종료됐어요');
  }
}

async function onTimer(act) {
  if (act === 'start') {
    timer = { ...timer, running: true, started_at: new Date().toISOString() };
    paintTimer(); startTick();
    applyTimer(await api('/api/timer/start', 'POST'));
  } else {
    stopTick();
    applyTimer(await api('/api/timer/stop', 'POST'));
  }
}

async function loadTimer() {
  try { applyTimer(await api('/api/timer')); } catch (e) { /* noop */ }
}

let toastTimer = null;
function showMiniToast(msg) {
  const t = document.getElementById('m-toast');
  if (!t) return;
  t.textContent = msg;
  t.hidden = false;
  t.classList.remove('out');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    t.classList.add('out');
    setTimeout(() => { t.hidden = true; }, 300);
  }, 4000);
}

// 검색 — 돋보기로 검색바 토글, Esc로 닫기. 창 크기는 그대로(내부 리스트만 줄어듦).
const searchBox = document.getElementById('m-search');
const searchInput = document.getElementById('m-search-input');
const searchBtn = document.getElementById('m-search-btn');
const searchClear = document.getElementById('m-search-clear');
function setQuery(v) {
  query = v;
  if (searchInput.value !== v) searchInput.value = v;
  searchClear.hidden = !v;
  paint();
}
function setSearchOpen(open) {
  searchBox.hidden = !open;
  searchBtn.setAttribute('aria-pressed', String(open));
  if (open) searchInput.focus();
  else setQuery('');
}
searchBtn.onclick = () => setSearchOpen(searchBox.hidden);
searchInput.oninput = () => setQuery(searchInput.value);
searchClear.onclick = () => { setQuery(''); searchInput.focus(); };
searchInput.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (query) setQuery('');
    else setSearchOpen(false);
  }
});

const DPR = window.devicePixelRatio || 1;

// 최소화 ↔ 펼침 (미니바) — 헤더 실제 크기를 측정해 DPR 적용한 물리 px로 축소
let collapsed = false;
document.getElementById('m-min').onclick = () => {
  collapsed = !collapsed;
  document.body.classList.toggle('collapsed', collapsed);
  if (collapsed) {
    const head = document.querySelector('.m-head');
    const w = Math.round(210 * DPR);            // 콘텐츠 충분한 고정 논리폭 × 배율
    const h = Math.round(head.offsetHeight * DPR);
    window.pywebview?.api?.set_collapsed?.({ collapsed: true, w, h });
  } else {
    window.pywebview?.api?.set_collapsed?.({ collapsed: false });
  }
};
function grip(el, useW, useH) {
  if (!el) return;
  el.addEventListener('mousedown', async (e) => {
    e.preventDefault();
    if (collapsed) return;
    const sx = e.screenX, sy = e.screenY;
    let sw, sh;
    try { [sw, sh] = await window.pywebview.api.get_size(); } catch { return; }
    const move = (ev) => {
      const w = useW ? sw + (sx - ev.screenX) * DPR : sw;
      const h = useH ? sh + (sy - ev.screenY) * DPR : sh;
      window.pywebview?.api?.resize_to?.({ w: Math.round(w), h: Math.round(h) });
    };
    const up = () => {
      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseup', up);
    };
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', up);
  });
}
grip(document.getElementById('grip-t'), false, true);
grip(document.getElementById('grip-l'), true, false);
grip(document.getElementById('grip-tl'), true, true);

const MU_STATUS = {
  needs_login: '재로그인 필요', no_credentials: '연결 안 됨',
  network: '연결 실패', http_error: '연결 실패', init: '연결 중…',
};

function muResetIn(iso) {
  if (!iso) return '';
  const ms = new Date(iso) - new Date();
  if (ms <= 0) return '곧';
  const h = Math.floor(ms / 3.6e6), m = Math.floor((ms % 3.6e6) / 6e4);
  if (h >= 24) return `${Math.floor(h / 24)}일`;
  return h ? `${h}시간` : `${m}분`;
}

function renderMiniUsage(limits, status) {
  const lim = limits || {};
  const sess = document.getElementById('mu-session');
  const gz = document.getElementById('mu-gauges');
  if (!sess || !gz) return;
  if (!limits && status && status !== 'ok') {
    const relogin = status === 'needs_login'
      ? ` <button class="mu-relogin-btn" id="mu-relogin-btn" type="button">지금 재로그인</button>` : '';
    sess.innerHTML = `${MU_STATUS[status] || ''}${relogin}`;
    sess.className = 'mu-session' + (status !== 'init' ? ' bad' : '');
    sess.hidden = false;
    gz.innerHTML = '';
    if (status === 'needs_login') {
      document.getElementById('mu-relogin-btn').onclick = async () => {
        await api('/api/usage/relogin', 'POST');
        showMiniToast('새 콘솔 창에서 Claude 로그인을 완료하세요');
      };
    }
    return;
  }
  sess.hidden = true;
  sess.textContent = '';
  const list = [
    ['현재', lim.session],
    ['전체', lim.weekly_all],
    [(lim.weekly_scoped && lim.weekly_scoped.label) || 'Sonnet', lim.weekly_scoped],
  ];
  gz.innerHTML = list.map(([name, d]) => {
    const pct = (d && d.percent != null) ? d.percent : 0;
    const sub = d ? muResetIn(d.resets_at) : '';
    return `<div class="mu-g"><div class="mu-top"><span>${name}</span><b>${pct}%</b></div>
      <div class="mu-track"><i style="width:${Math.min(100, pct)}%"></i></div>
      <div class="mu-sub">${sub}</div></div>`;
  }).join('');
}

async function loadMiniUsage() {
  try {
    const u = await api('/api/usage');
    renderMiniUsage(u.limits, u.status);
  } catch (e) { /* noop */ }
}

function connectWS() {
  const ws = new WebSocket(`ws://${location.host}/ws`);
  ws.onmessage = (e) => {
    const { id, kind, payload } = JSON.parse(e.data);
    if (kind === 'usage') { renderMiniUsage(payload.limits, payload.status); return; }
    if (kind === 'timer') { applyTimer(payload); return; }
    if (kind !== 'state') return;
    const s = rows.get(id);
    if (s) { s.status = payload; paint(); }
  };
  ws.onclose = () => setTimeout(connectWS, 2000);
}

refresh();
loadMiniUsage();
loadTimer();
connectWS();
setInterval(refresh, 3000);
