/* 첫 실행 온보딩 — 루트레포 선택 → 하위 스캔 미리보기 → 스캔 root 확정 저장 (팀원 배포용) */
(() => {
  const el = (id) => document.getElementById(id);
  const overlay = el('onboard');
  if (!overlay) return;
  const pathIn = el('ob-path');
  const scanBtn = el('ob-scan');
  const candsEl = el('ob-cands');
  const saveBtn = el('ob-save');
  const statusEl = el('ob-status');
  const hintEl = el('ob-hint');

  const post = (p, body) =>
    fetch(p, { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {}) }).then((r) => r.json());

  function show() { overlay.classList.remove('hidden'); overlay.setAttribute('aria-hidden', 'false'); pathIn.focus(); }

  function setStatus(msg, kind) {
    statusEl.textContent = msg || '';
    statusEl.className = 'ob-fstatus' + (kind ? ' ' + kind : '');
  }

  function syncSaveState() {
    const n = candsEl.querySelectorAll('input[type=checkbox]:checked').length;
    saveBtn.disabled = n === 0;
    saveBtn.textContent = n > 0 ? `시작하기 · ${n}개 폴더` : '시작하기';
  }

  function renderCandidates(cands) {
    candsEl.innerHTML = '';
    if (!cands.length) {
      candsEl.innerHTML = '<li class="ob-empty">실행 가능한 서비스를 찾지 못했습니다. 다른 폴더를 선택하거나, 그래도 스캔하려면 폴더를 직접 지정하세요.</li>';
      syncSaveState();
      return;
    }
    for (const c of cands) {
      const li = document.createElement('li');
      li.className = 'ob-cand' + (c.count ? '' : ' ob-cand-empty');
      const samples = (c.samples || []).join(' · ');
      li.innerHTML = `
        <label>
          <input type="checkbox" value="${encodeURIComponent(c.path)}" ${c.recommended ? 'checked' : ''}>
          <span class="ob-cand-main">
            <span class="ob-cand-name">${escapeHtml(c.label)}</span>
            <span class="ob-cand-path">${escapeHtml(c.path)}</span>
            ${samples ? `<span class="ob-cand-samples">${escapeHtml(samples)}${c.count > (c.samples || []).length ? ' …' : ''}</span>` : ''}
          </span>
          <span class="ob-cand-count">${c.count}</span>
        </label>`;
      candsEl.appendChild(li);
    }
    candsEl.querySelectorAll('input[type=checkbox]').forEach((cb) =>
      cb.addEventListener('change', syncSaveState));
    syncSaveState();
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  async function doScan() {
    const folder = pathIn.value.trim().replace(/^"|"$/g, '');
    if (!folder) { setStatus('경로를 입력하세요', 'err'); return; }
    setStatus('스캔 중…');
    candsEl.innerHTML = '<li class="ob-empty">스캔 중…</li>';
    try {
      const res = await post('/api/onboard/preview', { folder });
      if (!res.ok) {
        const reason = res.reason === 'not_a_dir' ? '폴더가 존재하지 않습니다' : '경로를 확인하세요';
        setStatus(reason, 'err');
        candsEl.innerHTML = `<li class="ob-empty">${reason}</li>`;
        return;
      }
      pathIn.value = res.folder;
      setStatus('');
      renderCandidates(res.candidates);
      const hits = res.candidates.filter((c) => c.count).length;
      hintEl.innerHTML = hits
        ? `서비스가 있는 폴더 <b>${hits}곳</b>을 자동 체크했습니다. 조정 후 <b>시작하기</b>.`
        : '이 폴더에선 서비스를 못 찾았습니다. 상위/다른 폴더를 시도하세요.';
    } catch (e) {
      setStatus('스캔 실패', 'err');
    }
  }

  async function doBrowse() {
    setStatus('폴더 선택 창을 여는 중…');
    try {
      const res = await post('/api/onboard/browse', {});
      if (res.path) { pathIn.value = res.path; setStatus(''); doScan(); }
      else { setStatus(res.note === 'frozen' ? '경로를 직접 붙여넣어 주세요' : '선택이 취소됨'); }
    } catch (e) { setStatus('찾기 실패 — 경로를 직접 입력하세요', 'err'); }
  }

  async function doSave() {
    const roots = [...candsEl.querySelectorAll('input[type=checkbox]:checked')]
      .map((cb) => decodeURIComponent(cb.value));
    if (!roots.length) return;
    saveBtn.disabled = true;
    setStatus('저장·스캔 중…');
    try {
      const res = await post('/api/onboard/save', { roots });
      if (res.ok) { setStatus(`완료 · 서비스 ${res.count}개 발견`, 'ok'); location.reload(); }
      else { setStatus('저장 실패', 'err'); saveBtn.disabled = false; }
    } catch (e) { setStatus('저장 실패', 'err'); saveBtn.disabled = false; }
  }

  // 입력 시 스캔 버튼 활성화, Enter로 스캔
  pathIn.addEventListener('input', () => { scanBtn.disabled = !pathIn.value.trim(); });
  pathIn.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); doScan(); } });
  scanBtn.addEventListener('click', doScan);
  el('ob-browse').addEventListener('click', doBrowse);
  saveBtn.addEventListener('click', doSave);

  // 시작: 온보딩 필요 여부 확인
  fetch('/api/onboard/status').then((r) => r.json()).then((s) => {
    if (!s.onboarded) show();
  }).catch(() => { /* 상태 확인 실패 시 온보딩 강제하지 않음 */ });
})();
