# ServiceHub

로컬 서비스 통합 관리 허브 (로컬 전용). 트레이 상주 + localhost:3050 대시보드.

## 기술 스택
- Python 3.10+ / FastAPI / uvicorn / psutil / pystray / Pillow / winotify / PyInstaller

## 실행
- `설치.bat` — 팀원 원샷 설치(`install.ps1`: 의존성 설치·검증·기동, `-Autostart`로 부팅 자동실행). 최초 1회
- `시작.vbs` — 평소 실행(콘솔 없이 트레이)
- `시작 3050.bat` — 콘솔 보며 실행(디버그)
- `제거.bat` — 팀원 제거(`uninstall.ps1`: 자동실행 해제 + 이 폴더에서 띄운 프로세스 종료)
- `build.bat` — exe 빌드

## 팀원 배포 / 온보딩
- 팀원은 이 폴더를 받아 `설치.bat` 더블클릭(또는 Claude에 "README 팀원 설치 런북 실행") → 대시보드 첫 화면 **온보딩**에서 관리할 **루트레포 폴더**를 고른다.
- 온보딩: `_detect_repo_root`(모노레포 이름 탐지)에 의존하지 않고, 팀원이 고른 폴더를 `scanner.preview_candidates`로 훑어 서비스 있는 하위폴더를 자동추천 → 체크로 확정 → `config.roots`에 **절대경로** 저장 + `onboarded:true`. 트리거: `config.is_onboarded()`(roots 중 실존 폴더 없고 플래그 false면 온보딩 표시 → 기존 모노레포 사용자는 자동 스킵).
- 미니뷰 토글은 트레이 메뉴 + 대시보드 헤더 "미니뷰" 버튼(`POST /api/miniview/toggle`) 둘 다 제공. 부팅 자동실행은 트레이 "부팅 시 자동 시작" 토글로 켠다.

## 테스트
`python -m pytest tests/ -v`

## 설정 (config.json)
- `roots`: 스캔할 폴더(repo 루트 상대경로). 기본 for_Local/for_Release/for_Drop/에이전트.
  스캔은 각 root의 **1단계 자식만** 본다. 중첩된 서비스(예: `에이전트/notion-agents/agents/*`)는
  그 부모 경로를 roots에 직접 추가해야 발견된다.
- `overrides`: 서비스 id별 port/name/command/type/enabled 수동 오버라이드(포트 고정 시 사용)
- `assigned_ports`: 매니저 자동 기록(편집 불필요). 런타임 재배정 결과도 여기 영속화됨

## 포트 정책 (ServiceHub가 전담)
- **배정**: registry가 web 서비스 간 유니크 포트 배정. override/이전배정 → 의도포트(시작bat) → 풀(3060+).
- **런타임 충돌 재정리**: 시작 시 배정 포트가 이미 점유(외부 프로세스 등)면 에러로 끝내지 않고,
  `reassign_port`로 다른 서비스 포트 + OS 점유 포트를 모두 피해 풀에서 다음 빈 포트로 **자동 재배정 후 기동**.
  새 포트는 config.assigned_ports에 저장돼 다음부터 고정. 대시보드 카드 포트/링크는 `port` WS 이벤트로 즉시 갱신.
  단, 허브가 직접 띄운 프로세스가 살아있으면(이미 실행 중) 재배정하지 않고 현재 상태를 재전송.

## 중지 정책 (stop/kill) — ⚠️ 회귀 주의
서비스가 "안 꺼지는" 버그가 반복됐다. 중지 로직(`supervisor._kill_by_port`/`stop`)은 아래 불변식을 **반드시** 지킨다. 수정 시 `tests/test_supervisor.py`의 `test_kill_by_port_kills_*` 회귀 테스트가 통과해야 한다.

- **모든 리스너를 죽인다**: 포트의 첫 리스너만 죽이고 `return` 금지. IPv4(127.0.0.1)·IPv6(::1)에 **별도 프로세스로 따로 바인딩**되거나 중복 리스너가 있으면 하나만 죽여선 포트가 안 풀린다(`is_port_free`는 둘 중 하나라도 점유면 사용중 판정).
- **재spawn 부모까지 죽인다**: 리스너에서 위로 거슬러 올라가(`_kill_root`) next dev·npm·nodemon 등 **워커를 재spawn하는 슈퍼바이저**를 함께 종료한다. 하위 트리만 죽이면 부모가 워커를 즉시 부활시켜 포트가 다시 점유된다.
- **보호 대상은 절대 안 죽인다**: 셸/터미널/claude/탐색기(`_is_ignorable_proc`)에서 위로 올라가기를 멈추고, 허브 자신과 그 조상 PID(`_own_pids`)는 종료 대상에서 제외한다(다른 Claude 세션·허브 자폭 방지).
- **stop은 트리킬 후에도 포트 스윕**: 허브가 직접 띄운 프로세스라도 트리 밖으로 새 나간(re-parent된) 리스너가 남을 수 있어 `_kill_by_port`를 항상 한 번 더 돌린다.

## 동작 구조
1. 트레이 기동 → roots 스캔 → 서비스 자동 발견(web/task)
2. registry가 포트 유니크 배정(충돌 시 3060+ 풀), config에 영속화
3. 대시보드에서 시작/중지 → supervisor가 창 없이 spawn·트리킬. 기동 시 포트 점유면 자동 재배정(위 포트 정책)
4. WebSocket으로 상태·로그·포트 재배정 실시간 표시
5. Claude 사용량(`src/usage.py`): 2분 폴러가 OAuth 한도 %(`api/oauth/usage`)를 `kind:'usage'`로 푸시. 로컬 토큰은 `/api/usage`가 `~/.claude/projects/**/*.jsonl` 세션 기록을 **직접 집계**(메시지별 timestamp·model·usage). Claude Code의 `stats-cache.json`은 `/usage` 실행 때만 갱신돼 며칠씩 멈추므로 의존하지 않음 → 항상 오늘까지 최신. 파일 mtime+size 증분 캐시(`_file_cache`), 토큰id로 resume 중복 dedup, 로컬 날짜로 버킷팅. 일별 토큰 = 4종 합(input+output+cache_read+cache_creation), Claude Code `/usage` 숫자와는 다를 수 있음(내부 필터 비공개). 프론트는 페이지 로드 + 5분 주기 `loadUsage()`로 갱신(자정 롤오버 포함). 대시보드 statbar 아래 독립 섹션 + 미니뷰 상단 섹션. 토큰 값은 절대 로그·UI 노출 금지

## 업무 타이머(`src/timer.py`)
전역 단일 타이머. RoutineLog 운동 타이머와 동일 원리 — **시작 절대시각(`started_at`)만 `config.work_timer`에 저장하고 경과는 클라가 `now-started_at`로 매초 계산**(영속, 재시작·새로고침해도 이어짐). `today_seconds`는 그날 종료된 세션 누적(자정 날짜키 롤오버로 0 리셋). 가드: 진행 중 자정 넘김 → 자동종료(전날 몫 폐기), 12시간 초과 → 자동종료(상한 12h 누적) + `auto_stopped` 플래그 1회 브로드캐스트. API `GET/POST /api/timer(/start|/stop)`, WS `kind:'timer'`. 대시보드는 헤더 우측 칩, 미니뷰는 상단 딥바이올렛 블록 내 타이머 바 + **최소화(collapsed) 시 미니바에 경과시간 노출**(`#m-head-elapsed`). 자정·12h reconcile은 2분 폴러가 수행.
