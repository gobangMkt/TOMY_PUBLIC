﻿[CmdletBinding()]
param([switch]$Autostart, [switch]$NoLaunch)

# ServiceHub 팀원 설치 스크립트 — 의존성 설치·검증·(선택)부팅 자동실행·기동까지 원샷.
$ErrorActionPreference = 'Stop'
$here = $PSScriptRoot
Set-Location $here

function PythonwPath {
  $p = & python -c "import sys,os;print(os.path.join(os.path.dirname(sys.executable),'pythonw.exe'))"
  if ($p -and (Test-Path $p)) { return $p }
  return (Get-Command python).Source
}

Write-Host ''
Write-Host '=== ServiceHub 설치 ===' -ForegroundColor Cyan

# 1) Python 확인 (3.10+)
$py = Get-Command python -ErrorAction SilentlyContinue
if (-not $py) {
  throw 'Python이 없습니다. https://www.python.org/downloads/ 에서 3.11~3.13 설치(설치 시 "Add to PATH" 체크) 후 다시 실행하세요.'
}
$ver = (& python -c "import sys;print('%d.%d'%sys.version_info[:2])").Trim()
Write-Host "  Python $ver 감지"
if ($ver -eq '3.14') {
  Write-Host '  주의: 3.14는 pywebview/pythonnet 휠이 없어 미니뷰 설치가 실패할 수 있습니다(대시보드는 정상).' -ForegroundColor Yellow
}

# 2) 의존성 설치 — 반드시 python -m pip (pythonw와 같은 인터프리터에 설치)
Write-Host '  패키지 설치 중… (python -m pip install -r requirements.txt)'
& python -m pip install -r (Join-Path $here 'requirements.txt')
if ($LASTEXITCODE -ne 0) {
  throw 'pip 설치 실패. Python 3.11~3.13 권장. 특정 패키지만 실패하면 그 패키지만 재설치하세요.'
}

# 3) 핵심 모듈 검증 (한글은 PowerShell이 출력 — python -c 콘솔 인코딩 깨짐 방지)
& python -c "import fastapi, uvicorn, psutil, pystray, PIL, winotify"
if ($LASTEXITCODE -ne 0) { throw '핵심 패키지 import 실패 — 위 오류의 모듈을 재설치하세요.' }
Write-Host '  핵심 패키지 OK'
& python -c "import webview" 2>$null
if ($LASTEXITCODE -eq 0) { Write-Host '  pywebview OK — 미니뷰 사용 가능' }
else { Write-Host '  pywebview 미설치 — 미니뷰만 비활성(대시보드/트레이는 정상)' -ForegroundColor Yellow }

# 4) (선택) 부팅 자동실행 등록
if ($Autostart) {
  $runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
  $val = '"' + (PythonwPath) + '" "' + (Join-Path $here 'src\main.py') + '"'
  New-ItemProperty -Path $runKey -Name 'ServiceHub' -Value $val -PropertyType String -Force | Out-Null
  Write-Host '  부팅 자동실행 등록 완료 (해제: 제거.bat 또는 트레이 메뉴)'
}

# 5) 기동 — 시작.vbs와 동일(콘솔 없이 트레이). 이미 3050 점유면 중복 실행 안 함
if (-not $NoLaunch) {
  $busy = Get-NetTCPConnection -LocalPort 3050 -State Listen -ErrorAction SilentlyContinue
  if ($busy) {
    Write-Host '  이미 실행 중(포트 3050 점유) — 새로 띄우지 않습니다.' -ForegroundColor Yellow
  } else {
    Start-Process -FilePath (PythonwPath) -ArgumentList 'src\main.py' -WorkingDirectory $here
    Start-Sleep -Seconds 4
    try { $code = (Invoke-WebRequest 'http://localhost:3050' -UseBasicParsing -TimeoutSec 6).StatusCode }
    catch { $code = $_.Exception.Message }
    Write-Host "  기동 확인 (200이면 성공): $code"
  }
}

Write-Host ''
Write-Host '설치 완료!' -ForegroundColor Green
Write-Host '  브라우저에서 http://localhost:3050 접속 → 첫 화면에서 관리할 루트레포 폴더를 선택하세요.'
Write-Host '  트레이 아이콘: 작업표시줄 우측 ^(숨겨진 아이콘) 영역. 우클릭으로 미니뷰/자동실행/종료 제어.'
