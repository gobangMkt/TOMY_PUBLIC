﻿[CmdletBinding()]
param()

# ServiceHub 제거 — 부팅 자동실행 해제 + 이 폴더에서 띄운 프로세스 종료. 소스/설정은 남김.
$ErrorActionPreference = 'Continue'
$here = $PSScriptRoot

Write-Host ''
Write-Host '=== ServiceHub 제거 ===' -ForegroundColor Cyan

# 1) 부팅 자동실행 해제
$runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
try {
  Remove-ItemProperty -Path $runKey -Name 'ServiceHub' -ErrorAction Stop
  Write-Host '  부팅 자동실행 해제 완료'
} catch { Write-Host '  부팅 자동실행 등록 없음 (건너뜀)' }

# 2) 이 설치 폴더의 main.py 로 뜬 프로세스만 종료 (다른 python 트레이앱 보호)
$folderName = Split-Path $here -Leaf
$killed = 0
Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'" |
  Where-Object { $_.CommandLine -and $_.CommandLine -like '*main.py*' -and $_.CommandLine -like "*$folderName*" } |
  ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop; $killed++ } catch {} }
Write-Host "  실행 중 프로세스 종료: $killed 개"

Write-Host ''
Write-Host '제거 완료.' -ForegroundColor Green
Write-Host '  소스·설정(config.json)은 폴더에 그대로 남습니다. 완전 삭제는 이 폴더를 지우세요.'
